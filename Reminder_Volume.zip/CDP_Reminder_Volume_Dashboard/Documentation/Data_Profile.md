# Data Profile

Profile of the supplied extract, produced by `python tools/gen_docs.py` before any modelling decision was taken.

| Property | Value |
|---|---|
| Source | `Data/CDP_Projects_Summary_History.csv` |
| Rows | 162 |
| Columns | 9 |
| Date range | 2026-04-22 to 2026-09-10 |
| Distinct dates with data | 91 |
| Total volume column sum | 2,016 |
| Encoding | UTF-8 with BOM |

## Columns as they appear in the file

| # | Header | Inferred type | Distinct values | Nulls |
|---:|---|---|---:|---:|
| 1 | `Client_name` | text | 3 | 0 |
| 2 | `client_group` | text | 3 | 0 |
| 3 | `comm_code` | text | 3 | 0 |
| 4 | `site_code` | text | 8 | 0 |
| 5 | `rem_flag` | text | 4 | 0 |
| 6 | `Program` | text | 2 | 0 |
| 7 | `file_date` | date (dd-MMM-yy) | 91 | 0 |
| 8 | `t_c_ind` | text | 1 | 0 |
| 9 | `email_counts` | whole number | 29 | 0 |

> The volume column ships as **`email_counts`**, while the specification calls it `Number of Email`. Power Query accepts either name and normalises to `Number of Email`, so the documented DAX works verbatim against either drop.

## Distinct values

### `Client_name` - 3 distinct

| Value | Rows |
|---|---:|
| Ashley Advantage® Credit Card | 35 |
| BrandsMart USA Credit Card | 124 |
| CITY Furniture VIP Credit Card | 3 |

### `client_group` - 3 distinct

| Value | Rows |
|---|---:|
| ASFU20 | 35 |
| BRSM20 | 124 |
| CIFU20 | 3 |

### `Program` - 2 distinct

| Value | Rows |
|---|---:|
| AOPQ | 159 |
| FOC | 3 |

### `rem_flag` - 4 distinct

| Value | Rows |
|---|---:|
| REM1 | 64 |
| REM2 | 32 |
| REM3 | 35 |
| REM4 | 31 |

### `comm_code` - 3 distinct

| Value | Rows |
|---|---:|
| EMACTY | 3 |
| R03PPREEM11XXTX01A | 124 |
| V13PPREXE11XXTX01A | 35 |

### `site_code` - 8 distinct

| Value | Rows |
|---|---:|
| AOPBUSEM1 | 28 |
| AOPBUSEM2 | 31 |
| AOPBUSEM3 | 34 |
| AOPBUSEM4 | 31 |
| AOPSHEM1 | 35 |
| QSCTFEMR1 | 1 |
| QSCTFEMR2 | 1 |
| QSCTFEMR3 | 1 |

### `t_c_ind` - 1 distinct

| Value | Rows |
|---|---:|
| T | 162 |

## Findings that shaped the model

1. **There are no Control records.** All 162 rows carry `t_c_ind = "T"`. The Test/Control rule is still enforced in the measure rather than assumed, and `Dim_Population` still carries a Control member, so the report behaves correctly the first time a Control row appears.
2. **The feed is not daily-complete.** 91 distinct dates span 2026-04-22 to 2026-09-10, a window of 142 calendar days. Averages therefore divide by days that carry data, and the previous-day comparison looks for the previous day that exists rather than subtracting one.
3. **Journeys differ in length.** The three client + program pairs in this extract have one, three and four reminder stages respectively, so the dynamic-journey requirement is exercised by real data rather than a contrived case.

| Client | Program | Stages present |
|---|---|---|
| Ashley Advantage® Credit Card | AOPQ | REM1 |
| BrandsMart USA Credit Card | AOPQ | REM1  ->  REM2  ->  REM3  ->  REM4 |
| CITY Furniture VIP Credit Card | FOC | REM1  ->  REM2  ->  REM3 |

4. **`comm_code` and `client_group` are one-to-one with the client in this extract**, and `site_code` is one-to-one with the reminder stage within a client. Nothing in the model assumes that will stay true.
5. **No data-quality failures.** Every validation check returns zero: no nulls, no negative volumes, no unexpected T/C or reminder values, no duplicate rows on the business grain.
