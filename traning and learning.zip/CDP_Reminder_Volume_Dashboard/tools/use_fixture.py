# -*- coding: utf-8 -*-
"""Points the model at the scale fixture, or back at the real extract.

    python tools/use_fixture.py on     # 128 clients, ~99k rows
    python tools/use_fixture.py off    # the supplied 162-row extract

Then regenerate the model and reload Desktop:

    python tools/gen_semantic_model.py

The switch is made in the generator, not in the generated TMDL. Editing the
output works only until the next build regenerates it, which is exactly what
happened the first time - it put the model quietly back on the 162-row extract
in the middle of a scale test, and the screenshots looked fine because they
were of the wrong data.
"""
import io
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GEN = os.path.join(ROOT, "tools", "gen_semantic_model.py")
# The "real" extract is the copy bundled with the project, not a path on
# one particular machine - so this switch works wherever the project is
# checked out.
REAL = os.path.join(ROOT, "Data", "CDP_Projects_Summary_History.csv")
FIXTURE = os.path.join(ROOT, "Data", "scale_fixture.csv")


def main():
    mode = (sys.argv[1] if len(sys.argv) > 1 else "").lower()
    if mode not in ("on", "off"):
        print(__doc__)
        return 2
    want = FIXTURE if mode == "on" else REAL
    text = io.open(GEN, encoding="utf-8").read()
    line = [l for l in text.splitlines() if l.startswith("DEFAULT_SOURCE")][0]
    text = text.replace(line, 'DEFAULT_SOURCE = r"%s"' % want)
    with io.open(GEN, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    print("DEFAULT_SOURCE -> %s" % want)
    print("now run: python tools/gen_semantic_model.py, then reload Desktop")
    return 0


if __name__ == "__main__":
    sys.exit(main())
