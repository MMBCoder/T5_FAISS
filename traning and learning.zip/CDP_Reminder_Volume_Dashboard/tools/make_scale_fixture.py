# -*- coding: utf-8 -*-
"""Generates a production-scale synthetic extract for testing the report.

The supplied extract has three clients and 162 rows. The report is being built
for 100+ clients and 100k+ rows, and a layout that reads well at three clients
can be unusable at a hundred - ranking charts become scrollbars, legends become
walls, heatmaps become a page of empty cells. Asserting that the design scales
is not the same as seeing it, so this writes a fixture with the shape the real
feed will have and the report is pointed at it and looked at.

It is deliberately not random noise. Journeys vary in length the way real ones
do - some clients run one reminder, some four - because the whole point of the
journey band is that it renders only the stages a client actually has, and a
fixture where every client runs four stages would not test that at all.

Run:  python tools/make_scale_fixture.py
Writes Data/scale_fixture.csv and prints its shape.
"""
import csv
import datetime as dt
import os
import random

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "Data", "scale_fixture.csv")

N_CLIENTS = 128
START = dt.date(2025, 4, 1)
DAYS = 540                 # about eighteen months
SEED = 20260911

BRANDS = [
    "Ashley Advantage", "BrandsMart USA", "CITY Furniture VIP", "Conn's HomePlus",
    "Rooms To Go", "Havertys", "Bob's Discount", "Raymour & Flanigan",
    "American Signature", "Value City", "Slumberland", "Furniture Row",
    "La-Z-Boy", "Ethan Allen", "Arhaus", "Crate & Barrel", "West Elm",
    "Pottery Barn", "Restoration Hardware", "Williams Sonoma", "Big Lots",
    "Badcock Home", "Aaron's", "Rent-A-Center", "Sleep Number", "Mattress Firm",
    "Purple Home", "Casper Select", "Tempur-Pedic", "Serta Simmons",
    "Nebraska Furniture", "Jerome's", "Living Spaces", "Ashley Sleep",
]
SUFFIX = ["Credit Card", "Rewards Card", "Store Card", "Platinum Card",
          "Preferred Card"]
PROGRAMS = ["AOPQ", "FOC", "PREQ", "ACQX", "RETN", "WINB", "UPGR", "XSEL"]
SITE_STEMS = ["AOPSHEM", "AOPBUSEM", "FOCSHEM", "PRQSHEM", "RETSHEM"]


def main():
    rnd = random.Random(SEED)

    clients = []
    for i in range(N_CLIENTS):
        brand = BRANDS[i % len(BRANDS)]
        # Beyond the brand list, names repeat with a regional qualifier - real
        # portfolios carry names that are long and share prefixes, which is
        # exactly what breaks a category axis.
        if i >= len(BRANDS):
            brand = "%s %s" % (brand, ["North", "South", "East", "West",
                                       "Central"][(i // len(BRANDS)) % 5])
        name = "%s%s %s" % (brand, "®" if i % 3 == 0 else "",
                            SUFFIX[i % len(SUFFIX)])
        group = "%s%02d" % ("".join(w[0] for w in brand.split()[:2]).upper(),
                            (i % 40) + 10)
        # Journey shape: a quarter run one stage, a quarter two, a quarter
        # three, a quarter four.
        stages = (i % 4) + 1
        progs = rnd.sample(PROGRAMS, rnd.choice([1, 1, 2, 2, 3]))
        # A long tail: a few clients carry most of the volume, most carry very
        # little. A ranking chart over a flat distribution proves nothing.
        weight = rnd.choice([40, 25, 15] + [6] * 10 + [2] * 30 + [1] * 60)
        clients.append({"name": name, "group": group, "stages": stages,
                        "programs": progs, "weight": weight})

    rows = 0
    with open(OUT, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["Client_name", "client_group", "comm_code", "site_code",
                    "rem_flag", "Program", "file_date", "t_c_ind",
                    "email_counts"])
        for day in range(DAYS):
            date = START + dt.timedelta(days=day)
            # Weekends are quiet and roughly one day in nine has no send at
            # all, so the gap-aware date logic is exercised rather than assumed.
            if date.weekday() >= 5 and rnd.random() < 0.75:
                continue
            if rnd.random() < 0.08:
                continue
            for ci, c in enumerate(clients):
                if rnd.random() > min(0.92, 0.34 + c["weight"] / 60.0):
                    continue
                for prog in c["programs"]:
                    if rnd.random() < 0.12:
                        continue
                    for stage in range(1, c["stages"] + 1):
                        # Later stages carry less, the way a reminder sequence
                        # actually behaves.
                        base = c["weight"] * (0.55 ** (stage - 1))
                        vol = max(1, int(rnd.gauss(base * 4, base * 1.2)))
                        comm = "%s%02d%sX%02dA" % (
                            prog[:3].upper(), ci % 90,
                            "PPREXE" if stage % 2 else "PPREEM", stage)
                        site = "%s%d" % (SITE_STEMS[ci % len(SITE_STEMS)], stage)
                        w.writerow([c["name"], c["group"], comm, site,
                                    "REM%d" % stage, prog,
                                    date.strftime("%d-%b-%y"), "T", vol])
                        rows += 1
                        # A real feed carries control rows. This extract had
                        # none, so the Test-only rule was never exercised
                        # against data that could break it.
                        if rnd.random() < 0.18:
                            w.writerow([c["name"], c["group"], comm, site,
                                        "REM%d" % stage, prog,
                                        date.strftime("%d-%b-%y"), "C",
                                        max(1, int(vol * rnd.uniform(0.05, 0.3)))])
                            rows += 1

    size = os.path.getsize(OUT) / (1024.0 * 1024.0)
    shapes = {}
    for c in clients:
        shapes[c["stages"]] = shapes.get(c["stages"], 0) + 1
    print("wrote %s" % OUT)
    print("  clients: %d   rows: %s   size: %.1f MB"
          % (len(clients), "{:,}".format(rows), size))
    print("  journey shapes: %s"
          % ", ".join("%d stage(s): %d clients" % (k, shapes[k])
                      for k in sorted(shapes)))
    print("  date span: %s -> %s"
          % (START, START + dt.timedelta(days=DAYS - 1)))


if __name__ == "__main__":
    main()
