"""Power Query (M) for every imported table in the CDP model.

Design notes
------------
One shared query, ``Source_CDP``, does all of the reading and cleaning. Every
table - fact and dimensions alike - derives from it, so a change to the parsing
rules can never leave a dimension describing a different population than the
fact it filters.

Nothing is discarded. Rows that fail a validation land in the fact table with
``DQ *`` flag columns set, which is what the Data Quality page counts. Silently
dropping them would make the dashboard reconcile against a source that no
longer matches the file on disk.

Column names are matched case-insensitively against a list of accepted aliases.
The supplied extract names the volume column ``email_counts`` while the
specification calls it ``Number of Email``; both are accepted and normalised to
``Number of Email`` so the documented DAX works verbatim against either drop.
"""

# --------------------------------------------------------------------------
# shared source
# --------------------------------------------------------------------------
SOURCE_CDP = r'''
let
    // p_SourceFilePath is the one thing that has to change when this project
    // moves to another machine. Power Query cannot resolve a path relative to
    // the report file, so the path stored here is absolute by necessity; the
    // default points at the copy bundled under Data\ on the machine that
    // generated the model.
    //
    // When it cannot be read the failure is raised deliberately, naming the
    // parameter and the menu path, because the native error is a bare
    // "file not found" that says nothing about which of a dozen queries broke
    // or how to fix it.
    Attempt = try File.Contents ( p_SourceFilePath ),
    Binary =
        if not Attempt[HasError] then
            Attempt[Value]
        else
            error Error.Record (
                "CDP source file not found",
                "Could not read: " & p_SourceFilePath,
                "Set p_SourceFilePath to this machine's copy of the extract: "
                    & "Home > Transform data (dropdown) > Edit parameters, "
                    & "then Home > Refresh. "
                    & "A copy of the extract ships with the project under "
                    & "the Data folder."
            ),

    Loaded = Csv.Document (
        Binary,
        [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv] ),
    Promoted = Table.PromoteHeaders ( Loaded, [PromoteAllScalars = true] ),
    TrimmedNames = Table.TransformColumnNames ( Promoted, each Text.Trim ( _ ) ),
    Names = Table.ColumnNames ( TrimmedNames ),

    // Accepted aliases per canonical column. Matching is case-insensitive so a
    // header cased differently in a later extract still binds.
    Aliases = {
        { "Client_name",     { "client_name", "clientname", "client" } },
        { "client_group",    { "client_group", "clientgroup", "client group" } },
        { "comm_code",       { "comm_code", "commcode", "comm code", "communication_code" } },
        { "site_code",       { "site_code", "sitecode", "site code" } },
        { "rem_flag",        { "rem_flag", "remflag", "rem flag", "reminder_flag" } },
        { "Program",         { "program" } },
        { "file_date",       { "file_date", "filedate", "file date" } },
        { "t_c_ind",         { "t_c_ind", "tcind", "t c ind", "t_c_indicator" } },
        { "Number of Email", { "number of email", "number_of_email", "email_counts",
                               "email counts", "emailcounts", "email_count" } }
    },
    FindColumn = ( wanted as list ) as nullable text =>
        List.First (
            List.Select ( Names, each List.Contains ( wanted, Text.Lower ( _ ) ) ),
            null ),
    RenamePairs = List.RemoveNulls ( List.Transform ( Aliases, each
        let found = FindColumn ( _{1} )
        in  if found = null or found = _{0} then null else { found, _{0} } ) ),
    Renamed = Table.RenameColumns ( TrimmedNames, RenamePairs, MissingField.Ignore ),

    // A canonical column absent from the file is created empty rather than
    // raising, so a partial extract still loads and is reported on the Data
    // Quality page instead of failing the refresh outright.
    Canonical = List.Transform ( Aliases, each _{0} ),
    Missing = List.Difference ( Canonical, Table.ColumnNames ( Renamed ) ),
    Filled = List.Accumulate ( Missing, Renamed,
        ( state, col ) => Table.AddColumn ( state, col, each null ) ),
    Kept = Table.SelectColumns ( Filled, Canonical ),

    // ---- text cleanup ----------------------------------------------------
    TextCols = { "Client_name", "client_group", "comm_code", "site_code",
                 "rem_flag", "Program", "t_c_ind" },
    CleanText = Table.TransformColumns ( Kept,
        List.Transform ( TextCols, each { _, ( v ) =>
            if v = null then null
            else
                let s = Text.Trim ( Text.Clean ( Text.From ( v ) ) )
                in  if s = "" then null else s,
            type nullable text } ) ),

    // ---- dates -----------------------------------------------------------
    // The extract ships dd-MMM-yy ("01-Aug-26"). The alternates cover the other
    // shapes this feed has been seen in; anything unparseable becomes null and
    // is flagged rather than guessed at.
    ParseDate = ( v ) as nullable date =>
        if v = null then null
        else if v is date then v
        else if v is datetime then Date.From ( v )
        else
            let s = Text.Trim ( Text.From ( v ) )
            in  if s = "" then null
                else
                    try Date.FromText ( s, [Format = "dd-MMM-yy",   Culture = "en-US"] )
                    otherwise try Date.FromText ( s, [Format = "dd-MMM-yyyy", Culture = "en-US"] )
                    otherwise try Date.FromText ( s, [Format = "yyyy-MM-dd",  Culture = "en-US"] )
                    otherwise try Date.FromText ( s, [Format = "MM/dd/yyyy",  Culture = "en-US"] )
                    otherwise try Date.From ( s, "en-US" )
                    otherwise null,
    WithDate = Table.TransformColumns ( CleanText,
        {{ "file_date", ParseDate, type nullable date }} ),

    // ---- volume ----------------------------------------------------------
    ParseNumber = ( v ) as nullable number =>
        if v = null then null
        else if v is number then v
        else
            let s = Text.Remove ( Text.Trim ( Text.From ( v ) ), { ",", " " } )
            in  if s = "" then null
                else try Number.From ( s, "en-US" ) otherwise null,
    WithNumber = Table.TransformColumns ( WithDate,
        {{ "Number of Email", ParseNumber, type nullable number }} ),

    // ---- validation ------------------------------------------------------
    // A reminder flag is well formed when it is REM followed by digits. The
    // stage number is read from those digits, so the model orders REM5 or REM10
    // correctly without anyone editing a mapping table.
    ReminderDigits = ( s ) as text =>
        if s = null then "" else Text.Select ( s, { "0" .. "9" } ),
    IsReminder = ( s ) as logical =>
        s <> null
        and Text.StartsWith ( Text.Upper ( s ), "REM" )
        and ReminderDigits ( s ) <> ""
        and Text.Upper ( s ) = "REM" & ReminderDigits ( s ),
    IsPopulation = ( s ) as logical =>
        s <> null and List.Contains ( { "T", "C" }, Text.Upper ( s ) ),

    F1 = Table.AddColumn ( WithNumber, "DQ Missing Client",
        each if [Client_name] = null then 1 else 0, Int64.Type ),
    F2 = Table.AddColumn ( F1, "DQ Missing Program",
        each if [Program] = null then 1 else 0, Int64.Type ),
    F3 = Table.AddColumn ( F2, "DQ Missing Reminder",
        each if [rem_flag] = null then 1 else 0, Int64.Type ),
    F4 = Table.AddColumn ( F3, "DQ Missing Date",
        each if [file_date] = null then 1 else 0, Int64.Type ),
    F5 = Table.AddColumn ( F4, "DQ Missing Volume",
        each if [Number of Email] = null then 1 else 0, Int64.Type ),
    F6 = Table.AddColumn ( F5, "DQ Negative Volume",
        each if [Number of Email] <> null and [Number of Email] < 0 then 1 else 0, Int64.Type ),
    F7 = Table.AddColumn ( F6, "DQ Invalid Population",
        each if IsPopulation ( [t_c_ind] ) then 0 else 1, Int64.Type ),
    Flags = Table.AddColumn ( F7, "DQ Invalid Reminder",
        each if [rem_flag] = null then 0
             else ( if IsReminder ( [rem_flag] ) then 0 else 1 ), Int64.Type ),

    // ---- duplicate detection on the business grain -----------------------
    GrainCols = { "Client_name", "client_group", "comm_code", "site_code",
                  "rem_flag", "Program", "file_date", "t_c_ind" },
    Counts = Table.Group ( Flags, GrainCols,
        {{ "DQ Grain Count", each Table.RowCount ( _ ), Int64.Type }} ),
    JoinedCounts = Table.NestedJoin ( Flags, GrainCols, Counts, GrainCols,
        "__grain", JoinKind.LeftOuter ),
    ExpandedCounts = Table.ExpandTableColumn ( JoinedCounts, "__grain",
        { "DQ Grain Count" }, { "DQ Grain Count" } ),
    WithDuplicate = Table.AddColumn ( ExpandedCounts, "DQ Duplicate Row",
        each if [DQ Grain Count] > 1 then 1 else 0, Int64.Type ),

    Issues = Table.AddColumn ( WithDuplicate, "DQ Issue Count", each
        [DQ Missing Client] + [DQ Missing Program] + [DQ Missing Reminder]
        + [DQ Missing Date] + [DQ Missing Volume] + [DQ Negative Volume]
        + [DQ Invalid Population] + [DQ Invalid Reminder] + [DQ Duplicate Row],
        Int64.Type ),
    Status = Table.AddColumn ( Issues, "Row Status",
        each if [DQ Issue Count] = 0 then "OK" else "Review", type text ),

    Typed = Table.TransformColumnTypes ( Status, {
        { "Client_name", type text }, { "client_group", type text },
        { "comm_code", type text }, { "site_code", type text },
        { "rem_flag", type text }, { "Program", type text },
        { "file_date", type date }, { "t_c_ind", type text },
        { "Number of Email", type number } } )
in
    Typed
'''

# --------------------------------------------------------------------------
# fact
# --------------------------------------------------------------------------
FACT = r'''
let
    // The fact is the cleaned source verbatim: every row that was in the file
    // is here, valid or not, so totals reconcile against the CSV exactly.
    Source = Source_CDP,
    Ordered = Table.SelectColumns ( Source, {
        "Client_name", "client_group", "comm_code", "site_code", "rem_flag",
        "Program", "file_date", "t_c_ind", "Number of Email",
        "DQ Missing Client", "DQ Missing Program", "DQ Missing Reminder",
        "DQ Missing Date", "DQ Missing Volume", "DQ Negative Volume",
        "DQ Invalid Population", "DQ Invalid Reminder", "DQ Duplicate Row",
        "DQ Issue Count", "Row Status" } )
in
    Ordered
'''

# --------------------------------------------------------------------------
# dimensions
# --------------------------------------------------------------------------
DIM_REMINDER = r'''
let
    // Stage order and display name are derived from the digits in rem_flag, not
    // from a hard-coded REM1..REM4 mapping. A future REM5 sorts and labels
    // itself; an unparseable flag sorts last rather than silently taking slot 1.
    Source = Table.SelectColumns ( Source_CDP, { "rem_flag" } ),
    Present = Table.SelectRows ( Source, each [rem_flag] <> null ),
    Distinct = Table.Distinct ( Present ),
    Digits = Table.AddColumn ( Distinct, "__d",
        each Text.Select ( [rem_flag], { "0" .. "9" } ), type text ),
    WithOrder = Table.AddColumn ( Digits, "Reminder Order",
        each if [__d] = "" then 9999 else Number.From ( [__d] ), Int64.Type ),
    WithName = Table.AddColumn ( WithOrder, "Reminder Display Name",
        each if [__d] = "" then [rem_flag] else "Reminder " & [__d], type text ),
    WithShort = Table.AddColumn ( WithName, "Reminder Short Name",
        each if [__d] = "" then [rem_flag] else "REM" & [__d], type text ),
    WithStage = Table.AddColumn ( WithShort, "Stage Label",
        each if [__d] = "" then [rem_flag] else "Stage " & [__d], type text ),
    Cleaned = Table.RemoveColumns ( WithStage, { "__d" } ),
    Sorted = Table.Sort ( Cleaned, {{ "Reminder Order", Order.Ascending }} ),
    Typed = Table.TransformColumnTypes ( Sorted,
        {{ "rem_flag", type text }} )
in
    Typed
'''

DIM_CLIENT = r'''
let
    // Keyed on Client_name because that is what the fact joins on. client_group
    // is carried as an attribute; if a client ever legitimately spans more than
    // one group the groups are listed rather than one being silently chosen,
    // and Dim_ClientGroup still filters the fact on the true source value.
    Source = Table.SelectColumns ( Source_CDP, { "Client_name", "client_group" } ),
    Present = Table.SelectRows ( Source, each [Client_name] <> null ),
    Pairs = Table.Distinct ( Present ),
    Grouped = Table.Group ( Pairs, { "Client_name" }, {
        { "Client Group", each Text.Combine (
            List.Sort ( List.RemoveNulls ( _[client_group] ) ), " / " ), type text },
        { "Client Group Count", each List.Count (
            List.Distinct ( List.RemoveNulls ( _[client_group] ) ) ), Int64.Type } } ),
    Sorted = Table.Sort ( Grouped, {{ "Client_name", Order.Ascending }} ),
    Typed = Table.TransformColumnTypes ( Sorted, {{ "Client_name", type text }} )
in
    Typed
'''

DIM_CLIENT_GROUP = r'''
let
    Source = Table.SelectColumns ( Source_CDP, { "client_group" } ),
    Present = Table.SelectRows ( Source, each [client_group] <> null ),
    Distinct = Table.Distinct ( Present ),
    Sorted = Table.Sort ( Distinct, {{ "client_group", Order.Ascending }} ),
    Typed = Table.TransformColumnTypes ( Sorted, {{ "client_group", type text }} )
in
    Typed
'''

DIM_PROGRAM = r'''
let
    Source = Table.SelectColumns ( Source_CDP, { "Program" } ),
    Present = Table.SelectRows ( Source, each [Program] <> null ),
    Distinct = Table.Distinct ( Present ),
    Sorted = Table.Sort ( Distinct, {{ "Program", Order.Ascending }} ),
    Typed = Table.TransformColumnTypes ( Sorted, {{ "Program", type text }} )
in
    Typed
'''

DIM_COMMCODE = r'''
let
    // No descriptions are invented for a communication code. The only derived
    // attribute is the code's own prefix, which groups the creative families
    // that already exist in the data.
    Source = Table.SelectColumns ( Source_CDP, { "comm_code" } ),
    Present = Table.SelectRows ( Source, each [comm_code] <> null ),
    Distinct = Table.Distinct ( Present ),
    WithFamily = Table.AddColumn ( Distinct, "Creative Family",
        each if Text.Length ( [comm_code] ) >= 3 then Text.Start ( [comm_code], 3 )
             else [comm_code], type text ),
    Sorted = Table.Sort ( WithFamily, {{ "comm_code", Order.Ascending }} ),
    Typed = Table.TransformColumnTypes ( Sorted, {{ "comm_code", type text }} )
in
    Typed
'''

DIM_SITE = r'''
let
    Source = Table.SelectColumns ( Source_CDP, { "site_code" } ),
    Present = Table.SelectRows ( Source, each [site_code] <> null ),
    Distinct = Table.Distinct ( Present ),
    Sorted = Table.Sort ( Distinct, {{ "site_code", Order.Ascending }} ),
    Typed = Table.TransformColumnTypes ( Sorted, {{ "site_code", type text }} )
in
    Typed
'''

DIM_POPULATION = r'''
let
    // T and C are the documented business codes, so both members always exist
    // even when a given extract contains only one of them - a slicer that
    // silently loses Control would hide the fact that no control was mailed.
    // Any code that is neither is appended so it is visible rather than lost.
    Known = #table (
        type table [
            t_c_ind = text,
            Population = text,
            #"Receives Email" = text,
            #"Population Order" = Int64.Type ],
        { { "T", "Test", "Yes", 1 },
          { "C", "Control", "No", 2 } } ),
    Found = List.Distinct ( List.RemoveNulls ( Source_CDP[t_c_ind] ) ),
    Unexpected = List.Difference ( Found, Known[t_c_ind] ),
    Extra = Table.FromList ( Unexpected, Splitter.SplitByNothing (),
        { "t_c_ind" }, null, ExtraValues.Error ),
    ExtraTyped = Table.TransformColumnTypes ( Extra, {{ "t_c_ind", type text }} ),
    E1 = Table.AddColumn ( ExtraTyped, "Population",
        each "Unexpected (" & [t_c_ind] & ")", type text ),
    E2 = Table.AddColumn ( E1, "Receives Email", each "Unknown", type text ),
    ExtraFull = Table.AddColumn ( E2, "Population Order", each 9, Int64.Type ),
    Combined = Table.Combine ( { Known, ExtraFull } ),
    Sorted = Table.Sort ( Combined, {{ "Population Order", Order.Ascending }} )
in
    Sorted
'''

# --------------------------------------------------------------------------
# calculated tables
# --------------------------------------------------------------------------
DIM_DATE = r'''
-- The calendar spans exactly the loaded data, rounded out to whole months so
-- month slicers are not left with a partial first or last bucket. It extends
-- automatically as new days arrive; nothing here is pinned to a literal date.
VAR _min = CALCULATE ( MIN ( 'Fact_ReminderVolume'[file_date] ), ALL ( 'Fact_ReminderVolume' ) )
VAR _max = CALCULATE ( MAX ( 'Fact_ReminderVolume'[file_date] ), ALL ( 'Fact_ReminderVolume' ) )
VAR _from = IF ( ISBLANK ( _min ), DATE ( 2020, 1, 1 ), DATE ( YEAR ( _min ), MONTH ( _min ), 1 ) )
VAR _to   = IF ( ISBLANK ( _max ), DATE ( 2020, 12, 31 ), EOMONTH ( _max, 0 ) )
RETURN
    ADDCOLUMNS (
        CALENDAR ( _from, _to ),
        "Year",           YEAR ( [Date] ),
        "Quarter Number", QUARTER ( [Date] ),
        "Quarter",        "Q" & QUARTER ( [Date] ),
        "Month Number",   MONTH ( [Date] ),
        "Month",          FORMAT ( [Date], "mmmm" ),
        "Month Short",    FORMAT ( [Date], "mmm" ),
        "Month Year",     FORMAT ( [Date], "mmm yyyy" ),
        "Month Year Sort", YEAR ( [Date] ) * 100 + MONTH ( [Date] ),
        "Week Number",    WEEKNUM ( [Date], 21 ),
        "Year-Week",      FORMAT ( YEAR ( [Date] ), "0000" ) & "-W" & FORMAT ( WEEKNUM ( [Date], 21 ), "00" ),
        "Year-Week Sort", YEAR ( [Date] ) * 100 + WEEKNUM ( [Date], 21 ),
        -- A real date for the Monday of each week. A weekly chart needs a
        -- scalar axis to space its points by time and thin its own labels;
        -- with the text "Year-Week" on a categorical axis, 78 weeks printed
        -- 78 labels, truncated every one of them to "20..." and then grew a
        -- scrollbar.
        "Week Start",     [Date] - WEEKDAY ( [Date], 2 ) + 1,
        "Day",            DAY ( [Date] ),
        "Day Name",       FORMAT ( [Date], "dddd" ),
        "Day Name Short", FORMAT ( [Date], "ddd" ),
        "Day Name Number", WEEKDAY ( [Date], 2 ),
        "Day Label",      FORMAT ( [Date], "dd mmm" ),
        "Is Weekend",     WEEKDAY ( [Date], 2 ) >= 6
    )
'''

MEASURE_HOME = 'ROW ( "_", "" )'
