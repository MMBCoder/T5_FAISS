# -*- coding: utf-8 -*-
"""Structural validation of the generated PBIP.

Checks the things that make Power BI Desktop open a project and then show
nothing, or show a visual with a red error triangle - all of which are silent
until someone opens the file:

  * every measure and column a visual binds to exists in the semantic model
  * every navigation button points at a page that exists
  * every relationship names real tables and columns
  * every sortByColumn and drill-through field resolves
  * the legacy report.json Desktop reads carries the same visuals as the PBIR
    it was lowered from, and kept the drill-through page filters

Run: python tools/validate_project.py
"""
import glob
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT = "CDP_Reminder_Volume_Dashboard"
MODEL_DEF = os.path.join(ROOT, PROJECT + ".SemanticModel", "definition")
TABLES = os.path.join(MODEL_DEF, "tables")
PBIR_DEF = os.path.join(ROOT, "build", "pbir", "definition")
REPORT_DIR = os.path.join(ROOT, PROJECT + ".Report")
LEGACY = os.path.join(REPORT_DIR, "report.json")

ERRORS = []
NOTES = []


def fail(msg):
    ERRORS.append(msg)


# --------------------------------------------------------------------------
# model inventory, parsed straight out of the TMDL
# --------------------------------------------------------------------------
def model_inventory():
    tables, columns, measures, sort_refs = set(), {}, set(), []
    for path in sorted(glob.glob(os.path.join(TABLES, "*.tmdl"))):
        text = open(path, encoding="utf-8").read()
        m = re.search(r"^table\s+('([^']+)'|(\S+))", text, re.M)
        if not m:
            fail("no table declaration in %s" % os.path.basename(path))
            continue
        tname = m.group(2) or m.group(3)
        tables.add(tname)
        columns[tname] = set()
        current = None
        for line in text.splitlines():
            cm = re.match(r"^\tcolumn\s+('([^']+)'|(\S+))\s*$", line)
            if cm:
                current = cm.group(2) or cm.group(3)
                columns[tname].add(current)
                continue
            mm = re.match(r"^\tmeasure\s+('([^']+)'|([^\s=]+))\s*=", line)
            if mm:
                measures.add(mm.group(2) or mm.group(3))
                current = None
                continue
            sm = re.match(r"^\t\tsortByColumn:\s*('([^']+)'|(\S+))\s*$", line)
            if sm and current:
                sort_refs.append((tname, current, sm.group(2) or sm.group(3)))
    return tables, columns, measures, sort_refs


def check_relationships(tables, columns):
    path = os.path.join(MODEL_DEF, "relationships.tmdl")
    text = open(path, encoding="utf-8").read()
    n = 0
    for m in re.finditer(r"^\t(fromColumn|toColumn):\s*(.+)$", text, re.M):
        ref = m.group(2).strip()
        parts = re.match(r"^('([^']+)'|([^.]+))\.('([^']+)'|(.+))$", ref)
        if not parts:
            fail("unparseable relationship endpoint: %s" % ref)
            continue
        t = parts.group(2) or parts.group(3)
        c = parts.group(5) or parts.group(6)
        n += 1
        if t not in tables:
            fail("relationship references unknown table %s" % t)
        elif c not in columns[t]:
            fail("relationship references unknown column %s[%s]" % (t, c))
    NOTES.append("relationship endpoints checked: %d" % n)


# --------------------------------------------------------------------------
# report references
# --------------------------------------------------------------------------
def walk(node, out):
    """Collect every Measure / Column expression anywhere in a visual."""
    if isinstance(node, dict):
        for kind in ("Measure", "Column", "HierarchyLevel"):
            spec = node.get(kind)
            if isinstance(spec, dict):
                ent = spec.get("Expression", {}).get("SourceRef", {}).get("Entity")
                prop = spec.get("Property")
                if ent and prop:
                    out.add((kind, ent, prop))
        for v in node.values():
            walk(v, out)
    elif isinstance(node, list):
        for v in node:
            walk(v, out)


def check_report(tables, columns, measures):
    page_names, refs, nav_targets = set(), set(), []
    pages_meta = json.load(open(os.path.join(PBIR_DEF, "pages", "pages.json"),
                                encoding="utf-8"))
    n_vis = 0
    drill_pages = []
    layouts = {}
    for pdir in sorted(glob.glob(os.path.join(PBIR_DEF, "pages", "*"))):
        pj = os.path.join(pdir, "page.json")
        if not os.path.isfile(pj):
            continue
        pdoc = json.load(open(pj, encoding="utf-8"))
        page_names.add(pdoc["name"])
        if pdoc.get("type") == "Drillthrough":
            drill_pages.append(pdoc["name"])
            walk(pdoc.get("filterConfig"), refs)
            binding = pdoc.get("pageBinding") or {}
            fnames = {f.get("name") for f in
                      (pdoc.get("filterConfig") or {}).get("filters", [])}
            for prm in binding.get("parameters", []):
                if prm.get("boundFilter") not in fnames:
                    fail("%s: drill-through binding names filter %r which the "
                         "page does not declare"
                         % (pdoc["name"], prm.get("boundFilter")))
        for vp in sorted(glob.glob(os.path.join(pdir, "visuals", "*",
                                                "visual.json"))):
            vdoc = json.load(open(vp, encoding="utf-8"))
            n_vis += 1
            layouts.setdefault(pdoc["name"], []).append(vdoc)
            walk(vdoc, refs)
            link = ((vdoc.get("visual") or {})
                    .get("visualContainerObjects") or {}).get("visualLink")
            for entry in (link or []):
                props = entry.get("properties", {})
                if props.get("type", {}).get("expr", {}).get(
                        "Literal", {}).get("Value") == "'PageNavigation'":
                    target = props.get("navigationSection", {}).get(
                        "expr", {}).get("Literal", {}).get("Value", "")
                    nav_targets.append((vdoc["name"], target.strip("'")))

    for name, target in nav_targets:
        if target not in page_names:
            fail("navigation button %s points at missing page %r"
                 % (name, target))

    for kind, ent, prop in sorted(refs):
        if kind == "Measure":
            if prop not in measures:
                fail("visual binds to missing measure [%s] (entity %s)"
                     % (prop, ent))
        else:
            if ent not in tables:
                fail("visual binds to missing table %s" % ent)
            elif prop not in columns[ent]:
                fail("visual binds to missing column %s[%s]" % (ent, prop))

    for p in pages_meta.get("pageOrder", []):
        if p not in page_names:
            fail("pages.json orders unknown page %r" % p)

    check_bounds(layouts)
    check_overlaps(layouts)

    NOTES.append("pages: %d   visuals: %d   distinct field bindings: %d"
                 % (len(page_names), n_vis, len(refs)))
    NOTES.append("drill-through pages: %s" % (", ".join(drill_pages) or "none"))
    return page_names, drill_pages


# Background surfaces are laid down at z = 0 and everything else is composed on
# top of them. Two visuals that both carry content and still overlap is always a
# layout mistake - it is how an empty banner ended up painting itself across the
# KPI row, which nothing but a screenshot would otherwise have caught.
BACKGROUND_Z = 0


PAGE_W, PAGE_H = 1440, 810


def check_bounds(layouts):
    n = 0
    for pname, docs in sorted(layouts.items()):
        for d in docs:
            pos = d.get("position") or {}
            r = pos.get("x", 0) + pos.get("width", 0)
            b = pos.get("y", 0) + pos.get("height", 0)
            if r > PAGE_W + 0.5 or b > PAGE_H + 0.5:
                n += 1
                fail("%s: %s runs off the canvas (right=%.0f bottom=%.0f, "
                     "page is %dx%d)" % (pname, d["name"], r, b, PAGE_W, PAGE_H))
    NOTES.append("canvas bounds check: %d overflow(s)" % n)


def check_overlaps(layouts):
    n = 0
    for pname, docs in sorted(layouts.items()):
        boxes = []
        for d in docs:
            pos = d.get("position") or {}
            if pos.get("z", 0) == BACKGROUND_Z:
                continue
            boxes.append((d["name"], pos.get("x", 0), pos.get("y", 0),
                          pos.get("width", 0), pos.get("height", 0)))
        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                an, ax, ay, aw, ah = boxes[i]
                bn, bx, by, bw, bh = boxes[j]
                ox = min(ax + aw, bx + bw) - max(ax, bx)
                oy = min(ay + ah, by + bh) - max(ay, by)
                if ox > 1 and oy > 1:
                    n += 1
                    fail("%s: %s and %s overlap by %dx%d px"
                         % (pname, an, bn, ox, oy))
    NOTES.append("visual overlap check: %d collision(s)" % n)


def check_theme():
    """The custom theme has to survive the lowering to legacy.

    It did not: the converter wrote an empty themeCollection and no resource
    package, so Desktop fell back to its default Classic palette and every
    series colour in the report was wrong - silently, with nothing to see but
    charts in the wrong colours.
    """
    if not os.path.isfile(LEGACY):
        return
    doc = json.load(open(LEGACY, encoding="utf-8"))
    cfg = json.loads(doc.get("config", "{}"))
    theme = (cfg.get("themeCollection") or {}).get("customTheme") or {}
    name = theme.get("name")
    if not name:
        fail("legacy report.json declares no custom theme - Desktop will use "
             "its default palette and every series colour will be wrong")
        return
    paths = []
    for rp in doc.get("resourcePackages") or []:
        pkg = rp.get("resourcePackage") or {}
        for item in pkg.get("items") or []:
            paths.append(item.get("name"))
    if name not in paths:
        fail("custom theme %r is declared but not registered in "
             "resourcePackages" % name)
        return
    on_disk = os.path.join(REPORT_DIR, "StaticResources", "RegisteredResources",
                           name + ".json")
    if not os.path.isfile(on_disk):
        fail("custom theme %r is registered but %s does not exist"
             % (name, on_disk))
        return
    NOTES.append("custom theme: %s registered and present" % name)


def check_legacy(page_names, drill_pages):
    if not os.path.isfile(LEGACY):
        fail("legacy report.json was not written")
        return
    doc = json.load(open(LEGACY, encoding="utf-8"))
    sections = doc.get("sections", [])
    names = [s["name"] for s in sections]
    missing = page_names - set(names)
    if missing:
        fail("legacy report.json is missing pages: %s" % ", ".join(sorted(missing)))
    total = 0
    for s in sections:
        total += len(s.get("visualContainers", []))
        for vc in s["visualContainers"]:
            cfg = json.loads(vc["config"])
            sv = cfg.get("singleVisual", {})
            if not sv.get("visualType"):
                fail("%s: visual %s lost its visualType in conversion"
                     % (s["name"], cfg.get("name")))
            # A prototypeQuery Select is keyed by Name. Two entries sharing one
            # Name - which happens the moment a measure appears on both Y and
            # Tooltips - makes the query unresolvable, and Desktop then draws an
            # empty frame with no error at all. Caught here because it is
            # invisible everywhere else.
            proto = sv.get("prototypeQuery")
            if proto:
                names = [e.get("Name") for e in proto.get("Select", [])]
                dupes = sorted({n for n in names if names.count(n) > 1})
                if dupes:
                    fail("%s: visual %s has duplicate prototypeQuery Select "
                         "names %s - it would render empty"
                         % (s["name"], cfg.get("name"), ", ".join(dupes)))
                refs = set(names)
                for role, entries in (sv.get("projections") or {}).items():
                    for e in entries:
                        if e.get("queryRef") not in refs:
                            fail("%s: visual %s projection %s references "
                                 "queryRef %r that the prototypeQuery does not "
                                 "select" % (s["name"], cfg.get("name"), role,
                                             e.get("queryRef")))
        if s["name"] in drill_pages:
            flt = json.loads(s.get("filters") or "[]")
            if not any(f.get("howCreated") == 2 for f in flt):
                fail("%s is a drill-through target but the legacy section "
                     "carries no Drillthrough filter - right-click drill would "
                     "not be offered" % s["name"])
    NOTES.append("legacy sections: %d   legacy visuals: %d" % (len(sections), total))


def check_pbip():
    for rel in [PROJECT + ".pbip",
                PROJECT + ".Report/definition.pbir",
                PROJECT + ".Report/.platform",
                PROJECT + ".Report/report.json",
                PROJECT + ".SemanticModel/definition.pbism",
                PROJECT + ".SemanticModel/.platform",
                PROJECT + ".SemanticModel/definition/model.tmdl",
                PROJECT + ".SemanticModel/definition/database.tmdl",
                PROJECT + ".SemanticModel/definition/expressions.tmdl",
                PROJECT + ".SemanticModel/definition/relationships.tmdl",
                "Data/CDP_Projects_Summary_History.csv"]:
        if not os.path.exists(os.path.join(ROOT, rel)):
            fail("missing project file: %s" % rel)
    pbip = json.load(open(os.path.join(ROOT, PROJECT + ".pbip"),
                          encoding="utf-8"))
    if pbip["artifacts"][0]["report"]["path"] != PROJECT + ".Report":
        fail(".pbip does not point at the report folder")
    pbir = json.load(open(os.path.join(ROOT, PROJECT + ".Report",
                                       "definition.pbir"), encoding="utf-8"))
    ref = pbir["datasetReference"]["byPath"]["path"]
    if not os.path.isdir(os.path.join(ROOT, PROJECT + ".Report", ref)):
        fail("report points at a semantic model folder that does not exist: %s"
             % ref)


def check_model_refs(tables, columns, measures, sort_refs):
    """Every [Measure] and Table[Column] used inside DAX must resolve."""
    n = 0
    for path in sorted(glob.glob(os.path.join(TABLES, "*.tmdl"))):
        text = open(path, encoding="utf-8").read()
        # Power Query partitions are M, not DAX: [__d] is a step reference and
        # [Number of Email] is a field access, neither of which resolves against
        # the model the way a DAX reference does. Scanning them here produced
        # nothing but false positives, so they are excised first.
        text = re.sub(r"\n\tpartition [^\n]*= m\n.*?(?=\n\tannotation PBI_Id)",
                      "", text, flags=re.S)
        for t, c in re.findall(r"'([A-Za-z_][^']*)'\[([^\]]+)\]", text):
            n += 1
            if t not in tables:
                fail("%s: DAX references unknown table '%s'"
                     % (os.path.basename(path), t))
            elif c not in columns[t] and c not in measures:
                fail("%s: DAX references unknown column '%s'[%s]"
                     % (os.path.basename(path), t, c))
        # bare [Name] references: a measure, an extension column, or a column
        # of the table the expression already sits in
        own = os.path.basename(path)[:-5]
        for name in re.findall(r"(?<![\w'\]])\[([^\[\]]+)\]", text):
            if name.startswith("@") or name.startswith("#"):
                continue
            n += 1
            if (name not in measures and name not in columns.get(own, set())
                    and not any(name in cs for cs in columns.values())):
                fail("%s: DAX references unknown name [%s]" % (own, name))
    for t, c, target in sort_refs:
        if target not in columns[t]:
            fail("%s[%s] sorts by missing column %s" % (t, c, target))
    NOTES.append("model DAX references checked: %d" % n)
    NOTES.append("tables: %d   columns: %d   measures: %d"
                 % (len(tables), sum(len(c) for c in columns.values()),
                    len(measures)))


def main():
    tables, columns, measures, sort_refs = model_inventory()
    check_relationships(tables, columns)
    check_model_refs(tables, columns, measures, sort_refs)
    page_names, drill_pages = check_report(tables, columns, measures)
    check_legacy(page_names, drill_pages)
    check_theme()
    check_pbip()

    print("=" * 72)
    for n in NOTES:
        print("  %s" % n)
    print("=" * 72)
    if ERRORS:
        print("VALIDATION FAILED - %d problem(s):" % len(ERRORS))
        for e in ERRORS:
            print("  ! %s" % e)
        return 1
    print("VALIDATION PASSED - project structure is internally consistent")
    return 0


if __name__ == "__main__":
    sys.exit(main())
