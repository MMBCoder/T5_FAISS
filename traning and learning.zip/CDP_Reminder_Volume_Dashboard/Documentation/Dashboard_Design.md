# Dashboard Design

## The story the report tells

Five pages, in order, each answering one question. The order is the argument:

| # | Page | Question it answers | Accent |
|---|---|---|---|
| 1 | Volume Tracking | How much are we sending, and what does the journey look like? | Teal |
| 2 | Reminder Journey | Which stage carries the volume, and how do the stages move against each other? | Steel |
| 3 | Drivers | Which client, program and creative drive it? | Clay |
| 4 | Daily Operations | Show me the actual rows behind the numbers | Gold |
| 5 | Records & Quality | What are the underlying rows, and can I trust them? | Slate |

Read top to bottom, that is: **how much → where in the sequence → who drives it →
what changed → show me the rows**.

### Why five and not nine

An earlier cut had nine pages. Three of them - Client Analysis, Program Analysis
and Creative Analysis - were the same three visuals with one field swapped, and
two more were drill-through pages that repeated the executive page almost
exactly. That is a report which *feels* large and *reads* small: the reader has
to work out what is different about each page before they can use it.

The three ranking pages are now one row of three ranking charts on page 3, where
they can actually be compared with each other. The two drill-through pages are
gone; page 3 is itself the drill-through target for both client and program. The
client and program contribution charts were removed from page 1 for the same
reason - they are the whole subject of page 3.

## Page by page

### 1. Volume Tracking

- **Six KPI tiles** - total volume, latest day with its day-over-day movement,
  average per active day, clients, programs, active reminder stages.
- **The reminder journey band** - the report's signature visual. Four stage
  slots and three connectors, all measure-driven, described below.
- **Daily volume trend** with a dynamic title naming the current client
  selection, and **reminder distribution** as columns.
- **Four dynamic insight sentences**, each computed from the current selection.

### 2. Reminder Journey

- Four KPI tiles including the journey written out as a path.
- **Stage mix by client** - 100% stacked columns. Deliberately not the journey
  band from page 1: it answers the different question of the *shape* of each
  client's journey rather than the *size* of the whole one. A one-stage journey
  shows a single full-height band, which makes the point immediately.
- **Volume by stage** in stage order.
- **Weekly volume by reminder stage** - one line per stage present.
- **Stage-to-stage detail** with volume movement against the previous stage that
  actually exists in that journey.

### 3. Drivers

- Four KPI tiles with insight captions.
- **Three ranking charts side by side** - by client, by program, by creative -
  each with its own drill-down hierarchy.
- **Weekly volume by client**.
- **The full matrix**: Client → Program → Reminder → Creative.

This page is the drill-through target for `Dim_Client[Client_name]` and
`Dim_Program[Program]`.

### 4. Daily Operations

One table, the full page: every loaded record at source grain - one row per
client, group, creative, site, stage, program, date and T/C indicator - newest
first, with the row count, the Test-only volume and the raw T+C volume. No
tiles, no charts, no commentary. This is the page to come to when the question
is *show me the actual rows behind that number*.

Every column on it is a dimension column or a plain sum, which is what lets it
hold at 100k rows. The trailing-baseline and exception-status measures are
deliberately absent: evaluating a 14-day window per source row is what made an
earlier version of this table render as an empty panel at scale.

**Exporting from this page.** Power BI has no scriptable download action - a
button can navigate, bookmark, drill through or open a URL, and nothing else -
so the export is the visual's own. The table is the one visual in the report
whose header is left visible, because *Export data* lives in that header's
overflow menu, and a caption under it says so in words. The report also
declares `exportDataMode` so underlying rows are offered and not just the
summarised view; that setting had been written into the PBIR definition all
along and silently dropped on the way down to the legacy format.

The in-visual export is capped at 30,000 rows for CSV and truncates without
saying so, which at production size is worse than refusing. The caption
therefore prints the live row count beside the cap, and
`tools/export_raw_csv.ps1` runs a single DAX query against the open model and
streams every row out with no limit.

> The exception-detection visuals - the daily volume against its trailing
> baseline, the weekly heatmap and the exception-day tile - used to live here
> and were removed when the page became records-only. The anomaly measures are
> still in the model and still documented below; nothing on a page reads them
> now. If watching for exceptions matters, that band is worth restoring, on
> this page or page 1.

### 5. Records & Quality

- Six KPI tiles reconciling rows and volume.
- **Nine validation check tiles**, one per rule.
- **The raw extract** - one row per client, group, creative, site, stage,
  program, date and population, with Test-only volume and the raw column sum
  side by side.

## The reminder journey band

The most important behaviour in the report. Not every client and program runs
four reminders, and a dashboard that renders an empty `REM4` is lying about the
journey.

Each of the four slots is built from four cards - stage label, value, share
caption and latest-day caption - plus a connector card between consecutive
slots. Every one of them is bound to a measure that returns an **empty string**
when the stage is not part of the current journey, so the slot and its incoming
connector disappear completely. A one-stage journey renders as one stage, with
no gap and no dangling arrow.

Three cases, kept distinct:

| Situation | What the card shows |
|---|---|
| Stage is not part of this journey | nothing - the slot collapses |
| Stage exists but had no volume in the selected period | `0`, with the caption *No volume in the selected period* |
| Stage exists and has volume | the volume, its share, its latest day and day-over-day movement |

The distinction comes from `REMn In Journey`, which evaluates membership with
the **date filter removed**. Which stages a journey has is a property of the
journey, not of the window being looked at.

> A card bound to a measure returning `BLANK` does not render nothing - it
> renders the literal text `(Blank)`. Every measure feeding a journey card
> therefore returns an empty string instead. This is why the journey values are
> text measures (`REMn Journey Value`) rather than numeric ones.

The extract exercises all the shapes: Ashley Advantage runs one stage,
CITY Furniture three, BrandsMart four.

## Filters

Seven slicers on every page, all synced, so a selection survives navigation:
Client, Client Group, Program, Reminder, Creative / Comm Code, Site, T_C_IND.
Plus one **Between** date-range slicer in the header, also synced.

The last slicer is labelled **T_C_IND**, after the source column it filters,
not "Population". The word was doing two jobs in this report - the Test/Control
indicator, and the record counts `[Test Population]` and `[Control Population]`
- and a filter called Population sitting next to a measure called Test
Population invites exactly the wrong reading. T_C_IND filters; Population
counts.

**T_C_IND defaults to Test**, because Test is the population that receives
email.

Everything on the page responds to all of them: KPI tiles, the journey band,
trends, rankings, matrices and detail tables all read from the same filter
context. There are no disconnected visuals.

### Selecting Control

`[Email Volume]` filters the fact to `t_c_ind = "T"`. Selecting Control in the
population slicer intersects that selection with the `T` filter, so email volume
is correctly **blank**. A banner then appears in the header strip:

> CONTROL POPULATION — NO EMAILS SENT. Email volume is blank because control
> records do not receive email.

Population counts still work under a Control selection, which is the point of
keeping Control in the model.

## Dates

`Latest Available Date` is the latest date carrying Test data **inside the
current filter context**, not the dataset maximum. Narrow the date slicer and
every latest-day figure follows.

`Previous Available Date` finds the previous date that actually holds data. The
feed has gaps - 91 distinct dates across a 142-day window - so with 10, 11 and
13 loaded, the previous day for the 13th is the 11th, not the 12th. When there
is no previous day with data in range, the movement caption reads `N/A` rather
than a misleading 0%.

`Average Daily Volume` divides by days that carry data, never by calendar days.
Missing dates are not treated as zero-volume days.

## Anomaly method

Transparent and explainable, deliberately not a model:

- **Baseline** - the mean of the **14 most recent days with data** before the
  day being evaluated. Trailing, not centred, so a day's status never changes
  when later days arrive. Blank until at least five prior days exist.
- **Spread** - the population standard deviation over the same window.
- **Status** - `High` above baseline + 2 SD, `Low` below baseline − 2 SD,
  otherwise `Normal`; `Baseline forming` while there is too little history.

The thresholds are stated on the page itself, not buried here.

## Visual identity

The report is a **light, printed editorial page**, deliberately not a dark
instrument panel. That choice is the point: the IDR monitoring report is a dark
navy console, and two reports that share a generator should not also share a
face. Someone glancing at a screen from across a room should know which of the
two they are looking at before they can read a number.

| | This report | The IDR console |
|---|---|---|
| Canvas | warm paper `#F3F0E9` | dark navy `#0A0E17` |
| Cards | white, square, hairline rule | dark, rounded, floating |
| Header | one inverted deep-pine masthead | dark band on a dark page |
| Identity mark | accent spine, chapter badge, lit nav pill | full-bleed accent rule |
| Accents | teal, steel, clay, gold | electric blue, cyan, purple, amber |

### The masthead

One deep-pine band across the top holds the chapter mark, the title, the volume
rule, the five navigation pills and all eight filters.

The strapline under the title is not a description of the page - it is the rule
that governs every number in the report: *Email Volume = Test (T) records only.
Control (C) is population, never a send.* It used to be a banner in a strip of
its own, and the per-page strapline that sat here was decorative prose
repeating the chapter caption. A reader who misses the volume rule misreads
every figure on the page, so it takes the permanent position.

The chapter caption and the title share a single container. Two textboxes each
pay the renderer's own 16px of vertical padding, and that difference alone was
enough to push both into scrollbars and cut them in half. Separating the controls from the paper
this sharply means the body of every page is nothing but data - no chrome
competes with it - and it is the silhouette that distinguishes the report
before any colour is read.

The page's identity is carried by three marks, never by a full-bleed rule:

- the **accent spine** down the left edge of the whole page, running through
  both the masthead and the paper;
- the **chapter badge**, a solid accent square holding the page number - the
  report's only decorative geometry, and the thing the eye lands on first;
- the one **lit navigation pill**.

Filters are wells cut into the pine rather than light tiles laid on it. Seven
white boxes across a dark band read as seven buttons, and the masthead stops
being a header and starts competing with the page.

### The body

Everything below the masthead is white or nothing. Cards are square with a
`#DBD4C4` hairline; bands are opened by a tracked accent label alone, not by
boxing each panel.

There is deliberately no hairline rule under those labels. Power BI enforces a
minimum rendered height on a visual container, so a 1px "rule" came out as an
11px grey slab lying across the heading - which is what made the section
headings look like they were overlapping something. Two surfaces are tinted, and only two: the
reminder journey band, because it is the report's signature visual, and the
narrative strip, because it reads as prose and should look like a pull-quote
rather than another row of tiles.

Each KPI tile carries a 4px accent bar down its left edge. The bar is a
separate visual rather than a tint on the tile, so the number still sits on
plain white - eight tinted tiles in a row is a mood, not a reading.

## Colour

Every accent exists in **two registers**. The saturated one is used as a pure
mark, where nothing sits on top of it: the spine, the KPI ticks, a chart
series. The deep one is used wherever the accent has to carry text - as small
text itself on paper, and as the fill beneath the white label of the badge and
the active navigation pill.

| Element | Mark | As text / under white text |
|---|---|---|
| Reminder 1, page 1 | `#0E7A6A` teal | `#0E7A6A` |
| Reminder 2, page 2 | `#2B6C97` steel | `#2B6C97` |
| Reminder 3, page 3 | `#C05A38` clay | `#B45434` |
| Reminder 4, page 4 | `#C79020` gold | `#916917` |
| Page 5 | `#5A6B76` slate | `#5A6B76` |

Clay and gold fail WCAG AA in both text roles at full saturation. Dulling the
fills to fix that would have cost the palette its warmth, so each keeps a
darkened twin instead: a bar and the label describing it stay recognisably the
same colour, and both are legible.

| Element | Colour | Rule |
|---|---|---|
| Volume rise | `#2E7D52` green | |
| Volume fall | `#916917` gold | gold, not red - a smaller later stage is the normal shape of a reminder sequence, not a failure |
| Exception / attention | `#916917` gold | |
| Exception, severe | `#AE3B2B` | used only where a rule was actually broken |

Stage colour comes from a measure keyed on `Reminder Order`, so a stage keeps
its identity even when a journey contains only some of the stages. The theme's
series palette is in the same order, so a multi-series chart by reminder picks
up the same identities.

The heatmap ramp runs **light to dark** on paper - the reverse of a dark-canvas
report - so the value printed in each cell inverts with it: ink on the two pale
steps, paper on the two saturated ones. Without that the busiest cells, the
ones actually worth reading, become the unreadable ones.

## Designing for 100+ clients and 100k+ rows

The supplied extract has three clients and 162 rows. The report is built for a
feed of 100+ clients and 100k+ rows, and a layout that reads well at three
clients can be unusable at a hundred. Rather than assert that it scales,
`tools/make_scale_fixture.py` writes a fixture with the shape the real feed
will have - 128 clients, ~99k rows, 18 months, journeys of one to four stages,
and control rows - and the report is pointed at it and looked at:

```bash
python tools/make_scale_fixture.py
python tools/use_fixture.py on
python tools/gen_semantic_model.py     # then reload Desktop
```

`python tools/use_fixture.py off` puts it back. That test is what found every
item below; none of them were visible at 162 rows.

### Rankings are cut to a top N, and say so

Every per-client, per-program and per-creative visual is drawn through a
`Top N ... Volume` measure that returns BLANK outside the cut, so the chart
drops those members. `[Top N]` is a measure, so one edit changes every ranking
chart and every caption with it.

The cut is stated, never implied: each chart's subtitle is a coverage caption
reading *Top 10 of 128 clients - 67.9% of selected volume*, or simply
*3 clients in selection* when everything fits. A ranking that silently shows
ten of a hundred and twenty-eight is a lie by omission.

**The ranked set is computed once per visual, not once per cell.** This is the
subtle part. Ranking inside the cell context re-chooses the top ten for every
reminder stage and every week, so a stacked chart drew twenty-two clients
instead of ten and a ten-series weekly line chart never returned at all.
Wrapping the ranking table in `CALCULATETABLE ( ..., ALLSELECTED () )` strips
the visual's own groupings while keeping the slicers: one set, cached, stable
across every cell.

### Grain follows the question, not the source

The daily operations table used to be one row per source row, carrying each
day's baseline and status beside it. At 99k rows it rendered nothing at all -
no error, an empty panel - because a trailing 14-day baseline was being
evaluated for every row.

It is now one row per day. That is also the honest grain: the baseline, the
standard deviation and the exception flag are properties of a *day*, and
printing a day's status beside a single client-creative-stage row implied the
row was the thing being judged. Row-level records live on page 5, which is the
page for them.

### Time axes are scalar, and weekly charts key off a real date

`Dim_Date[Week Start]` holds the Monday of each week so weekly charts sit on a
scalar axis, spaced by time, thinning their own labels. The earlier version put
the text `Year-Week` on a categorical axis: at 91 days that was tight, and at
78 weeks it printed 78 labels, truncated every one to `20...`, and grew a
scrollbar.

### Everything else that scale changed

- Slicers carry a search box. A dropdown of 128 clients without one is not a
  filter.
- The category gutter on ranking charts is widened to 45% of the plot, or long
  names arrive as *Ashley Advantag...*.
- Ranking charts are tall enough for ten bars. At the original height they drew
  three and hid the rest behind a scrollbar.
- A banner appears in the masthead when the selection is large enough that the
  page is showing a window rather than the whole: *128 clients - rankings show
  top 10*.
- The weekly-volume-by-client chart was removed. Ten overlapping weekly lines
  over seventy-eight weeks was never readable, and the space it freed is what
  lets the three rankings show ten bars each.

### What does not scale away

The matrices and the raw extract table stay at full grain and scroll. That is
the right behaviour for them - they exist to be searched and drilled, not
summarised - and Power BI virtualises their rows.

**Numbers in charts and tables follow the viewer's Windows regional format.**
On a machine set to an Indian locale, 653,297 renders as 6,53,297. That is
Power BI working as designed, not a report setting: the model's culture is
`en-US` and DAX-formatted text obeys it, but visual-level number formatting is
the viewer's. Data labels are left at full precision rather than Auto display
units, because Auto renders 122, 123 and 97 all as `0.1K`.

## Accessibility

- Colour is never the only signal: the heatmap prints its values, status columns
  print their words, and movement carries a sign as well as a colour.
- Body text is 8.5pt and above; KPI values are 26pt.
- Every visual has a title, and most carry a subtitle stating what the numbers
  mean.
- Text containers are sized to their line boxes - Power BI clips a run whose
  container is tight rather than reflowing it.
- **Contrast is measured, not asserted.** `tools/check_contrast.py` runs as a
  build stage: it walks every text element in the emitted `report.json`, works
  out which surface it actually sits on by geometry and z-order, and fails the
  build if any falls below WCAG 2.1 AA - 4.5:1 for body text, 3.0:1 for large.
  300 text elements are checked and all pass. This is the check that caught the
  colours the inversion from a dark canvas left behind.

## Navigation and drill-through

Numbered buttons across every page header, with the current page highlighted in
its accent colour. Right-click any client or program - in a chart, a matrix or a
table - and drill through to **3. Drivers**, filtered to that value.

## Tooltips

Measure-driven tooltips are attached to the visuals where they add something:

| Hovering | Shows |
|---|---|
| a date | volume, REM1-REM4, previous available day, day-over-day % |
| a client | volume, programs, stages, REM1-REM4 |
| a program | volume, clients, stages, creatives |
| a reminder stage | volume, share, latest day, day-over-day %, creatives |
| a creative | volume, clients, programs, reminders |

## Dynamic titles

Titles are measures, never fixed strings:

- `Daily Email Volume — All Clients`
- `Daily Email Volume — Ashley Advantage® Credit Card`
- `Client → Program → Reminder → Creative — All Clients`

`All` appears when nothing is selected, the value when one thing is, and a count
when several are.

## Empty states

| Situation | Behaviour |
|---|---|
| No filters | everything shown |
| No data after filtering | *No data available for the selected filters.* |
| Control-only selection | the Control banner, not the no-data message |
| A stage missing from the journey | slot and connector collapse |
| A stage with no volume in period | `0`, captioned as such |
| A date with no send | no row - it never reaches a table |

## Business definitions

| Term | Definition |
|---|---|
| Email Volume | Sum of the volume column over **Test (`T`) records only** |
| Test | `t_c_ind = "T"` - receives the reminder email |
| Control | `t_c_ind = "C"` - eligible population, deliberately not mailed |
| Population | A **record** count. The extract carries no headcount column, so this counts source rows, not people |
| Volume Movement | Difference against the previous stage **that exists in that journey**. Deliberately not called conversion: the source defines none |
| Active Day | A date that carries Test data |
| Journey | The set of reminder stages present for the current selection, ignoring the date filter |
