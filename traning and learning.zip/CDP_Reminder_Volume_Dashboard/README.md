# CDP Email Volume Tracking

A Power BI Project (PBIP) tracking daily email volume across clients, programs,
communication codes and reminder stages.

It is a light, printed editorial report - warm paper, white cards, one inverted
deep-pine masthead holding every control - deliberately not a dark instrument
panel, so it is never mistaken for the IDR monitoring console it shares a
generator with. See
[Documentation/Dashboard_Design.md](Documentation/Dashboard_Design.md).

It answers one question, in five pages: *for a selected client and program, how
much email volume was generated at each reminder stage, how has it changed, which
creative drove it, and where should I look?*

---

## Business objective

```text
CLIENT  ->  PROGRAM  ->  COMMUNICATION / CREATIVE  ->  TEST POPULATION
        ->  REMINDER 1  ->  REMINDER 2  ->  REMINDER 3  ->  REMINDER 4
```

Not every client and program runs four reminders. Some run one, some three. The
report works out which stages exist for the current selection and renders exactly
those - no empty `REM4`, no dangling arrow.

## Source

| | |
|---|---|
| File | `Data/CDP_Projects_Summary_History.csv` (a copy of the supplied extract) |
| Rows | 162 |
| Date range | 22-Apr-2026 to 10-Sep-2026 (91 distinct dates) |
| Total volume | 2,016 |

The extract's volume column is named `email_counts`; the specification calls it
`Number of Email`. Power Query accepts either and normalises to
`Number of Email`, so the documented DAX works against either drop.

## Setup

**Requires** Power BI Desktop (developed against 2.157.879.0, August 2026) with
*Preview features → Power BI Project (.pbip) save option* enabled.

```text
Open CDP_Reminder_Volume_Dashboard.pbip in Power BI Desktop.
```

The project opens with the model schema in place but **unprocessed** - a PBIP
carries no cached data. Click **Home → Refresh** once. The tables load in a few
seconds and every visual populates.

### Moving it to another machine, or converting to PBIX

Step-by-step in
[Documentation/Deployment.md](Documentation/Deployment.md). The short version:
copy the whole folder, enable the `.pbip` preview option once, and repoint
**`p_SourceFilePath`** - it is the only parameter in the model and the only
thing that is machine-specific, because Power Query cannot resolve a path
relative to the report file.

To hand the dashboard to someone who just wants to read it, refresh and then
**File → Save as → Power BI files (\*.pbix)**. A PBIX carries the data inside
it, so the recipient needs neither the CSV nor the preview feature.

### Refresh against a new extract

Change one parameter:

1. **Home → Transform data → Manage parameters**
2. Set **`p_SourceFilePath`** to the new CSV.
3. **Close & Apply**, then **Refresh**.

`p_SourceFilePath` defaults to the copy bundled under `Data/`, so a freshly
built project refreshes without touching anything. A second fallback parameter
used to sit beside it; on a new machine both paths were wrong and both needed
editing, which is worse than one. Nothing else needs editing: reminder stages, clients, programs, creatives and the
calendar are all derived from whatever the file contains.

## Exporting the raw data

Two ways, and the difference matters.

**From the page.** On *4 - Daily Operations*, hover the table, open the `...`
menu at its top right and choose **Export data** (right-clicking the table
works too). This exports what the slicers currently select. Power BI caps that
export at **30,000 rows for CSV** and 150,000 for Excel, and it truncates
silently, so the page prints the live row count next to the instruction.

**The complete extract, uncapped.** With the project open and refreshed:

```bash
powershell -ExecutionPolicy Bypass -File tools/export_raw_csv.ps1
powershell -ExecutionPolicy Bypass -File tools/export_raw_csv.ps1 -Out D:/exports/cdp.csv
```

One DAX query against the running model, streamed straight to CSV with no row
limit. Verified against the scale fixture: 98,883 rows out, 11 MB, and the
exported volume column sums to 1,000,505 - the model's own total. Files land in
`Exports/`.

It exports the model's view - cleaned, typed, dimension-joined - which is
normally what "the raw data behind the dashboard" means. For the untouched
source file, just copy the CSV the model was refreshed from.

## Brand mark

Drop the logo at **`Assets/synchrony_logo.png`** and run `python tools/build.py`.
It is copied into the report's registered resources and placed top-right in the
masthead on every page. Without the file the report builds normally and the
generator prints `brand mark: NOT FOUND`, so a missing binary is a visible
notice rather than a broken image. See
[Assets/README.md](Assets/README.md).

## Data model

Star schema - one fact, eight dimensions, one measure table.

```text
                          Dim_Date
                              |
        Dim_Reminder          |          Dim_Client
                   \          |          /
                    \         |         /
   Dim_Program ------  Fact_ReminderVolume  ------ Dim_CommCode
                    /         |         \
                   /          |          \
          Dim_Site            |           Dim_ClientGroup
                       Dim_Population

   _Measures  (185 measures, no data)
```

Full detail in [Documentation/Data_Model.md](Documentation/Data_Model.md).

## Pages

| # | Page | Answers |
|---|---|---|
| 1 | Volume Tracking | How much are we sending, and what does the journey look like? |
| 2 | Reminder Journey | Which stage carries the volume, and how do stages move against each other? |
| 3 | Drivers | Which client, program and creative drive it? (also the drill-through target) |
| 4 | Daily Operations | Show me the actual rows behind the numbers |
| 5 | Records & Quality | What are the underlying rows, and can I trust them? |

Design rationale in
[Documentation/Dashboard_Design.md](Documentation/Dashboard_Design.md).

## Business rules

**Email volume is Test-only.** `t_c_ind = "T"` is the population that receives
the reminder; `C` is the control population that does not.

```dax
Email Volume =
CALCULATE (
    SUM ( 'Fact_ReminderVolume'[Number of Email] ),
    'Fact_ReminderVolume'[t_c_ind] = "T"
)
```

Control rows are **kept** in the model so the population can be analysed, but
they can never contribute to a number labelled "email". The raw volume column is
hidden and the model sets `discourageImplicitMeasures`, so nobody can casually
drag it into a visual and put Control volume back in.

Selecting Control in the **T_C_IND** slicer correctly yields blank, and a banner
explains why rather than leaving a blank page. That slicer is named after the
source column rather than "Population", because Population is also what the
record counts are called and one word doing two jobs is how a Test-only figure
gets misread.

**Absence is not zero.** A stage that is not part of a journey renders nothing.
A stage that exists but had no volume in the selected period renders `0`.

**Gaps are real.** The feed has 91 distinct dates across a 142-day window.
Averages divide by days with data; the previous-day comparison finds the previous
day that *exists*.

**Reminder order is derived, not mapped.** Stage order comes from the digits in
`rem_flag`, so a future `REM5` sorts and labels itself.

## Validation

Every headline figure is recomputed from the CSV in Python, independently of the
model, and the model is then queried through the live Analysis Services engine
and compared.

```bash
python tools/validate_data.py        # recompute expected values from the CSV
python tools/validate_project.py     # structural checks on the PBIP
python tools/check_contrast.py       # WCAG AA audit of every text element
python tools/check_text_fit.py       # every text container has room to render

# with the project open in Power BI Desktop:
powershell -ExecutionPolicy Bypass -File tools/verify_live_model.ps1
```

Current status - all checks pass:

| Metric | CSV | Model |
|---|---:|---:|
| Rows | 162 | 162 |
| Test rows / Control rows | 162 / 0 | 162 / 0 |
| Email Volume (Test only) | 2,016 | 2,016 |
| REM1 / REM2 / REM3 / REM4 | 1,674 / 122 / 123 / 97 | 1,674 / 122 / 123 / 97 |
| Days with data | 91 | 91 |
| Latest / previous day | 10-Sep-2026 / 09-Sep-2026 | 10-Sep-2026 / 09-Sep-2026 |
| Day-over-day | −92.73% | −92.73% |

All 185 measures evaluate without error, all 293 text elements clear WCAG
2.1 AA contrast, and all 92 text containers have room to render without
clipping. Full results in
[Documentation/Validation.md](Documentation/Validation.md).

### Seeing the report without opening Desktop

```bash
powershell -ExecutionPolicy Bypass -File tools/dump_card_values.ps1   # needs Desktop open
python tools/preview_report.py
```

`build/preview/preview.html` renders all five pages from the same `report.json`
Desktop loads - real geometry, real colour, real static text, and real card
values pulled from the running model. Chart interiors are not drawn; their
pixels come from the engine at render time and inventing them would make the
preview a mockup rather than a view of the build.

## Rebuilding

The whole project is generated. To regenerate and revalidate:

```bash
python tools/build.py
```

| Script | Does |
|---|---|
| `tools/gen_semantic_model.py` | writes the TMDL semantic model |
| `tools/gen_report.py` | writes the report (PBIR, then lowered to legacy) |
| `tools/gen_docs.py` | writes Data_Profile, Data_Model and DAX_Measures |
| `tools/validate_data.py` | recomputes every figure from the CSV |
| `tools/validate_project.py` | structural, layout and reference checks |
| `tools/check_contrast.py` | WCAG AA contrast audit of every text element |
| `tools/check_text_fit.py` | catches containers too short for their own text |
| `tools/make_scale_fixture.py` | writes a 128-client, ~99k-row test extract |
| `tools/use_fixture.py` | points the model at the fixture, or back |
| `tools/verify_live_model.ps1` | evaluates the DAX against the live engine |
| `tools/export_raw_csv.ps1` | writes the full extract to CSV with no row cap |
| `tools/dump_card_values.ps1` | reads every card's value out of the live model |
| `tools/preview_report.py` | renders the emitted report as static HTML |

## Scale

Built for 100+ clients and 100k+ rows, and tested against that rather than
assumed. `tools/make_scale_fixture.py` writes a synthetic extract with the
shape the real feed will have - 128 clients, ~99k rows, 18 months, journeys of
one to four stages, and control rows - and the report is refreshed against it
and inspected:

```bash
python tools/make_scale_fixture.py
python tools/use_fixture.py on
python tools/gen_semantic_model.py     # then reload Desktop
python tools/use_fixture.py off        # back to the real extract
```

Every ranking visual is cut to the top N by volume and says so in its subtitle
("Top 10 of 128 clients - 67.9% of selected volume"). `[Top N]` is a measure,
so one edit moves every chart and caption together. Matrices and the raw
extract stay at full grain and scroll.

Full detail in
[Documentation/Dashboard_Design.md](Documentation/Dashboard_Design.md).

## Known limitations

1. **No Control records exist in the supplied extract.** All 162 rows are Test.
   The Test-only rule is enforced in the measure rather than assumed, and
   `Dim_Population` still carries a Control member, so the report behaves
   correctly the first time a Control row appears - but that path has been
   verified by construction, by querying a Control-only selection, and against
   the scale fixture - which does carry control rows, and where the split
   reads 83,834 Test / 15,049 Control with email volume correctly counting only
   the Test side. It has still never been exercised against real control data.
2. **"Population" counts records, not people.** The extract has no headcount or
   identifier column, so `Test Population` and `Control Population` count source
   rows. Both are documented as such wherever they appear.
3. **A PBIP opens unprocessed.** One manual Refresh is needed after opening; a
   project file carries no cached data.
4. **The heatmap scrolls** when the selection spans more than about ten weeks.
   The values are printed in every cell, and the operational table below carries
   the same data at daily grain.
5. **Report-page tooltips are not used.** Tooltips are measure-driven instead.
   The legacy report format Desktop reads has no equivalent of a PBIR tooltip
   page binding, and measure tooltips carry the same content.
6. **Numbers in visuals follow the viewer's regional format.** On a machine
   set to an Indian locale, 653,297 renders as 6,53,297. The model's culture is
   `en-US` and DAX-formatted text obeys it, but visual-level number formatting
   is the viewer's, which is Power BI working as designed rather than a report
   setting.
7. **The scale fixture is synthetic.** It has the right shape - client count,
   row count, journey variety, a long-tailed volume distribution, control rows
   - but it is generated, not real. It proves the layout and the DAX hold at
   size; it cannot prove anything about the real feed's content.
8. **`comm_code` has no descriptive names.** The source supplies none and none
   were invented; the only derived attribute is the code's own three-character
   prefix.

## Project structure

```text
CDP_Reminder_Volume_Dashboard/
├── CDP_Reminder_Volume_Dashboard.pbip
├── CDP_Reminder_Volume_Dashboard.Report/         report definition
├── CDP_Reminder_Volume_Dashboard.SemanticModel/  TMDL model
├── Assets/synchrony_logo.png                     brand mark (you supply)
├── Exports/                                      uncapped CSV exports land here
├── Data/CDP_Projects_Summary_History.csv
├── Data/scale_fixture.csv                        generated scale test extract
├── Documentation/
│   ├── Data_Profile.md
│   ├── Data_Model.md
│   ├── DAX_Measures.md
│   ├── Dashboard_Design.md
│   ├── Validation.md
│   └── validation_summary.json
├── build/pbir/                                   PBIR authoring staging
├── build/preview/preview.html                    static render of the build
└── tools/                                        generators and validators
```
