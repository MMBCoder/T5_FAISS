# -*- coding: utf-8 -*-
"""Generates the CDP report: five pages, one story.

Authored as PBIR (one JSON per visual - easy to generate and validate), then
lowered to the single legacy ``report.json`` that Power BI Desktop 2.157
actually reads. See pbir_to_legacy.py for why both formats exist.

The page set is deliberately five, not nine. An earlier cut had a separate page
for clients, one for programs and one for creative - the same three visuals with
one field swapped - plus two drill-through pages that repeated the executive
page almost exactly. Redundant pages make a report feel large and read small.
Each page here answers one question, in order:

    1  HOW MUCH        Volume Tracking     total volume, the journey, the drivers
    2  WHERE IN IT     Reminder Journey    which stage carries the volume
    3  WHO DRIVES IT   Drivers             client, program and creative together
    4  THE DAY BY DAY  Daily Operations    the operational records, unsummarised
    5  THE RECORDS     Records & Quality   the raw extract and its validation

Each page carries its own accent colour, chapter caption and arrangement, so the
reader always knows which chapter they are in without reading a word.

Run: python tools/gen_report.py
"""
import json
import os
import shutil
import sys
import time
import uuid

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from report_lib import (
    SCHEMA_PAGES, SCHEMA_REPORT, SCHEMA_VERSION, SCHEMA_PLATFORM,
    BG_PAGE, BG_CARD, BG_BAND, BG_PANEL, BG_PANEL_2, BG_QUOTE, BAND_ALT,
    BORDER, BORDER_SOFT, TEXT_HI, TEXT_MID, TEXT_LOW, INK_HI, INK_MID, INK_LOW, PINE_LINE,
    GREEN, AMBER, RED, BLUE, CYAN, PURPLE, GRID,
    TEAL, STEEL, CLAY, GOLD, SLATE, CLAY_TEXT, GOLD_TEXT,
    FONT, FONT_SEMI, FONT_LIGHT, PAGE_W, PAGE_H,
    lit, obj, solid, solid_m, m_bound, measure_expr, column_expr,
    pm, pc, qref, sel_meta, visual, sort_by, chrome, textbox, panel,
    nav_button, card, tick, axis_objects, series_color, line_style, table_objects,
    value_color_rule, value_back_rule, drillthrough_filter, page)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT = "CDP_Reminder_Volume_Dashboard"
REPORT_DIR = os.path.join(ROOT, PROJECT + ".Report")
STAGE_DIR = os.path.join(ROOT, "build", "pbir")
DEF = os.path.join(STAGE_DIR, "definition")
NS = uuid.UUID("6f1c9b52-1f3e-5b7a-9c44-2f8d6e10a7b3")

REPORT_NAME = "CDP EMAIL VOLUME TRACKING"

# The brand mark is optional by design. If Assets/synchrony_logo.png is there
# it is registered as a report resource and placed in the masthead; if it is
# not, the report builds without it and says so. A generator that hard-required
# a binary would be one that nobody else could build.
LOGO_NAME = "synchrony_logo.png"
LOGO_SRC = os.path.join(ROOT, "Assets", LOGO_NAME)


def has_logo():
    return os.path.isfile(LOGO_SRC)


def logo_visual(x, y, w, h):
    """An image visual bound to a registered resource, not an embedded blob."""
    objects = {
        "general": [obj({
            "imageUrl": {"expr": {"ResourcePackageItem": {
                "PackageName": "RegisteredResources",
                "PackageType": 1,
                "ItemName": LOGO_NAME}}},
        })],
        "imageScaling": [obj({"imageScalingType": lit("Fit")})],
    }
    cont = {
        "background": [obj({"show": lit(False)})],
        "border": [obj({"show": lit(False)})],
        "title": [obj({"show": lit(False)})],
        "visualHeader": [obj({"show": lit(False)})],
        "dropShadow": [obj({"show": lit(False)})],
        "general": [obj({"altText": lit("Synchrony")})],
    }
    return visual(vn("logo"), x, y, w, h, "image", objects=objects,
                  container=cont)

# One identity per reminder stage, used on every page (spec section 55).
STAGE_COLOURS = [TEAL, STEEL, CLAY, GOLD]
STAGE_TEXT = [TEAL, STEEL, CLAY_TEXT, GOLD_TEXT]

# ---- geometry -------------------------------------------------------------
M = 16                      # page margin
G = 8                       # gap between tiles
CW = PAGE_W - 2 * M         # content width
# Heights are line boxes with headroom. Desktop clips a text run whose container
# is tight rather than reflowing it, so a 10pt run in a 22px box loses its lower
# half - which is how the brand line and every page subtitle came out cut.
SPINE_W = 6                 # the accent spine down the left edge of the page
BADGE = 50                  # the chapter badge - a solid accent square
HEAD_X = M + SPINE_W + BADGE + 16   # the masthead text column, clear of both

# Every height below is a line box with real headroom, not a guess. Desktop
# clips a text run whose container is tight rather than reflowing it, and it
# clips silently: the first cut of this masthead lost the chapter caption
# entirely and cut the title and the strapline in half. The rule of thumb that
# holds is roughly 2.2x the point size, and never less than 20px.
# The chapter caption and the title share one container. Two textboxes would
# each pay the renderer's own 16px of vertical padding, and that difference is
# what pushed both of them into scrollbars and cut them in half.
HEAD_Y, HEAD_H = 12, 62        # 8.5pt caption stacked over an 18pt title
BASIS_Y, BASIS_H = 76, 24      # 8.5pt - the volume rule, stated under the title
NAV_Y, NAV_H = 106, 30
FILT_Y, FILT_H = 142, 52       # 8.5pt header over a 9pt dropdown
BAND_H = 200

# The two conditional banners sit beside the navigation rather than under it.
# They are transparent cards bound to measures that return an empty string in
# the normal case, so this strip is blank paper until there is something to say.
NAV_W = 892                    # five pills, leaving room for the banners
NOTICE_X = M + NAV_W + 14
NOTICE_W = (PAGE_W - M) - NOTICE_X

PERIOD_X, PERIOD_W = 700, 310
DATE_X, DATE_W = 1018, 280
# The brand mark sits top-right, opposite the title - the conventional place
# for it, and the only corner of the masthead not already carrying a control.
LOGO_W, LOGO_H = 116, 42
LOGO_X, LOGO_Y = PAGE_W - M - LOGO_W, 18

Y0 = BAND_H + 8
KPI_H = 82                     # label + one-line caption + a 26pt value

FS_TITLE, FS_SUB = 18, 9.5
FS_SECT = 10.5
SECT_H = 34
FS_PANEL, FS_BODY, FS_CAP = 10.5, 9, 8.5
FS_KPI = 26

DATE_SYNC = "cdpDate"

_seq = [0]


def vn(prefix):
    _seq[0] += 1
    return "%s%04d" % (prefix, _seq[0])


def write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)


def disp(measure):
    """KPI values go through the card-safe text form of a measure.

    Power BI's card formats a number through a different path from a table: on
    this build 2,016 rendered as "2.016" on a card while the matrix beside it
    printed "1,674". A card also prints the literal string "(Blank)" when its
    measure is BLANK, which is exactly what a Control-only selection produces.
    Handing the card text avoids both.
    """
    return measure + " Display"


# ==========================================================================
# pages - id, tab, chapter caption, title, subtitle, accent, accent-as-text
#
# Two registers of the same accent. The saturated one is used as a pure mark -
# the spine, the KPI ticks, a chart series - where nothing sits on top of it.
# The deep one is used wherever the accent has to carry text: as small text
# itself on paper, and as the fill under the white label of the badge and the
# active nav pill. Clay and gold fail AA in both of those roles at full
# saturation, and dulling the fills to fix it would have cost the palette its
# warmth.
# ==========================================================================
PAGES = [
    ("pgCommand", "Volume Tracking", "01   HOW MUCH ARE WE SENDING",
     REPORT_NAME,
     "Total email volume, the reminder journey it moves through, and what the numbers say",
     TEAL, TEAL),
    ("pgJourney", "Reminder Journey", "02   WHERE IN THE JOURNEY",
     "REMINDER JOURNEY",
     "Which reminder stage carries the volume, and how the stages move against one another",
     STEEL, STEEL),
    ("pgDrivers", "Drivers", "03   WHO AND WHAT DRIVES IT",
     "CLIENT, PROGRAM & CREATIVE DRIVERS",
     "Client, program and communication code side by side, down to the reminder stage",
     CLAY, CLAY_TEXT),
    ("pgOps", "Daily Operations", "04   THE ROWS BEHIND THE NUMBERS",
     "DAILY OPERATIONAL RECORDS",
     "Every loaded record at source grain, filtered by the same eight slicers",
     GOLD, GOLD_TEXT),
    ("pgData", "Records & Quality", "05   THE UNDERLYING RECORDS",
     "RECORDS & DATA QUALITY",
     "Every row of the loaded extract, and the validation checks applied to it",
     SLATE, SLATE),
]
PAGE_BY_ID = {p[0]: p for p in PAGES}


# ==========================================================================
# shared furniture
# ==========================================================================
def date_slicer(x, y, w, h):
    """The one control that defines the selected period, synced everywhere."""
    objects = {
        "general": [obj({"outlineColor": solid(PINE_LINE), "outlineWeight": lit(1)})],
        "data": [obj({"mode": lit("Between")})],
        "header": [obj({"show": lit(False)})],
        "items": [obj({"fontColor": solid(INK_HI), "background": solid(BG_PANEL_2),
                       "fontSize": lit(FS_BODY), "fontFamily": lit(FONT)})],
        "date": [obj({"fontColor": solid(INK_HI), "fontSize": lit(FS_BODY),
                      "fontFamily": lit(FONT)})],
    }
    return visual(vn("slDate"), x, y, w, h, "slicer",
                  roles={"Values": [pc("Dim_Date", "Date")]},
                  objects=objects, sync_group=DATE_SYNC,
                  container=chrome(title="DATE RANGE", title_size=FS_CAP,
                                   bg=BG_PANEL, border=None,
                                   title_color=INK_LOW))


def categorical_default(field_name, entity, prop, value):
    """Pre-selects one slicer value. Used to default Population to Test."""
    src = "s"
    return {
        "name": field_name,
        "field": column_expr(entity, prop),
        "type": "Categorical",
        "filter": {
            "Version": 2,
            "From": [{"Name": src, "Entity": entity, "Type": 0}],
            "Where": [{"Condition": {"In": {
                "Expressions": [{"Column": {
                    "Expression": {"SourceRef": {"Source": src}},
                    "Property": prop}}],
                "Values": [[{"Literal": {"Value": "'%s'" % value}}]],
            }}}],
        },
        "howCreated": "User",
    }


def dropdown_slicer(x, y, w, h, entity, prop, header, sync, default=None,
                    cascade=True):
    # Each filter is a well cut into the pine rather than a light tile laid on
    # it: seven white boxes across a dark band read as seven buttons, and the
    # masthead stops being a header and starts competing with the page.
    objects = {
        # Production is 100+ clients. Scrolling a dropdown that long to find
        # one client is not a filter, it is a punishment, so every slicer
        # carries a search box.
        "general": [obj({"outlineColor": solid(PINE_LINE),
                         "outlineWeight": lit(1),
                         "searchEnabled": lit(True)})],
        "data": [obj({"mode": lit("Dropdown")})],
        "header": [obj({"show": lit(True), "fontColor": solid(INK_LOW),
                        "background": solid(BG_PANEL), "fontSize": lit(FS_CAP),
                        "fontFamily": lit(FONT_SEMI), "text": lit(header),
                        "outline": lit("None")})],
        "items": [obj({"fontColor": solid(INK_HI), "background": solid(BG_PANEL_2),
                       "fontSize": lit(FS_BODY), "fontFamily": lit(FONT),
                       "outline": lit("Frame")})],
        # Multi-select with tick boxes, plus a Select all entry. Without this a
        # dropdown slicer is single-select in practice: picking a second client
        # replaces the first, and there is no way back to everything short of
        # the eraser icon. Ctrl+click works either way, but nobody should have
        # to know that.
        "selection": [obj({"singleSelect": lit(False),
                           "strictSingleSelect": lit(False),
                           "selectAllCheckboxEnabled": lit(True)})],
    }
    filters = []
    if default:
        filters.append(categorical_default(vn("fDef"), entity, prop, default))
    # Cascading is handled in the model, by making the six slicer dimensions
    # bi-directional, not here. A visual-level measure filter was tried first
    # and does work per item, but it never sees the other slicers' selections,
    # so it cannot narrow one slicer by another. The `cascade` flag is kept
    # because it still records which slicers are meant to narrow each other.
    filters = filters or None
    return visual(vn("sl"), x, y, w, h, "slicer",
                  roles={"Values": [pc(entity, prop)]},
                  objects=objects, sync_group=sync, filters=filters,
                  container=chrome(transparent=True))


# The seven analytical filters the specification requires, all synced so a
# selection survives navigation - the report has to behave like one application,
# not five pages that each forget what you just asked for.
FILTERS = [
    ("Dim_Client", "Client_name", "CLIENT", "cdpClient", None, True),
    ("Dim_ClientGroup", "client_group", "CLIENT GROUP", "cdpGroup", None, True),
    ("Dim_Program", "Program", "PROGRAM", "cdpProgram", None, True),
    ("Dim_Reminder", "Reminder Display Name", "REMINDER", "cdpReminder", None, True),
    ("Dim_CommCode", "comm_code", "CREATIVE / COMM CODE", "cdpComm", None, True),
    ("Dim_Site", "site_code", "SITE", "cdpSite", None, True),
    # cascade=False: Dim_Population always carries both Test and Control, by
    # design, so that an extract with no control rows shows an empty Control
    # rather than no Control at all. Cascading would hide it in precisely the
    # case the member exists to reveal.
    ("Dim_Population", "Population", "T_C_IND", "cdpPop", "Test", False),
]


def notices():
    """The two banners that explain an otherwise blank page.

    Both are cards bound to measures that return an empty string in the normal
    case, so they show nothing until they have something to say. They sit
    beside the navigation, in a strip reserved for them - stacking them over
    the KPI row, as an earlier layout did, meant an empty banner painted itself
    across the tiles below.

    The third banner - the always-on statement of the volume rule - is no
    longer a banner at all. It is the strapline under the report title, which
    is where a rule that governs every number on the page belongs.
    """
    half = (NOTICE_W - G) / 2.0
    return [
        card(vn("noticePop"), NOTICE_X, NAV_Y, half, NAV_H,
             "Population Notice", size=9, value_color=GOLD, transparent=True),
        card(vn("noticeNone"), NOTICE_X + half + G, NAV_Y, half, NAV_H,
             "Page Status Notice", size=9, value_color=INK_MID,
             transparent=True),
    ]


def header(page_id):
    """The masthead: one inverted pine band carrying every control.

    The report is a light, printed page; the masthead is the one dark zone on
    it, and it holds the title, the chapter mark, the navigation and all eight
    filters. Separating the controls from the paper this sharply means the body
    of the page is nothing but data, and it is the silhouette that tells this
    report apart from the dark console at a glance.

    The page's identity is carried by three marks, never by a full-bleed rule:
    the accent spine down the left edge of the whole page, the solid accent
    chapter badge, and the one lit navigation pill.
    """
    pid, tab, chapter, title, subtitle, accent, accent_deep = PAGE_BY_ID[page_id]
    ordinal = [p[0] for p in PAGES].index(pid) + 1

    v = [panel(vn("hdr"), 0, 0, PAGE_W, BAND_H, bg=BG_PANEL, border=None, z=0)]
    # The spine runs the full height of the page, through both zones, so the
    # accent is present on the paper as well as on the masthead.
    v.append(tick(vn("spine"), 0, 0, SPINE_W, PAGE_H, accent))

    # The badge is one textbox carrying its own fill, not a panel with a number
    # laid over it. Two visuals both at z = 0 tie, and the full-width masthead
    # won the tie and painted straight over the badge.
    v.append(textbox(vn("badge"), M + SPINE_W, 14, BADGE, BADGE,
                     [("%d" % ordinal, 19, "#FFFFFF", 600)], align="center",
                     valign="middle", bg=accent_deep))

    head_w = PERIOD_X - HEAD_X - 16
    v.append(textbox(vn("head"), HEAD_X, HEAD_Y, head_w, HEAD_H,
                     [[(chapter, FS_CAP, INK_LOW, 600)],
                      [(title, FS_TITLE, INK_HI)]], valign="middle"))
    # The strapline is the volume rule itself, not a description of the page.
    # It is the one sentence that governs every number in the report, and a
    # reader who misses it misreads all of them.
    v.append(card(vn("basis"), HEAD_X, BASIS_Y, head_w, BASIS_H,
                  "Volume Basis Note", size=FS_CAP, value_color=INK_LOW,
                  transparent=True))

    # The period caption is a measure, so it always states the dates that
    # actually carry data rather than the slicer's endpoints.
    v.append(card(vn("period"), PERIOD_X, 16, PERIOD_W, 54,
                  "Selected Period Label", title="DATA IN SELECTION",
                  size=11, transparent=True, title_size=FS_CAP,
                  title_color=INK_LOW, value_color=INK_HI))
    v.append(date_slicer(DATE_X, 14, DATE_W, 74))
    if has_logo():
        v.append(logo_visual(LOGO_X, LOGO_Y, LOGO_W, LOGO_H))

    bw = (NAV_W - (len(PAGES) - 1) * G) / float(len(PAGES))
    for i, (p, label, _c, _t, _s, _a, a_deep) in enumerate(PAGES):
        v.append(nav_button(vn("nav"), M + i * (bw + G), NAV_Y, bw, NAV_H,
                            "%d.  %s" % (i + 1, label), p,
                            active=(p == page_id), accent=a_deep))

    fw = (CW - (len(FILTERS) - 1) * 6) / float(len(FILTERS))
    for i, (ent, prop, head, sync, default, cascade) in enumerate(FILTERS):
        v.append(dropdown_slicer(M + i * (fw + 6), FILT_Y, fw, FILT_H,
                                 ent, prop, head, sync, default, cascade))
    v += notices()
    return v, accent, accent_deep


def section(x, y, w, text, accent_deep):
    """An editorial band opener: a tracked accent label.

    There is deliberately no hairline under it. Power BI enforces a minimum
    rendered height on a visual, so a 1px rule came out as an 11px grey slab
    lying across the heading - the single worst thing on the page.
    """
    return [textbox(vn("sect"), x, y, w, SECT_H,
                    [(text.upper(), FS_SECT, accent_deep, 600)], valign="middle")]


def kpi_row(y, tiles, x=M, w=CW, h=KPI_H, accent=None):
    """tiles: (title, measure, caption_measure, colour).

    `measure` names the underlying measure; the card-safe display form is
    substituted here so no caller has to remember to do it.

    Each tile is a white rectangle with a hairline and a solid accent bar down
    its left edge. The bar is a separate 4px visual rather than a tint on the
    tile, so the number still sits on plain white - eight tinted tiles in a row
    is a mood, not a reading.
    """
    n = len(tiles)
    tw = (w - (n - 1) * G) / float(n)
    out = []
    for i, (title, meas, cap, colour) in enumerate(tiles):
        is_hex = isinstance(colour, str) and colour.startswith("#")
        tx = x + i * (tw + G)
        bar = accent if accent else (colour if is_hex else TEAL)
        out.append(tick(vn("kpiTick"), tx, y, 4, h, bar))
        out.append(card(vn("kpi"), tx + 4, y, tw - 4, h, disp(meas),
                        title=title, subtitle_measure=cap,
                        value_color=colour if is_hex else None,
                        value_color_measure=None if is_hex else colour,
                        size=FS_KPI, title_size=FS_CAP))
    return out


def narrative(y, h, measures, x=M, w=CW):
    """Dynamic, measured sentences - never a hard-coded narrative.

    The one tinted surface in the body of the page. Everything else on the
    paper is white or nothing, so the strip that reads as prose looks like a
    pull-quote rather than another row of tiles.
    """
    n = len(measures)
    tw = (w - (n - 1) * G) / float(n)
    return [card(vn("ins"), x + i * (tw + G), y, tw, h, meas, size=10,
                 value_color=TEXT_MID, bg=BG_QUOTE, border=None)
            for i, meas in enumerate(measures)]


# ==========================================================================
# chart builders
# ==========================================================================
def line_chart(name, x, y, w, h, projections, title, subtitle=None,
               subtitle_measure=None, title_measure=None, colours=None,
               legend=True, tooltips=None):
    # Continuous, not categorical: at 90+ dates a categorical axis prints every
    # label and becomes an unreadable band of overlapping text.
    o = axis_objects(legend=legend, cat_type="Scalar")
    o["labels"] = [obj({"show": lit(False)})]
    o["lineStyles"] = [obj({"strokeWidth": lit(2.5), "showMarker": lit(False),
                            "lineStyle": lit("solid")})]
    if colours:
        o["dataPoint"] = [obj({"fill": solid(c)}, sel_meta(qref(p)))
                          for p, c in zip(projections, colours)]
    roles = {"Category": [pc("Dim_Date", "Date")], "Y": projections}
    if tooltips:
        roles["Tooltips"] = tooltips
    return visual(name, x, y, w, h, "lineChart", roles=roles, objects=o,
                  container=chrome(title=title, title_measure=title_measure,
                                   subtitle=subtitle,
                                   subtitle_measure=subtitle_measure,
                                   title_size=FS_PANEL))


def line_chart_by(name, x, y, w, h, legend_proj, value_proj, title,
                  subtitle=None, subtitle_measure=None, title_measure=None,
                  tooltips=None,
                  cat_proj=None):
    """One line per member of a dimension - stages, clients, programs.

    Weekly grain, on a scalar axis keyed to the Monday of each week.

    The axis matters more than it sounds. The earlier version put the text
    "Year-Week" on a categorical axis, which gives every week its own slot and
    prints every label: at 91 days that was merely tight, and at 78 weeks it
    was 78 labels all truncated to "20..." behind a horizontal scrollbar. A
    real date on a scalar axis is spaced by time and thins its own labels, so
    the same chart reads at three months or at three years.

    (The note that used to live here said a scalar axis with a Series legend
    drew no plot at all. That was true, but the cause was the axis type being
    written as "Continuous" - the label the UI shows - where the JSON only
    accepts "Scalar". With the right value it plots.)

    Weekly rather than daily is still deliberate: the daily grain is on page 1
    as a single series and on page 4 against its baseline, and this chart
    answers the different question of how the series move relative to one
    another.
    """
    o = axis_objects(legend=True, cat_type="Scalar", cat_size=8)
    o["labels"] = [obj({"show": lit(False)})]
    o["lineStyles"] = [obj({"strokeWidth": lit(2), "showMarker": lit(False)})]
    roles = {"Category": [cat_proj or pc("Dim_Date", "Week Start",
                                         display="Week")],
             "Y": [value_proj], "Series": [legend_proj]}
    if tooltips:
        roles["Tooltips"] = tooltips
    return visual(name, x, y, w, h, "lineChart", roles=roles, objects=o,
                  container=chrome(title=title, title_measure=title_measure,
                                   subtitle=subtitle,
                                   subtitle_measure=subtitle_measure,
                                   title_size=FS_PANEL))


def bar_chart(name, x, y, w, h, category, value, title, subtitle=None,
              subtitle_measure=None, title_measure=None, colour=BLUE,
              colour_measure=None, sort_measure=None, tooltips=None,
              horizontal=True):
    """Horizontal bars keep long client names readable instead of rotating them."""
    o = axis_objects(legend=False, cat_type="Categorical")
    if horizontal:
        o["categoryAxis"][0]["properties"]["maxMarginFactor"] = lit(45)
    # Display units are left at None deliberately. Auto reads well at
    # production volumes - 653,297 becomes 653K - but it destroys the small
    # case: 122, 123 and 97 all render as "0.1K", three different bars
    # labelled identically. Precision at both sizes beats tidiness at one.
    o["labels"] = [obj({"show": lit(True), "fontSize": lit(FS_CAP),
                        "color": solid(TEXT_HI), "fontFamily": lit(FONT),
                        "labelDisplayUnits": lit(1)})]
    if colour_measure:
        # Without the wildcard selector the fill is evaluated once, for the
        # series as a whole, and every bar comes out the colour the measure
        # returns with no category in context - which for the stage palette is
        # the "other" slate. The wildcard is what makes Power BI evaluate it
        # per data point.
        o["dataPoint"] = [obj({"fill": solid_m(colour_measure)},
                              {"data": [{"dataViewWildcard":
                                         {"matchingOption": 0}}]})]
    else:
        o["dataPoint"] = [obj({"fill": solid(colour)})]
    roles = {"Category": category if isinstance(category, list) else [category],
             "Y": [value]}
    if tooltips:
        roles["Tooltips"] = tooltips
    srt = sort_by(measure_expr(sort_measure), "Descending") if sort_measure else None
    return visual(name, x, y, w, h,
                  "barChart" if horizontal else "columnChart",
                  roles=roles, objects=o, sort=srt,
                  container=chrome(title=title, title_measure=title_measure,
                                   subtitle=subtitle,
                                   subtitle_measure=subtitle_measure,
                                   title_size=FS_PANEL))


def stacked_mix(name, x, y, w, h, category, series, value, title, subtitle=None,
                subtitle_measure=None, tooltips=None):
    """100% stacked columns: the shape of each row's journey, not its size.

    Columns rather than bars. Three clients as horizontal bars had to share
    whatever height was left under the title, subtitle and legend, and the third
    one ended up behind a scrollbar; as columns they share the width instead,
    which there is plenty of.
    """
    o = axis_objects(legend=True, legend_pos="Top", cat_type="Categorical",
                     cat_size=8)
    o["labels"] = [obj({"show": lit(True), "fontSize": lit(8),
                        "color": solid(TEXT_HI), "fontFamily": lit(FONT)})]
    roles = {"Category": [category], "Series": [series], "Y": [value]}
    if tooltips:
        roles["Tooltips"] = tooltips
    return visual(name, x, y, w, h, "hundredPercentStackedColumnChart",
                  roles=roles, objects=o,
                  container=chrome(title=title, subtitle=subtitle,
                                   subtitle_measure=subtitle_measure,
                                   title_size=FS_PANEL))


def matrix(name, x, y, w, h, rows, values, title, subtitle=None,
           subtitle_measure=None, title_measure=None, columns=None,
           colour_rules=None,
           back_rules=None, font=FS_CAP, subtotals=False, stepped=True):
    o = {
        "grid": [obj({"gridVertical": lit(False), "gridHorizontal": lit(True),
                      "gridHorizontalColor": solid(BORDER_SOFT),
                      "gridHorizontalWeight": lit(1),
                      "outlineWeight": lit(0), "rowPadding": lit(3),
                      "textSize": lit(font)})],
        "columnHeaders": [obj({"fontColor": solid(TEXT_LOW),
                               "backColor": solid(BG_CARD),
                               "fontSize": lit(font), "fontFamily": lit(FONT_SEMI),
                               "alignment": lit("left"), "wordWrap": lit(True),
                               "autoSizeColumnWidth": lit(True)})],
        "rowHeaders": [obj({"fontColor": solid(TEXT_HI),
                            "backColor": solid(BG_CARD),
                            "fontSize": lit(font), "fontFamily": lit(FONT),
                            "steppedLayout": lit(stepped),
                            "steppedLayoutIndentation": lit(12)})],
        "values": [obj({"fontColor": solid(TEXT_HI),
                        "backColor": solid(BG_CARD),
                        "fontColorPrimary": solid(TEXT_HI),
                        "backColorPrimary": solid(BG_CARD),
                        "fontColorSecondary": solid(TEXT_HI),
                        "backColorSecondary": solid(BAND_ALT),
                        "bandedRowHeadersandTotal": lit(True),
                        "fontSize": lit(font), "fontFamily": lit(FONT)})],
        "subTotals": [obj({"rowSubtotals": lit(subtotals),
                           "columnSubtotals": lit(False)})],
        "total": [obj({"show": lit(subtotals)})],
    }
    for r in (colour_rules or []) + (back_rules or []):
        o["values"].append(r)
    roles = {"Rows": rows, "Values": values}
    if columns:
        roles["Columns"] = columns
    return visual(name, x, y, w, h, "pivotTable", roles=roles, objects=o,
                  container=chrome(title=title, title_measure=title_measure,
                                   subtitle=subtitle,
                                   subtitle_measure=subtitle_measure,
                                   title_size=FS_PANEL))


def data_table(name, x, y, w, h, projections, title, subtitle=None,
               subtitle_measure=None, title_measure=None, sort=None,
               colour_rules=None, font=FS_CAP, header=False):
    t = table_objects(font_size=font, header_size=font, row_pad=4, wrap=False)
    for r in (colour_rules or []):
        t["values"].append(r)
    return visual(name, x, y, w, h, "tableEx", roles={"Values": projections},
                  objects=t, sort=sort,
                  container=chrome(title=title, title_measure=title_measure,
                                   subtitle=subtitle,
                                   subtitle_measure=subtitle_measure,
                                   title_size=FS_PANEL, header=header))


# ==========================================================================
# the reminder journey band
# ==========================================================================
def journey_band(x, y, w, h, accent_deep):
    """Four stage slots and three connectors, every one of them measure-driven.

    Nothing here is a static shape. A slot whose stage is not part of the
    current journey resolves to an empty string on every card it is made of and
    so disappears completely, and the connector into it disappears with it. That
    is what makes a one-stage journey look deliberate rather than like a
    four-stage journey with three things broken.
    """
    v = [panel(vn("jPanel"), x, y, w, h, bg=BG_BAND, border=BORDER, z=0)]
    v += section(x + 14, y + 5, 360, "REMINDER JOURNEY", accent_deep)
    v.append(card(vn("jPath"), x + 380, y + 5, w - 394, 30, "Journey Path Label",
                  size=10, value_color=TEXT_MID, transparent=True))

    arrow_w = 44
    inner_x = x + 12
    sw = ((w - 24) - 3 * arrow_w) / 4.0
    top = y + 5 + SECT_H + 5
    # 8.5pt needs ~22px of card, not 19: at 19 Desktop clipped both captions.
    # A card does not shrink small text to fit the way it shrinks a big value,
    # so a 10pt run needs about 2.4x its point size of container. At 22px the
    # stage labels and the journey path had their capitals shaved off the top -
    # while the 8.5pt captions below them, in boxes of the same height, were
    # fine. That difference is the whole rule.
    lab_h, val_h, cap_h, day_h = 30, 46, 22, 22

    for i in range(4):
        sx = inner_x + i * (sw + arrow_w)
        n = i + 1
        v.append(card(vn("jLab"), sx, top, sw, lab_h, "REM%d Stage Label" % n,
                      size=10, value_color=STAGE_TEXT[i], transparent=True))
        # The card prints text, not a number: a BLANK would render as the
        # literal "(Blank)" and leave a ghost stage behind.
        v.append(card(vn("jVal"), sx, top + lab_h, sw, val_h,
                      "REM%d Journey Value" % n, size=28,
                      value_color=TEXT_HI, transparent=True))
        v.append(card(vn("jCap"), sx, top + lab_h + val_h, sw, cap_h,
                      "REM%d Stage Caption" % n, size=FS_CAP,
                      value_color=TEXT_MID, transparent=True))
        v.append(card(vn("jDay"), sx, top + lab_h + val_h + cap_h, sw, day_h,
                      "REM%d Day Caption" % n, size=8, value_color=TEXT_LOW,
                      transparent=True))
        if i < 3:
            v.append(card(vn("jArr"), sx + sw, top + lab_h, arrow_w, val_h,
                          "REM%d Arrow" % n, size=18, value_color=TEXT_LOW,
                          transparent=True))
    return v


# ==========================================================================
# tooltip measure sets (spec section 54)
# ==========================================================================
TT_DATE = [pm("Email Volume"), pm("REM1 Volume"), pm("REM2 Volume"),
           pm("REM3 Volume"), pm("REM4 Volume"),
           pm("Previous Available Date"), pm("Day-over-Day Change %")]
TT_CLIENT = [pm("Email Volume"), pm("Program Count"), pm("Journey Stage Count"),
             pm("REM1 Volume"), pm("REM2 Volume"), pm("REM3 Volume"),
             pm("REM4 Volume")]
TT_PROGRAM = [pm("Email Volume"), pm("Client Count"), pm("Journey Stage Count"),
              pm("Creative Count")]
TT_REMINDER = [pm("Email Volume"), pm("Reminder Stage Share"),
               pm("Latest Day Volume"), pm("Day-over-Day Change %"),
               pm("Creative Count")]
TT_CREATIVE = [pm("Email Volume"), pm("Client Count"), pm("Program Count"),
               pm("Reminder Count")]

P_CLIENT = pc("Dim_Client", "Client_name", display="Client")
P_PROGRAM = pc("Dim_Program", "Program", display="Program")
P_REMINDER = pc("Dim_Reminder", "Reminder Display Name", display="Reminder")
P_CREATIVE = pc("Dim_CommCode", "comm_code", display="Creative")
P_SITE = pc("Dim_Site", "site_code", display="Site")
P_VOLUME = pm("Email Volume", display="Email Volume")


# ==========================================================================
# page 1 - Volume Tracking
# ==========================================================================
def page_command():
    pid = "pgCommand"
    v, accent, accent_deep = header(pid)

    y = Y0
    v += kpi_row(y, accent=accent, tiles=[
        ("TOTAL EMAIL VOLUME", "Email Volume", "Population Split Label", TEXT_HI),
        ("LATEST DAY", "Latest Day Volume", "Day-over-Day Label", TEXT_HI),
        ("AVERAGE PER ACTIVE DAY", "Average Daily Volume",
         "Active Days Caption", TEXT_HI),
        ("CLIENTS", "Client Count", "Top Client Short", TEXT_HI),
        ("PROGRAMS", "Program Count", "Top Program Short", TEXT_HI),
        ("ACTIVE REMINDER STAGES", "Active Reminder Stages",
         "Journey Stage Summary", TEXT_HI),
    ])

    y += KPI_H + 6
    v += journey_band(M, y, CW, 172, accent_deep)

    y += 178
    tw = 844
    v.append(line_chart(vn("cmTrend"), M, y, tw, 210, [pm("Email Volume")],
                        None, title_measure="Trend Title",
                        subtitle="Test-only email volume by business date",
                        colours=[accent], legend=False, tooltips=TT_DATE))
    # Columns, not bars: four stages in a short panel of horizontal bars gave
    # each one about 18px and Power BI put the rest behind a scrollbar.
    v.append(bar_chart(vn("cmDist"), M + tw + G, y, CW - tw - G, 210,
                       P_REMINDER, pm("Email Volume"), "REMINDER DISTRIBUTION",
                       subtitle="Only stages present in the selection are drawn",
                       colour_measure="Reminder Stage Colour",
                       horizontal=False, tooltips=TT_REMINDER))

    # Client and program contribution deliberately do not appear here: they are
    # the entire subject of page 3, and carrying them on both pages was the
    # clearest of the duplications that made this report feel larger than it read.
    y += 216
    v += narrative(y, PAGE_H - y - M, [
        "Insight Reminder Mix", "Insight Top Client", "Insight Top Program",
        "Insight Latest Movement"])
    return page(pid, "1 - Volume Tracking", 0, v)


# ==========================================================================
# page 2 - Reminder Journey
# ==========================================================================
def page_journey():
    pid = "pgJourney"
    v, accent, accent_deep = header(pid)

    y = Y0
    v += kpi_row(y, accent=accent, tiles=[
        ("TOTAL EMAIL VOLUME", "Email Volume", "Population Split Label", TEXT_HI),
        ("STAGES IN THIS JOURNEY", "Journey Stage Count", "Journey Path Label",
         TEXT_HI),
        ("STAGES WITH VOLUME IN PERIOD", "Active Reminder Stages",
         "Selected Period Label", TEXT_HI),
        ("LATEST DAY", "Latest Day Volume", "Day-over-Day Label", TEXT_HI),
    ])

    # Deliberately not the journey card band from page 1: the mix chart answers
    # a different question - the shape of each client's journey rather than the
    # size of the whole one - so the two pages do not restate each other.
    y += KPI_H + 6
    hw = (CW - G) / 2.0
    v.append(stacked_mix(vn("jyMix"), M, y, hw, 170, P_CLIENT, P_REMINDER,
                         pm("Top N Client Volume", display="Email Volume"),
                         "STAGE MIX BY CLIENT",
                         subtitle_measure="Client Coverage Caption",
                         tooltips=TT_REMINDER))
    v.append(bar_chart(vn("jyStage"), M + hw + G, y, hw, 170, P_REMINDER,
                       pm("Email Volume"), "VOLUME BY STAGE",
                       subtitle="Stage order, never alphabetical",
                       colour_measure="Reminder Stage Colour",
                       horizontal=False, tooltips=TT_REMINDER))

    y += 182
    v.append(line_chart_by(vn("jyTrend"), M, y, CW, 146, P_REMINDER,
                           pm("Email Volume"),
                           "WEEKLY VOLUME BY REMINDER STAGE",
                           subtitle="One line per stage actually present - the "
                                    "legend never invents a stage that is not "
                                    "in the journey. Weekly, so the stages can "
                                    "be compared with each other.",
                           tooltips=TT_DATE))

    y += 152
    v.append(matrix(vn("jyMatrix"), M, y, CW, PAGE_H - y - M,
                    rows=[P_REMINDER, P_CREATIVE],
                    values=[P_VOLUME,
                            pm("Reminder Stage Share", display="% of Stages"),
                            pm("Stage Volume Movement", display="Volume Movement"),
                            pm("Stage Volume Movement %", display="Movement %"),
                            pm("Latest Day Volume", display="Latest Day"),
                            pm("Day-over-Day Change %", display="DoD %"),
                            pm("Creative Count", display="Creatives"),
                            pm("Site Count", display="Sites")],
                    title="STAGE-TO-STAGE DETAIL",
                    subtitle="Movement is against the previous stage that "
                             "exists here - a volume difference, not a conversion",
                    colour_rules=[
                        value_color_rule(pm("Stage Volume Movement",
                                            display="Volume Movement"),
                                         "Stage Movement Colour"),
                        value_color_rule(pm("Day-over-Day Change %",
                                            display="DoD %"),
                                         "Day-over-Day Colour")]))
    return page(pid, "2 - Reminder Journey", 1, v)


# ==========================================================================
# page 3 - Drivers  (also the drill-through target for client and program)
# ==========================================================================
def page_drivers():
    pid = "pgDrivers"
    v, accent, accent_deep = header(pid)

    y = Y0
    v += kpi_row(y, accent=accent, tiles=[
        ("TOTAL EMAIL VOLUME", "Email Volume", "Population Split Label", TEXT_HI),
        ("CLIENTS", "Client Count", "Top Client Short", TEXT_HI),
        ("PROGRAMS", "Program Count", "Top Program Short", TEXT_HI),
        ("CREATIVES", "Creative Count", "Top Creative Short", TEXT_HI),
    ])

    # Three rankings side by side. These used to be three separate pages of the
    # same three visuals with one field swapped; as one row they can actually be
    # compared, which was the point of having them at all.
    y += KPI_H + 6
    v += section(M, y, 700, "WHO AND WHAT CARRIES THE VOLUME", accent_deep)
    y += SECT_H + 4
    tw = (CW - 2 * G) / 3.0
    # Each ranking is drawn through its Top-N measure, which returns BLANK for
    # members outside the cut so the chart drops them. The subtitle is the
    # coverage caption, which states the cut and what share of the selection it
    # covers - a ranking that silently shows ten of a hundred and thirty-seven
    # clients without saying so is a lie by omission.
    v.append(bar_chart(vn("drClient"), M, y, tw, 280,
                       [P_CLIENT, P_PROGRAM, P_REMINDER],
                       pm("Top N Client Volume", display="Email Volume"),
                       "BY CLIENT", subtitle_measure="Client Coverage Caption",
                       colour=TEAL, sort_measure="Top N Client Volume",
                       tooltips=TT_CLIENT))
    v.append(bar_chart(vn("drProg"), M + tw + G, y, tw, 280,
                       [P_PROGRAM, P_REMINDER, P_CREATIVE],
                       pm("Top N Program Volume", display="Email Volume"),
                       "BY PROGRAM", subtitle_measure="Program Coverage Caption",
                       colour=STEEL, sort_measure="Top N Program Volume",
                       tooltips=TT_PROGRAM))
    v.append(bar_chart(vn("drComm"), M + 2 * (tw + G), y, tw, 280,
                       [P_CREATIVE, P_CLIENT, P_REMINDER],
                       pm("Top N Creative Volume", display="Email Volume"),
                       "BY CREATIVE / COMM CODE",
                       subtitle_measure="Creative Coverage Caption",
                       colour=CLAY, sort_measure="Top N Creative Volume",
                       tooltips=TT_CREATIVE))

    # The weekly-by-client line chart that used to sit here is gone. Ten
    # overlapping weekly lines across seventy-eight weeks was never readable,
    # and at 128 clients it did not render at all. Pages 1, 2 and 4 carry the
    # time dimension; this page answers "who drives the volume", and the space
    # is what lets the three rankings actually show ten bars each.
    y += 286
    v.append(matrix(vn("drMatrix"), M, y, CW, PAGE_H - y - M,
                    rows=[P_CLIENT, P_PROGRAM, P_REMINDER, P_CREATIVE],
                    values=[P_VOLUME,
                            pm("% of Selected Volume", display="% of Total"),
                            pm("Reminder Stage Share",
                               display="% of Reminder Volume"),
                            pm("Volume on Report Latest Day",
                               display="Latest Report Day"),
                            pm("Day-over-Day Change %", display="DoD %"),
                            pm("Site Count", display="Sites")],
                    title=None, title_measure="Matrix Title",
                    subtitle="Expand a client to walk the journey down to "
                             "creative. Right-click a client or a program "
                             "anywhere in the report to drill through to this "
                             "page.",
                    colour_rules=[value_color_rule(
                        pm("Day-over-Day Change %", display="DoD %"),
                        "Day-over-Day Colour")]))

    # One page serves as the drill-through target for both fields, instead of
    # the two extra near-duplicate pages an earlier cut carried.
    return page(pid, "3 - Drivers", 2, v,
                ptype="Drillthrough",
                binding={"name": "driversBinding", "type": "Drillthrough",
                         "parameters": [{"name": "drillClient",
                                         "boundFilter": "drillClient"},
                                        {"name": "drillProgram",
                                         "boundFilter": "drillProgram"}]},
                filters=[drillthrough_filter("drillClient", "Dim_Client",
                                             "Client_name"),
                         drillthrough_filter("drillProgram", "Dim_Program",
                                             "Program")])


# ==========================================================================
# page 4 - Daily Operations
# ==========================================================================
def page_ops():
    """The operational records, unsummarised.

    One table, the full width and height of the page, at the grain the feed
    actually arrives in: one row per client, group, creative, site, stage,
    program, date and T/C indicator. No tiles, no charts, no commentary.

    Every column here is a dimension column or a plain sum, which is what lets
    it hold up at 100k rows. The trailing-baseline and exception measures are
    deliberately not on it: evaluating a 14-day window per source row is what
    made the earlier version of this table render as an empty panel at scale.
    They remain available on the page-1 journey band and in the tooltips.

    All eight slicers and the date range still drive it, so this is the page to
    come to when the question is "show me the actual rows behind that number".
    """
    pid = "pgOps"
    v, accent, accent_deep = header(pid)

    y = Y0
    # The table stops short of the page foot to leave room for the export
    # hint below it.
    v.append(data_table(vn("opRaw"), M, y, CW, PAGE_H - y - M - 28,
                        [pc("Dim_Date", "Date", display="Date"),
                         P_CLIENT,
                         pc("Dim_ClientGroup", "client_group",
                            display="Client Group"),
                         P_PROGRAM, P_REMINDER, P_CREATIVE, P_SITE,
                         pc("Dim_Population", "Population", display="T_C_IND"),
                         # Total Rows, not Source Rows. Source Rows carries a
                         # REMOVEFILTERS, so it is non-blank for every possible
                         # combination of dimensions - which makes a table
                         # materialise the entire cartesian product of date x
                         # client x group x program x stage x creative x site,
                         # printing dated rows that carry no volume because no
                         # such record exists.
                         pm("Total Rows", display="Rows"),
                         P_VOLUME,
                         pm("Email Volume (All Populations)",
                            display="Volume (T + C)")],
                        "OPERATIONAL RECORDS",
                        subtitle_measure="Raw Records Caption",
                        sort=sort_by(column_expr("Dim_Date", "Date"),
                                     "Descending"),
                        font=FS_CAP, header=True))
    v.append(card(vn("opExport"), M, PAGE_H - M - 24, CW, 24,
                  "Export Hint", size=FS_CAP, value_color=TEXT_LOW,
                  transparent=True))
    return page(pid, "4 - Daily Operations", 3, v)


# ==========================================================================
# page 5 - Records & Data Quality
# ==========================================================================
def page_data():
    pid = "pgData"
    v, accent, accent_deep = header(pid)

    y = Y0
    v += kpi_row(y, accent=accent, tiles=[
        ("ROWS LOADED", "Source Rows", "Data Quality Short", TEXT_HI),
        ("ROWS IN SELECTION", "Total Rows", "Reconciliation Short", TEXT_HI),
        ("TEST ROWS", "Test Rows", "Population Split Label", TEXT_HI),
        ("CONTROL ROWS", "Control Rows", "Control Presence Short", TEXT_HI),
        ("EMAIL VOLUME (TEST ONLY)", "Email Volume", "Population Split Label",
         TEXT_HI),
        ("ROWS NEEDING REVIEW", "Rows Needing Review", "Data Quality Status",
         "Data Quality Status Colour"),
    ])

    y += KPI_H + 6
    v += section(M, y, 900,
                     "VALIDATION CHECKS     nothing is dropped at load - "
                     "failing rows are flagged and counted here", accent_deep)
    y += SECT_H + 4
    checks = ["Null Client Rows", "Null Program Rows", "Null Reminder Rows",
              "Null Date Rows", "Null Email Volume Rows",
              "Negative Email Values", "Unexpected T/C Values",
              "Unexpected Reminder Values", "Duplicate Rows"]
    cw = (CW - 8 * G) / 9.0
    for i, meas in enumerate(checks):
        v.append(card(vn("dqChk"), M + i * (cw + G), y, cw, 70, disp(meas),
                      title=meas.upper(), size=20, title_size=7.5))

    y += 76
    v += section(M, y, 1000,
                     "THE RAW EXTRACT     one row per client, group, creative, "
                     "site, stage, program, date and population", accent_deep)
    y += SECT_H + 4
    v.append(data_table(vn("dqTable"), M, y, CW, PAGE_H - y - M,
                        [pc("Dim_Date", "Date", display="Date"),
                         P_CLIENT,
                         pc("Dim_ClientGroup", "client_group",
                            display="Client Group"),
                         P_PROGRAM, P_REMINDER, P_CREATIVE, P_SITE,
                         pc("Dim_Population", "Population", display="T_C_IND"),
                         pc("Dim_Population", "Receives Email",
                            display="Receives Email"),
                         pc("Fact_ReminderVolume", "Row Status",
                            display="Row Status"),
                         pm("Total Rows", display="Rows"),
                         P_VOLUME,
                         pm("Email Volume (All Populations)",
                            display="Volume (All Populations)")],
                        "EXTRACT DETAIL",
                        subtitle="Row Status is Review when any check failed. "
                                 "Email Volume is Test-only; Volume (All "
                                 "Populations) is the raw column sum.",
                        sort=sort_by(column_expr("Dim_Date", "Date"),
                                     "Descending")))
    return page(pid, "5 - Records & Quality", 4, v)


# ==========================================================================
def theme():
    # Series colours follow reminder-stage order, so a multi-series line chart
    # by reminder picks up the same identity the journey cards use.
    return {
        "name": "CDPCommandCenter",
        "dataColors": STAGE_COLOURS + [GREEN, SLATE, "#8FA39B", RED],
        "background": BG_PAGE,
        "backgroundLight": BG_CARD,
        "foreground": TEXT_HI,
        "foregroundNeutralSecondary": TEXT_MID,
        "foregroundNeutralTertiary": TEXT_LOW,
        "tableAccent": TEAL,
        "good": GREEN, "neutral": AMBER, "bad": RED,
        "textClasses": {
            "title": {"fontSize": FS_PANEL, "fontFace": FONT_SEMI,
                      "color": TEXT_HI},
            "label": {"fontSize": FS_BODY, "fontFace": FONT, "color": TEXT_MID},
            "callout": {"fontSize": FS_KPI, "fontFace": FONT_SEMI,
                        "color": TEXT_HI},
        },
    }


def rmtree_resilient(path):
    for _ in range(5):
        if not os.path.isdir(path):
            return
        try:
            shutil.rmtree(path)
            return
        except OSError:
            time.sleep(0.2)


def main():
    rmtree_resilient(STAGE_DIR)

    builders = [page_command, page_journey, page_drivers, page_ops, page_data]

    order, total = [], 0
    for build in builders:
        p, visuals = build()
        order.append(p["name"])
        write(os.path.join(DEF, "pages", p["name"], "page.json"), p)
        for vis in visuals:
            write(os.path.join(DEF, "pages", p["name"], "visuals",
                               vis["name"], "visual.json"), vis)
        total += len(visuals)

    write(os.path.join(DEF, "pages", "pages.json"),
          {"$schema": SCHEMA_PAGES, "pageOrder": order,
           "activePageName": order[0]})
    write(os.path.join(DEF, "report.json"), {
        "$schema": SCHEMA_REPORT,
        "layoutOptimization": "None",
        "themeCollection": {"customTheme": {
            "name": "CDPCommandCenter", "reportVersionAtImport": "5.55",
            "type": "RegisteredResources"}},
        "resourcePackages": [{
            "name": "RegisteredResources", "type": "RegisteredResources",
            "items": [{"name": "CDPCommandCenter.json",
                       "path": "CDPCommandCenter.json", "type": "CustomTheme"}]}],
        "settings": {"useStylableVisualContainerHeader": True,
                     "hideVisualContainerHeader": False,
                     "exportDataMode": "AllowSummarized"},
    })
    write(os.path.join(DEF, "version.json"),
          {"$schema": SCHEMA_VERSION, "version": "4.0.0"})

    # ---- lower to the format Desktop actually reads ----------------------
    rmtree_resilient(REPORT_DIR)
    write(os.path.join(REPORT_DIR, "definition.pbir"), {
        "version": "1.0",
        "datasetReference": {"byPath": {"path": "../%s.SemanticModel" % PROJECT}},
    })
    write(os.path.join(REPORT_DIR, ".platform"), {
        "$schema": SCHEMA_PLATFORM,
        "metadata": {"type": "Report", "displayName": PROJECT},
        "config": {"version": "2.0",
                   "logicalId": str(uuid.uuid5(NS, "logical::Report"))},
    })
    write(os.path.join(REPORT_DIR, "StaticResources", "RegisteredResources",
                       "CDPCommandCenter.json"), theme())
    write(os.path.join(ROOT, PROJECT + ".pbip"), {
        "version": "1.0",
        "artifacts": [{"report": {"path": PROJECT + ".Report"}}],
        "settings": {"enableAutoRecovery": True},
    })

    import pbir_to_legacy
    legacy = pbir_to_legacy.build_legacy(DEF)

    # The brand mark travels with the report as a registered resource rather
    # than as a base64 blob in the JSON: the file stays a file, the report.json
    # stays diffable, and Desktop resolves it the same way it resolves the
    # theme. Type 100 is an image; the theme beside it is type 202.
    if has_logo():
        dest = os.path.join(REPORT_DIR, "StaticResources",
                            "RegisteredResources", LOGO_NAME)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.copyfile(LOGO_SRC, dest)
        for rp in legacy.get("resourcePackages", []):
            pkg = rp.get("resourcePackage") or {}
            if pkg.get("name") == "RegisteredResources":
                pkg["items"].append({"name": LOGO_NAME, "path": LOGO_NAME,
                                     "type": 100})

    write(os.path.join(REPORT_DIR, "report.json"), legacy)
    shipped = sum(len(s["visualContainers"]) for s in legacy["sections"])

    print("report written to %s" % REPORT_DIR)
    if has_logo():
        print("  brand mark: %s registered" % LOGO_NAME)
    else:
        print("  brand mark: NOT FOUND - drop it at Assets/%s and rebuild "
              "(see Assets/README.md)" % LOGO_NAME)
    print("  pages:   %d" % len(order))
    print("  visuals: %d staged, %d shipped in %d sections"
          % (total, shipped, len(legacy["sections"])))
    for p in order:
        n = len(os.listdir(os.path.join(DEF, "pages", p, "visuals")))
        print("    %-14s %3d visuals" % (p, n))
    return 0


if __name__ == "__main__":
    sys.exit(main())
