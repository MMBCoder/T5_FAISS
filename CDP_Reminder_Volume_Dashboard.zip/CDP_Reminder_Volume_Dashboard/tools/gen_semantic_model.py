# -*- coding: utf-8 -*-
"""Generates the CDP semantic model as TMDL.

Run: python tools/gen_semantic_model.py
"""
import os
import shutil
import sys
import uuid

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import model_queries as Q
import model_measures as MM
from tmdl import (Column, Measure, Table, expression, shared_expression,
                  relationship, tag)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT = "CDP_Reminder_Volume_Dashboard"
MODEL_DIR = os.path.join(ROOT, PROJECT + ".SemanticModel")
DEF_DIR = os.path.join(MODEL_DIR, "definition")
TABLES_DIR = os.path.join(DEF_DIR, "tables")

BUNDLED_SOURCE = os.path.join(ROOT, "Data",
                              "CDP_Projects_Summary_History.csv")
# Power Query cannot resolve a path relative to the report file, so this
# has to be absolute. Deriving it from ROOT instead of hard-coding one
# machine's Downloads folder means a rebuild on any machine yields a
# model that refreshes without anyone touching a parameter.
DEFAULT_SOURCE = BUNDLED_SOURCE

NS = uuid.UUID("3f7a1c05-8d2e-5a41-9b63-7c04e1a9d820")

TEXT, DATE, NUM, INT = "string", "dateTime", "double", "int64"


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\r\n") as fh:
        fh.write(text.rstrip() + "\n")


# --------------------------------------------------------------------------
# fact
# --------------------------------------------------------------------------
def fact_table():
    key = lambda n, t, d: Column(n, t, desc=d, hidden=True)
    cols = [
        key("Client_name", TEXT, "Client the reminder belongs to. Hidden: filter "
            "through Dim_Client so the model stays a star."),
        key("client_group", TEXT, "Client group code. Hidden: filter through "
            "Dim_ClientGroup."),
        key("comm_code", TEXT, "Communication / creative code. Hidden: filter "
            "through Dim_CommCode."),
        key("site_code", TEXT, "Site code. Hidden: filter through Dim_Site."),
        key("rem_flag", TEXT, "Reminder stage flag as it appears in the source. "
            "Hidden: filter through Dim_Reminder, which also carries stage order."),
        key("Program", TEXT, "Program code. Hidden: filter through Dim_Program."),
        Column("file_date", DATE, fmt="dd-mmm-yyyy", hidden=True,
               desc="Business date of the send. Joined to Dim_Date[Date]; use "
                    "Dim_Date for every date axis."),
        key("t_c_ind", TEXT, "Test / Control indicator. Hidden: filter through "
            "Dim_Population."),
        Column("Number of Email", NUM, fmt="#,##0", hidden=True,
               desc="Email count on the row. Deliberately hidden: summing this "
                    "column directly would silently include Control rows. Use "
                    "the [Email Volume] measure, which is Test-only."),
    ]
    for c, d in [
        ("DQ Missing Client", "1 when Client_name is null."),
        ("DQ Missing Program", "1 when Program is null."),
        ("DQ Missing Reminder", "1 when rem_flag is null."),
        ("DQ Missing Date", "1 when file_date could not be parsed."),
        ("DQ Missing Volume", "1 when the volume column is null."),
        ("DQ Negative Volume", "1 when the volume is below zero."),
        ("DQ Invalid Population", "1 when t_c_ind is neither T nor C."),
        ("DQ Invalid Reminder", "1 when rem_flag is not REM followed by digits."),
        ("DQ Duplicate Row", "1 when the business grain repeats."),
        ("DQ Issue Count", "Number of checks this row fails."),
    ]:
        cols.append(Column(c, INT, fmt="0", hidden=True, desc=d))
    cols.append(Column("Row Status", TEXT,
                       desc="OK, or Review when the row carries any data-quality "
                            "flag. Visible so the Data Quality page can list "
                            "offending rows."))
    return Table(
        "Fact_ReminderVolume",
        desc="One row per client, group, creative, site, reminder stage, "
             "program, date and Test/Control indicator - the grain of the source "
             "extract, loaded without filtering.\n"
             "Every row from the file is present, valid or not: the DQ columns "
             "mark problems instead of dropping rows, so report totals reconcile "
             "against the CSV exactly.",
        columns=cols, partition=Q.FACT, kind="m")


# --------------------------------------------------------------------------
# dimensions
# --------------------------------------------------------------------------
def dim_reminder():
    return Table(
        "Dim_Reminder",
        desc="Reminder stages present in the source, with the ordering the "
             "report sorts by.\n"
             "Order and display name are parsed from the digits in rem_flag, so "
             "the model is not pinned to REM1-REM4: a REM5 in a later extract "
             "labels and sorts itself correctly.",
        columns=[
            Column("rem_flag", TEXT, key=True,
                   desc="Reminder flag exactly as it appears in the source."),
            Column("Reminder Order", INT, fmt="0", hidden=True,
                   desc="Stage number parsed from rem_flag. Sorts every reminder "
                        "field; an unparseable flag sorts last at 9999."),
            Column("Reminder Display Name", TEXT, sort_by="Reminder Order",
                   desc="\"Reminder 1\". Sorted by stage number, never "
                        "alphabetically."),
            Column("Reminder Short Name", TEXT, sort_by="Reminder Order",
                   desc="\"REM1\". Compact form for chart axes and the journey "
                        "path label."),
            Column("Stage Label", TEXT, sort_by="Reminder Order",
                   desc="\"Stage 1\". Used where the word reminder is already in "
                        "the visual title."),
        ], partition=Q.DIM_REMINDER, kind="m")


def dim_client():
    return Table(
        "Dim_Client",
        desc="One row per client. Keyed on Client_name because that is what the "
             "fact joins on.\n"
             "client_group is carried here as an attribute for convenience; the "
             "authoritative group filter is Dim_ClientGroup, which joins the fact "
             "on the source value directly. If a client ever spans two groups, "
             "Client Group lists both rather than one being silently picked.",
        columns=[
            Column("Client_name", TEXT, key=True, desc="Client name."),
            Column("Client Group", TEXT,
                   desc="Group code(s) seen for this client, slash separated when "
                        "there is more than one."),
            Column("Client Group Count", INT, fmt="0", hidden=True,
                   desc="How many distinct groups this client appears under. "
                        "Anything above 1 is worth investigating."),
        ], partition=Q.DIM_CLIENT, kind="m")


def dim_client_group():
    return Table("Dim_ClientGroup",
                 desc="Client group codes, joined to the fact on the source "
                      "value so the true client-to-group relationship is "
                      "preserved.",
                 columns=[Column("client_group", TEXT, key=True,
                                 desc="Client group code.")],
                 partition=Q.DIM_CLIENT_GROUP, kind="m")


def dim_program():
    return Table("Dim_Program", desc="Programs present in the source.",
                 columns=[Column("Program", TEXT, key=True,
                                 desc="Program code, e.g. AOPQ or FOC.")],
                 partition=Q.DIM_PROGRAM, kind="m")


def dim_commcode():
    return Table(
        "Dim_CommCode",
        desc="Communication / creative codes. No descriptive names are invented: "
             "the source supplies none, and a guessed label would be read as "
             "fact.",
        columns=[
            Column("comm_code", TEXT, key=True,
                   desc="Communication / creative code."),
            Column("Creative Family", TEXT,
                   desc="First three characters of the code - the only grouping "
                        "the data itself supports."),
        ], partition=Q.DIM_COMMCODE, kind="m")


def dim_site():
    return Table("Dim_Site",
                 desc="Site codes. Kept off the executive page and used for "
                      "operational detail, tooltips and drill-through.",
                 columns=[Column("site_code", TEXT, key=True,
                                 desc="Site code.")],
                 partition=Q.DIM_SITE, kind="m")


def dim_population():
    return Table(
        "Dim_Population",
        desc="Test / Control, with the business meaning spelled out so nobody has "
             "to remember what T and C stand for.\n"
             "Both members always exist even when an extract contains only one of "
             "them - a Control member that quietly disappears would hide the fact "
             "that no control population was held back.",
        columns=[
            Column("t_c_ind", TEXT, key=True, hidden=True,
                   desc="Raw source indicator."),
            Column("Population", TEXT, sort_by="Population Order",
                   desc="Test or Control - the label to put in front of users."),
            Column("Receives Email", TEXT,
                   desc="Yes for Test, No for Control. The whole reason email "
                        "volume is Test-only."),
            Column("Population Order", INT, fmt="0", hidden=True,
                   desc="Sort order: Test first."),
        ], partition=Q.DIM_POPULATION, kind="m")


def dim_date():
    cols = [
        Column("Date", DATE, key=True, fmt="dd-mmm-yyyy", inferred=True,
               desc="Calendar date. The model's official date field - every "
                    "trend and time calculation uses this, never the raw "
                    "file_date."),
        Column("Year", INT, fmt="0", inferred=True, desc="Calendar year."),
        Column("Quarter Number", INT, fmt="0", hidden=True, inferred=True,
               desc="Sorts Quarter."),
        Column("Quarter", TEXT, sort_by="Quarter Number", inferred=True,
               desc="Calendar quarter."),
        Column("Month Number", INT, fmt="0", hidden=True, inferred=True,
               desc="Sorts Month."),
        Column("Month", TEXT, sort_by="Month Number", inferred=True,
               desc="Full month name."),
        Column("Month Short", TEXT, sort_by="Month Number", inferred=True,
               desc="Three-letter month name."),
        Column("Month Year", TEXT, sort_by="Month Year Sort", inferred=True,
               desc="\"Aug 2026\"."),
        Column("Month Year Sort", INT, fmt="0", hidden=True, inferred=True,
               desc="Sorts Month Year."),
        Column("Week Number", INT, fmt="0", inferred=True,
               desc="ISO week number."),
        Column("Year-Week", TEXT, sort_by="Year-Week Sort", inferred=True,
               desc="\"2026-W32\". Row axis of the daily heatmap."),
        Column("Year-Week Sort", INT, fmt="0", hidden=True, inferred=True,
               desc="Sorts Year-Week."),
        Column("Week Start", DATE, fmt="dd-mmm-yyyy", inferred=True,
               desc="Monday of the week. Used as the axis of the weekly "
                    "charts, which need a real date to be spaced by time "
                    "rather than crammed one slot per week."),
        Column("Day", INT, fmt="0", inferred=True, desc="Day of month."),
        Column("Day Name", TEXT, sort_by="Day Name Number", inferred=True,
               desc="Full weekday name, sorted Monday first."),
        Column("Day Name Short", TEXT, sort_by="Day Name Number", inferred=True,
               desc="Three-letter weekday name."),
        Column("Day Name Number", INT, fmt="0", hidden=True, inferred=True,
               desc="Sorts the weekday names."),
        Column("Day Label", TEXT, inferred=True, desc="\"22 Apr\"."),
        Column("Is Weekend", "boolean", inferred=True,
               desc="True for Saturday and Sunday."),
    ]
    return Table("Dim_Date",
                 desc="Date dimension covering exactly the loaded data, rounded "
                      "out to whole months. Marked as the model date table.",
                 columns=cols, partition=Q.DIM_DATE, kind="calculated",
                 date_table=True)


def measure_table():
    defs = MM.measures()
    # Two measures with the same name do not error - TMDL keeps one of them and
    # the other silently disappears, taking whatever visual was bound to it
    # with it. This caught a Top-N measure colliding with an existing insight
    # measure of the same name.
    seen, dupes = set(), []
    for m in defs:
        if m["name"] in seen:
            dupes.append(m["name"])
        seen.add(m["name"])
    if dupes:
        raise SystemExit("duplicate measure name(s): %s" % ", ".join(sorted(set(dupes))))
    ms = [Measure(m["name"], m["dax"], m["fmt"], m["desc"], m["folder"],
                  m["hidden"]) for m in defs]
    return Table("_Measures",
                 desc="Home table for every explicit measure. Holds no data of "
                      "its own; the single hidden column exists only because a "
                      "table needs one.",
                 columns=[Column("_", TEXT, hidden=True, inferred=True,
                                 desc="Placeholder.")],
                 measures=ms, partition=Q.MEASURE_HOME, kind="calculated")


# --------------------------------------------------------------------------
# name, from (fact side), from column, to (dim side), to column, cross-filter
#
# The six dimensions that carry a slicer are bi-directional. A star with
# single-direction relationships propagates dim -> fact and stops, so choosing
# Program = FOC filtered the data but left every client listed in the Client
# slicer, including clients that run no FOC programme at all. Filtering has to
# reach back up through the fact for one slicer to narrow another.
#
# The alternative - a visual-level measure filter on each slicer - was built
# and tested first. It works per item (a threshold of 100 rows correctly left
# only the one client above it) but it never sees the other slicers'
# selections, so it cannot cascade. Bi-directional relationships are what
# actually does the job.
#
# Date and Population stay single-direction on purpose:
#   Dim_Date      - the time-intelligence measures remove and replace date
#                   filters deliberately; letting the fact filter the calendar
#                   back is a good way to make "previous available day" mean
#                   something different than it says.
#   Dim_Population - both Test and Control must always be listed, even when an
#                   extract contains neither, which is the whole reason that
#                   dimension is a fixed table rather than a derived one.
BOTH = "bothDirections"

RELATIONSHIPS = [
    ("Dim_Date_Fact", "Fact_ReminderVolume", "file_date", "Dim_Date", "Date", None),
    ("Dim_Reminder_Fact", "Fact_ReminderVolume", "rem_flag", "Dim_Reminder", "rem_flag", BOTH),
    ("Dim_Client_Fact", "Fact_ReminderVolume", "Client_name", "Dim_Client", "Client_name", BOTH),
    ("Dim_ClientGroup_Fact", "Fact_ReminderVolume", "client_group", "Dim_ClientGroup", "client_group", BOTH),
    ("Dim_Program_Fact", "Fact_ReminderVolume", "Program", "Dim_Program", "Program", BOTH),
    ("Dim_CommCode_Fact", "Fact_ReminderVolume", "comm_code", "Dim_CommCode", "comm_code", BOTH),
    ("Dim_Site_Fact", "Fact_ReminderVolume", "site_code", "Dim_Site", "site_code", BOTH),
    ("Dim_Population_Fact", "Fact_ReminderVolume", "t_c_ind", "Dim_Population", "t_c_ind", None),
]


def main():
    tables = [fact_table(), dim_date(), dim_reminder(), dim_client(),
              dim_client_group(), dim_program(), dim_commcode(), dim_site(),
              dim_population(), measure_table()]

    if os.path.isdir(DEF_DIR):
        shutil.rmtree(DEF_DIR)

    # Desktop upgrades the workspace database to its own compatibility
    # level on first open, and Analysis Services refuses to go back
    # down. Declaring a lower level than the workspace already holds
    # makes reopening the project fail outright with "Tabular databases
    # do not support CompatibilityLevel downgrade". 1606 is what
    # Desktop 2.157 uses.
    write(os.path.join(DEF_DIR, "database.tmdl"),
          "database\n\tcompatibilityLevel: 1606\n")

    # ---- model ----------------------------------------------------------
    order = ["p_SourceFilePath", "Fn_CanonicalLabel", "Source_CDP"] + \
            [t.name for t in tables if t.kind == "m"]
    model = [
        "model Model",
        "\tculture: en-US",
        "\tdefaultPowerBIDataSourceVersion: powerBI_V3",
        # Stops the field list offering "Sum of Number of Email", which would
        # quietly reintroduce Control volume into a business visual.
        "\tdiscourageImplicitMeasures",
        "\tsourceQueryCulture: en-US",
        "\tdataAccessOptions",
        "\t\tlegacyRedirects",
        "\t\treturnErrorValuesAsNull",
        "",
        "annotation PBI_QueryOrder = [%s]"
        % ",".join('"%s"' % n for n in order),
        "",
        "annotation __PBI_TimeIntelligenceEnabled = 0",
        "",
        'annotation PBI_ProTooling = ["DevMode"]',
        "",
    ]
    for t in tables:
        model.append("ref table %s" % (t.name if t.name.isidentifier()
                                       else "'%s'" % t.name))
    write(os.path.join(DEF_DIR, "model.tmdl"), "\n".join(model))

    # ---- expressions ----------------------------------------------------
    exprs = [
        expression(
            "p_SourceFilePath", '"%s"' % DEFAULT_SOURCE,
            "Full path to the CDP history CSV. This is the only parameter in "
            "the model, and the only thing to change when the project moves to "
            "another machine or points at a new drop. It defaults to the copy "
            "bundled with the project under Data. A second fallback parameter "
            "used to sit beside it; two paths that both needed editing on a "
            "new machine was worse than one."),
        shared_expression(
            "Fn_CanonicalLabel", Q.CANONICAL_LABEL,
            "Chooses which spelling of a value a dimension displays when the "
            "feed spells it several ways. Prefers a properly-cased spelling, "
            "then the most frequent, then alphabetical - so the choice is "
            "deterministic and a refresh cannot silently relabel a client."),
        shared_expression(
            "Source_CDP", Q.SOURCE_CDP,
            "Reads and cleans the CSV once. The fact and every dimension derive "
            "from this, so they can never disagree about what the source says."),
    ]
    write(os.path.join(DEF_DIR, "expressions.tmdl"), "\n".join(exprs))

    # ---- relationships --------------------------------------------------
    rels = [relationship(n, ft, fc, tt, tc, cross_filter=cf)
            for n, ft, fc, tt, tc, cf in RELATIONSHIPS]
    write(os.path.join(DEF_DIR, "relationships.tmdl"), "\n".join(rels))

    # ---- tables ---------------------------------------------------------
    for t in tables:
        write(os.path.join(TABLES_DIR, t.name + ".tmdl"), t.render())

    # ---- item metadata --------------------------------------------------
    write(os.path.join(MODEL_DIR, "definition.pbism"),
          '{\n  "$schema": "https://developer.microsoft.com/json-schemas/fabric'
          '/item/semanticModel/definitionProperties/1.0.0/schema.json",\n'
          '  "version": "4.2",\n  "settings": {}\n}\n')
    write(os.path.join(MODEL_DIR, ".platform"),
          '{\n  "$schema": "https://developer.microsoft.com/json-schemas/fabric'
          '/gitIntegration/platformProperties/2.0.0/schema.json",\n'
          '  "metadata": {\n    "type": "SemanticModel",\n'
          '    "displayName": "%s"\n  },\n'
          '  "config": {\n    "version": "2.0",\n    "logicalId": "%s"\n  }\n}\n'
          % (PROJECT, str(uuid.uuid5(NS, "logical::SemanticModel"))))

    n_meas = sum(len(t.measures) for t in tables)
    n_cols = sum(len(t.columns) for t in tables)
    print("semantic model written to %s" % MODEL_DIR)
    print("  tables:        %d" % len(tables))
    print("  columns:       %d" % n_cols)
    print("  measures:      %d" % n_meas)
    print("  relationships: %d" % len(RELATIONSHIPS))
    for t in tables:
        print("    %-24s %2d cols  %3d measures  (%s)"
              % (t.name, len(t.columns), len(t.measures), t.kind))
    return 0


if __name__ == "__main__":
    sys.exit(main())
