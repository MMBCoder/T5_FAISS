# Assets

Drop the brand mark here as **`synchrony_logo.png`**.

The report picks it up automatically on the next `python tools/build.py`: the
file is copied into the report's registered resources and an image visual is
placed in the top-right of the masthead on every page. If the file is absent
the report builds without it and the generator says so, rather than shipping a
broken image reference.

A transparent PNG works best - the masthead is deep pine (`#12332F`), so a
white or light mark reads cleanly on it. Around 350x130px at 2x is plenty; the
visual scales to fit a 116x42 slot.
