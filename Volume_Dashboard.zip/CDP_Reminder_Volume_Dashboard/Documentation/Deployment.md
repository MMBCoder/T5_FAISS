# Running this dashboard on another machine

Two ways to move it, and they suit different purposes:

| | **PBIP** (this project) | **PBIX** (single file) |
|---|---|---|
| What it is | a folder of text files | one binary file |
| Contains data? | no - refreshes from the CSV | **yes, the data is embedded** |
| Needs the CSV to open? | yes | **no** - only to refresh |
| Needs a preview feature enabled? | yes | no |
| Can be rebuilt by `tools/` | yes | no |
| Best for | continuing development | handing to someone to read |

If the other machine is **yours and you will keep changing the report**, take the
PBIP (Part A). If you are **giving the dashboard to someone to look at**,
convert to PBIX (Part B) - they get the data with it and need nothing else.

---

## Part A - Moving the PBIP

### A1. Copy the whole project folder

Copy `CDP_Reminder_Volume_Dashboard/` in its entirety. It must keep its
internal structure - the `.pbip` file points at the two folders beside it by
relative path:

```text
CDP_Reminder_Volume_Dashboard/
├── CDP_Reminder_Volume_Dashboard.pbip          <- open this one
├── CDP_Reminder_Volume_Dashboard.Report/
├── CDP_Reminder_Volume_Dashboard.SemanticModel/
├── Data/CDP_Projects_Summary_History.csv       <- the ONE input file
├── Assets/, Documentation/, tools/
```

Everything in the project is relative except one thing, which Part A3 deals
with.

`Data/` holds exactly one CSV, and the model exposes exactly one parameter, so
there is never a question of which file the dashboard is reading. The build
fails if either of those stops being true.

### A2. Turn on the PBIP save option, once per machine

Power BI Desktop → **File → Options and settings → Options → Preview features**
→ tick **Power BI Project (.pbip) save option** → **OK** → restart Desktop.

Without this, Desktop will not open a `.pbip` at all.

> **Desktop version matters.** This project is built at compatibility level
> **1606** (Desktop 2.157, August 2026). A *newer* Desktop is fine. An **older**
> Desktop will refuse to open it, because Analysis Services will not downgrade
> a model. If the other machine has an older Desktop, update it - or use the
> PBIX route in Part B, saved from the older version.

### A3. Point the model at the data file

This is **the only thing that needs changing**, and it always needs changing.
Power Query stores an **absolute** path and has no way to resolve one relative
to the report - there is no "current project folder" function in M - so a copied
project still points at the path it was built on. Skip this step and every table
fails at once:

```text
Fact_ReminderVolume   This path does not exist on this machine: C:\Users\...
Dim_Reminder          This path does not exist on this machine: C:\Users\...
Dim_Client            This path does not exist on this machine: C:\Users\...
  ... and so on for all eight tables
```

That is the model's own error, not a corruption. Eight lines because eight
tables read the same file; one cause, one fix.

#### Do it in one step (recommended)

**Before opening the .pbip**, from the copied project folder:

```powershell
powershell -ExecutionPolicy Bypass -File tools\set_source_path.ps1
```

It points the model at the CSV that travelled with the project - `Data\` beside
`tools\` - prints the old and new paths and the row count, and exits. Then open
the `.pbip`. Nothing else to do.

To point at a different file, a network drop for example:

```powershell
powershell -ExecutionPolicy Bypass -File tools\set_source_path.ps1 -Path D:\drops\CDP_latest.csv
```

> Run it with Desktop **closed**. An open Desktop holds its own copy of the
> model in memory and writes it back over the change when it saves.

#### Or do it inside Desktop

1. Open `CDP_Reminder_Volume_Dashboard.pbip`.
2. **Home → Transform data ▾ → Edit parameters** (the dropdown arrow under the
   Transform data button - this sets the value without opening the Power Query
   Editor).
3. Set **`p_SourceFilePath`** to the full path of the CSV on this machine. The
   copy that travelled with the project is the safe choice:
   `<wherever you put it>\CDP_Reminder_Volume_Dashboard\Data\CDP_Projects_Summary_History.csv`
4. **OK**, then **Home → Refresh**.

There is exactly one parameter in the model, so there is nothing else to hunt
for. The refresh error names the parameter and both fixes rather than printing a
bare "file not found" - the instruction is in the message itself, because Power
BI's error list shows the message and drops the detail.

### A4. Check it worked

The tiles on page 1 should read **2,016** total volume with the supplied
extract, over **162** rows. Page 3 shows every validation check at **0**.

---

## Part B - Converting to PBIX

### B1. Open and refresh first

Open the `.pbip`, complete **Part A3**, and **Refresh**. Do this *before*
saving: a PBIX stores whatever data was loaded at the moment you saved it, and
saving an unrefreshed project produces an empty PBIX.

### B2. Save as PBIX

**File → Save as** → set **Save as type** to **Power BI files (\*.pbix)** →
name it → **Save**.

That single file now contains the data model, the cached data and all three
report pages.

### B3. What the recipient needs

Power BI Desktop - and nothing else. No CSV, no preview feature, no folder
structure. They open the PBIX and every page renders against the embedded data.

They only need the CSV if they want to **refresh** it, in which case they follow
Part A3 inside the PBIX (Manage parameters works the same way there).

> **One-way door.** The PBIX is a distribution artefact, not a source. The
> generators under `tools/` write PBIP and cannot read a PBIX back, so keep the
> PBIP as the thing you edit and re-export a PBIX whenever you need to share.
> Changes made by hand inside the PBIX are lost the next time you export.

---

## Refreshing against a new extract

Same on either format, and nothing but the parameter changes:

1. **Home → Transform data ▾ → Edit parameters**
2. Point **`p_SourceFilePath`** at the new CSV
3. **OK**, then **Home → Refresh**

Clients, programs, creatives, sites, reminder stages and the calendar are all
derived from whatever the file contains. A new client appears on its own; a
`REM5` labels and sorts itself; the journey band renders however many stages
each client actually runs.

The file needs the same columns. Headers are matched case-insensitively against
a list of aliases, so `email_counts` and `Number of Email` are both accepted,
as are `client_name` / `Client_name` / `client`.

---

## Rebuilding on the other machine (optional)

Only needed if you want to change the report there. Requires Python 3.

```bash
python tools/build.py
```

This regenerates the model, the report and the documentation, and runs every
validator. It writes `p_SourceFilePath` pointing at the `Data/` copy **inside
that checkout**, so after a rebuild the parameter is already correct for that
machine and Part A3 becomes unnecessary.

The PowerShell helpers (`verify_live_model.ps1`, `export_raw_csv.ps1`,
`dump_card_values.ps1`) locate the Power BI ADOMD client by searching the usual
install locations, so they work on a default install, a D:-drive install or a
Microsoft Store install without being edited.

`set_source_path.ps1` needs none of that - it only rewrites a line in
`expressions.tmdl`, so it runs on a machine with nothing installed but
PowerShell.

---

## If something goes wrong

| Symptom | Cause | Fix |
|---|---|---|
| Desktop will not open the `.pbip` | preview feature off | Part A2 |
| "Tabular databases do not support CompatibilityLevel downgrade" | older Desktop than this project was built on | update Desktop, or use a PBIX saved from the older version |
| Refresh fails naming `p_SourceFilePath` | the path does not exist on this machine | Part A3 |
| Every table reports "This path does not exist on this machine" | the project was copied without repointing it | run `tools\set_source_path.ps1`, Part A3 |
| Report opens but every visual is blank | opened but never refreshed | **Home → Refresh** |
| PBIX opens empty for the recipient | it was saved before refreshing | redo Part B1 and B2 |
| "contains a duplicate value ... not allowed for columns on the one side of a many-to-one relationship" | the extract spells one value several ways (case, a non-breaking space, a doubled space) | already handled - the model collapses them. If you still see it, you are on a build from before this fix |
| "OLE DB or ODBC error: [DataSource.NotFound]" on every table | `p_SourceFilePath` still points at the machine the project came from | Part A3 |
| `set_source_path.ps1` says "More than one CSV in Data" | a second extract was dropped in beside the first | delete the one you do not want, or pass `-Path` |
| "Load was cancelled by an error in loading a previous table" | a cascade - one table failed and the rest stopped | fix the first real error in the list; the others usually clear with it |
| Numbers group as 6,53,297 rather than 653,297 | the viewer's Windows regional format | expected - visual number formatting follows the viewer, not the model |
