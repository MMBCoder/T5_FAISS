# Dashboard Design

## The story the report tells

Three pages, in order, each answering one question. The order is the argument:

| # | Page | Question it answers | Accent |
|---|---|---|---|
| 1 | Volume Tracking | How much are we sending, through which stages, and where does it sit? | Teal |
| 2 | Daily Operations | Show me the actual rows behind the numbers | Gold |
| 3 | Records & Quality | What are the underlying rows, and can I trust them? | Slate |

Read top to bottom, that is: **how much → show me the rows → can I trust them**.

### Why three and not nine

An earlier cut had nine pages, then five. Three of the nine - Client Analysis,
Program Analysis and Creative Analysis - were the same three visuals with one
field swapped, and two more were drill-through pages that repeated the executive
page almost exactly. That is a report which *feels* large and *reads* small: the
reader has to work out what is different about each page before they can use it.

Cutting from five to three removed a **Reminder Journey** page and a **Drivers**
page. Neither was carrying its own question. The journey page's subject - which
stage holds the volume - is already the signature band and the reminder
distribution chart on page 1, and its stage-to-stage matrix was a second telling
of the same four numbers. The drivers page ranked clients, programs and
creatives in three bar charts and a four-level matrix; that whole page is now
the **contribution panels** in the lower half of page 1 - two ranked charts
answering the same two questions in the space that used to hold four
restatements of the tiles above them.

What was genuinely lost with those pages is the creative/comm-code ranking and
the stage-to-stage movement matrix. Both are still available in the model and in
tooltips, and both can be read off the page-2 record table by filtering. If
either turns out to be a daily need it wants a visual, not a page.

## Page by page

### 1. Volume Tracking

- **Five KPI tiles** - total volume, average per active day, clients, programs,
  active reminder stages.
- **The reminder journey band** - the report's signature visual. Four stage
  slots and three connectors, all measure-driven, described below.
- **Daily volume trend** with a dynamic title naming the current client
  selection.
- **The contribution panels** - a tall ranked chart of the top clients down
  the right, with email volume by program and the reminder distribution
  beneath the trend. Described below.

There is no *latest day* tile. On a feed whose final day is routinely partial -
the supplied extract ends on a day carrying 4 emails against an average of 22 -
a tile reading `LATEST DAY 4` beside a `-92.7%` movement invites the reader to
treat an incomplete file as a collapse in volume. The trend chart one band below
shows that same day in the only context that makes it readable: next to the 90
days before it. `[Latest Day Volume]` and its day-over-day pair remain in the
model and in tooltips, where the surrounding numbers are present too.

### 2. Daily Operations

One table, the full page: every loaded record at source grain - one row per
client, group, creative, site, stage, program, date and T/C indicator - newest
first, with the row count, the Test-only volume and the raw T+C volume. No
tiles, no charts, no commentary. This is the page to come to when the question
is *show me the actual rows behind that number*.

Every column on it is a dimension column or a plain sum, which is what lets it
hold at 100k rows. The trailing-baseline and exception-status measures are
deliberately absent: evaluating a 14-day window per source row is what made an
earlier version of this table render as an empty panel at scale.

**Exporting from this page.** Power BI has no scriptable download action - a
button can navigate, bookmark, drill through or open a URL, and nothing else -
so the export is the visual's own. The table is the one visual in the report
whose header is left visible, because *Export data* lives in that header's
overflow menu, and a caption under it says so in words. The report also
declares `exportDataMode` so underlying rows are offered and not just the
summarised view; that setting had been written into the PBIR definition all
along and silently dropped on the way down to the legacy format.

The in-visual export is capped at 30,000 rows for CSV and truncates without
saying so, which at production size is worse than refusing. The caption
therefore prints the live row count beside the cap, and
`tools/export_raw_csv.ps1` runs a single DAX query against the open model and
streams every row out with no limit.

> **Measures no longer on any page.** Cutting to three pages left roughly 70 of
> the model's 194 measures unreachable from a visual: the whole anomaly set
> (trailing baseline, standard deviation, exception status and the heatmap
> ramp), the stage-to-stage movement measures and the `Top N` rankings that the
> drivers page drew, the four narrative insight sentences, and the dynamic
> titles those pages used.
>
> They are inert, not broken - documented, tested against the CSV by
> `tools/validate_data.py`, and available to any visual, tooltip or DAX query
> that wants them. They are kept rather than deleted because each one encodes a
> definition that was argued out once, and re-deriving `Volume Baseline` or
> `Stage Volume Movement` from scratch costs more than carrying them. If the
> model is ever trimmed, that list is where to start; if exception-watching
> becomes a daily need, the measures for it are already there and want a band
> on page 1.

### 3. Records & Quality

- Six KPI tiles reconciling rows and volume.
- **Nine validation check tiles**, one per rule.
- **The raw extract** - one row per client, group, creative, site, stage,
  program, date and population, with Test-only volume and the raw column sum
  side by side.

## The contribution panels

The lower half of page 1 answers the two questions a leader asks after "how
much": **which clients** send the email, and **which programs**. Both are
ranked charts with the name written on them and the email count printed on the
end of the bar.

They read without being taught. That sounds like a low bar; it took three
designs and one measurement to clear it.

### Three designs

**One - four dynamic insight sentences.** Measured, well-formed prose, one card
each. Also the least useful thing on the report: every sentence restated a KPI
tile the reader had walked past two bands earlier, and they spent the widest
strip on the page doing it.

**Two - a nested treemap plus an "80% of volume" card.** Program as the group,
client as the detail, so the outer blocks were programs and the tiles inside
them were clients; beside it, the number of clients it took to reach 80% of the
volume. Compact, both levels at once, no top-N cut - and rejected on the only
test that counts: **a senior reader who has not worked with this data could not
tell what either half was showing.**

That verdict is worth recording, because both halves failed for reasons that
generalise:

- A treemap encodes quantity as **area**, and people compare areas badly and
  inconsistently - a block twice the size does not look twice the size. It also
  requires the reader to *know* that nesting means hierarchy. Nothing on the
  visual says so.
- With a long tail, most tiles are too small to carry a label, so the majority
  of the chart is unlabelled colour: honest about the shape, useless for naming
  anyone.
- The 80% card asked for a cumulative-share idea to be held in the reader's
  head before the number meant anything, and *"clients carrying 80% of volume"*
  reads as a *kind* of client rather than as a count of them.

**Three - what is there now.** A ranked bar with a name next to it and a number
on the end of it. **Length** is the one visual encoding people judge
accurately, and the three things a reader needs - *who*, *how many emails*, and
*what am I not being shown* - are the label, the data label and the subtitle.
No legend, no colour to decode, nothing to learn first.

### The measurement that set the layout

Power BI reserves roughly **30px per category** on a horizontal bar chart, so a
ranking of five needs about 150px of plot before the title, the subtitle and
the axis are paid for.

A stress build made that concrete. The client chart was temporarily repointed
at the extract's eight `site_code` values - the only dimension in the sample
data with more than five members - and drawn in a 174px band. It rendered
**three bars and a scrollbar, under a caption that read "the 5 biggest"**. This
is the report's signature failure mode and the reason the stress build exists:
nothing errors, the caption stays confident, and two of the five members are
simply not there.

Columns fit five in that height - width is the dimension a short band has to
spare - but on a skewed selection 90px of column height flattens everything
below the leader into a 2px line. The same stress build showed it: 1,558 beside
103, 102, 97 and 96 drew one column and four hairlines.

So the client ranking was given **height** instead. It spans the trend row and
the band beneath it as a single 320px panel - about eight bars' worth of room -
and the lower half of the page became two columns rather than two rows:

| | Left column (844px) | Right column (556px) |
|---|---|---|
| top | daily volume trend, 140px | **top 5 clients**, 320px, horizontal |
| bottom | **by program**, 418px, columns | |
| | reminder distribution, 418px, columns | |

Nothing was removed to pay for it. The trend chart dropped from 210px to 140px
- 91 dates do not need more - and the reminder distribution moved from the
right of the trend to the band below it, narrower.

### What each chart says

**Programs are columns, clients are horizontal bars,** and that is not a style
choice. Client names are long: *Ashley Advantage® Credit Card* is 29
characters, and rotating it is exactly how the old drivers page became
unreadable. Program names are short codes and programs are few, so columns
divide the width and give each one 80px or more even at five.

**The value axis is off on both.** Every bar carries its own number, so an axis
would spend 25px restating them - and in these panels those 25px decide whether
a category fits or scrolls.

**Colour carries no meaning in either chart.** One flat colour each, teal for
clients and steel for programs, so the only thing the reader interprets is
length. An earlier draft coloured each client bar by that client's main
program, which did link the two - and bought a legend nobody asked for, plus
the question *why is that one gold*, in exchange for something the reader can
already get by looking left.

**The title states the cut and the subtitle states the remainder.** Both are
measures, so neither can go stale:

- all members fit → `EMAIL VOLUME BY CLIENT` / *"All 3 clients that sent email,
  biggest first."*
- more than fit → `TOP 5 CLIENTS BY EMAIL VOLUME` / *"The 5 biggest of 128
  clients. They send 68% of all email here."*

That second sentence is what replaced the 80% card, and it does the same job in
language nobody has to unpack. Note what it avoids: no "top N", no "selected
volume", no percentage without a subject. The previous wording - *"Top 5 of 128
clients - 67.9% of selected volume"* - is four pieces of shorthand in eleven
words, written for someone who already knows the report.

It is also **short on purpose**. A chart subtitle in Power BI truncates with an
ellipsis rather than wrapping, and these panels are 418px and 556px wide: a
fuller draft - *"The 5 biggest clients - together they send 68% of all the
email here. The other 123 send the rest."* - lost its last four words on
screen, which is how a caption ends up saying less than a short one.

### Five, not ten

Every other ranking in this report cuts at `[Top N]` = 10. These two cut at
`[Shortlist Size]` = 5. Five is what fits, and five is also the number a leader
asks for: the shortlist, with everything else accounted for in one sentence
rather than in five more bars.

`[Scale Notice]` - the banner beside the navigation - reads the same measure.
It used to print *rankings show top 10* while the charts underneath drew five,
which is a banner contradicting the chart it sits above.

### Proven at production shape

Layout decisions here were checked against a manufactured extract at the size
this report is actually for - **111,213 rows, 128 clients, 32 programs, 200
creatives, five stages including `day0`, and a deliberately skewed
distribution** - because none of it is visible at the supplied extract's 162
rows and 3 clients. What that run settled:

| | at 128 clients / 32 programs |
|---|---|
| bars drawn | 5 and 5, no scrollbar |
| longest client name | 38 chars, fits the label margin |
| captions | 62 chars, no ellipsis in either panel |
| slowest measure | 60 ms (the journey slots); everything else under 30 ms |
| journey band | `DAY0 → REM1 → REM2 → REM3 → REM4  (first 4 shown below)` |

It also caught the one thing no amount of reading the code would have found:
with a skewed distribution the longest bar reaches the panel edge, so Power BI
moved its data label **inside** the fill - dark ink on saturated teal, about
2.2:1, on the single number the reader most wants. The client chart now sets
`labelPosition: OutsideEnd`, which keeps every label on the paper and makes
Power BI reserve the width for it.

Both charts keep the full drill hierarchy behind them - client → program →
reminder stage on the right, program → client → stage on the left - so a reader
who wants the next level down can expand in place rather than navigate.

## The reminder journey band

Four stage slots and three connectors, and not one of them is a static shape.
Every card is bound to a measure that returns an **empty string** when it has
nothing to say, so a slot with no stage behind it disappears completely and the
connector into it disappears with it. That is what makes a one-stage journey
look deliberate rather than like a four-stage journey with three things broken.

### The slots are positional, not numbered

Slot 1 draws whichever stage comes **first in this journey**, slot 2 the second,
and so on - whatever those stages are called.

They used to be keyed to the stage number: slot 1 filtered `Reminder Order = 1`,
slot 2 filtered order 2. That works for exactly one shape of feed - one whose
`rem_flag` values start at 1 - and it fails silently for every other.

**The case that broke it.** Some programs open with a day-0 send before the
reminders start, and the feed spells it `day0`. The digit rule in `Dim_Reminder`
reads the 0 and gives it `Reminder Order` 0, which sorts it correctly ahead of
REM1. But no slot filtered on order 0, so on a `day0 → REM1 → REM2 → REM3`
journey the band drew **three** stages and an empty fourth - while the path line
directly above it read `DAY0 → REM1 → REM2 → REM3` and the tile beside it said
four stages. The first send of the journey, usually the largest, was simply not
on the band, and nothing on the page said so.

Positional slots fix that and several neighbouring cases with it: a feed that
starts at REM2, a REM5 that appears later, a journey with a gap in the middle.
None of those could be drawn before without leaving a hole where the missing
number would have been.

Verified against a manufactured extract in which one client's flags were shifted
down to `day0, REM1, REM2, REM3`:

| | slot 1 | slot 2 | slot 3 | slot 4 | total |
|---|---|---|---|---|---|
| day-0 client | DAY 0 · 96 | REMINDER 1 · 102 | REMINDER 2 · 103 | REMINDER 3 · 97 | **398 = 398** |
| ordinary client | REMINDER 1 · 20 | REMINDER 2 · 20 | REMINDER 3 · 20 | *(empty)* | 60 |
| single-stage client | REMINDER 1 · 1,558 | *(empty)* | | | 1,558 |

The slots sum to the client's email volume exactly, which is the property the
numbered form could not hold.

### Colour comes from the stage, not from the slot

`Slot n Label Colour` resolves the colour from the stage the slot is currently
showing, so **REM2 is steel in slot 2 of a REM1-REM4 journey and steel in slot 3
of a day-0 journey**. A fixed per-position colour would have recoloured every
stage the moment a day-0 send pushed them along.

Order 0 takes a neutral slate: a day-0 send is not a reminder, and the four
accents belong to the reminders. Slate also catches any flag whose number the
model could not read, so an unrecognised stage is visibly not one of the four.

> Slate as small text on the band's warm paper measures **4.49:1** - a hair
> under the 4.5:1 AA floor - so its text register is darkened to `#4E5D66`,
> exactly as clay and gold are. These four label colours are the only text in
> the report the automated contrast audit cannot see, because they resolve in
> DAX rather than in `report.json`; the check count dropped from 167 to 163 when
> they became measure-driven, and their contrast was computed by hand instead.

### A journey longer than the band

`[Journey Slot Count]` is 4. When a journey has more stages than that - a
`day0` plus four reminders, say - the path line says so in words:
`DAY0 → REM1 → REM2 → REM3 → REM4   (first 4 shown below)`. The whole journey is
still named there even when the cards below cannot all be drawn, which is the
difference between a limit and a silent truncation.

### What a day-0 flag is called

`day0` used to render as **"Reminder 0"** everywhere - slicers, charts, tables -
because the display name was always `"Reminder " & digits`. It is not a
reminder, and calling it one on every visual in the report reads as a mistake.
A flag whose text mentions a day is now labelled as a day:

| `rem_flag` | Reminder Order | Display Name | Short Name |
|---|---:|---|---|
| `day0` | 0 | Day 0 | DAY0 |
| `REM1` | 1 | Reminder 1 | REM1 |
| `REM4` | 4 | Reminder 4 | REM4 |
| `WELCOME` | 9999 | WELCOME | WELCOME |

The rule is the word "day" anywhere in the flag, case-insensitively. Everything
else with a digit stays a reminder, and a flag with no digit at all keeps its
own text and sorts last rather than silently taking slot 1.

### Tooltips break down positionally too

The stage breakdown in the trend and client tooltips reads *1st stage, 2nd
stage, 3rd stage, 4th stage* and is bound to the same slot measures. Bound to
`REM1..REM4` it could not reconcile on a day-0 journey - four lines adding up to
less than the total printed above them, with nothing to explain the gap. The
band on the page names which stage each position is.

> A card bound to a measure returning `BLANK` does not render nothing - it
> renders the literal text `(Blank)`. Every measure feeding a journey card
> therefore returns an empty string instead. This is why the journey values are
> text measures (`Slot n Journey Value`) rather than numeric ones.

The extract exercises all the shapes: Ashley Advantage runs one stage,
CITY Furniture three, BrandsMart four.

## Filters

Seven slicers on every page, all synced, so a selection survives navigation:
Client, Client Group, Program, Reminder, Creative / Comm Code, Site, T_C_IND.
Plus one **Between** date-range slicer in the header, also synced.

**The slicers narrow each other.** Choosing Program = FOC leaves only the
clients that run an FOC programme in the Client list, and so on across Client,
Client Group, Program, Reminder, Creative and Site. That needs two things, and
it was broken on both counts:

- the six slicer dimensions cross-filter in **both directions**. A star with
  single-direction relationships propagates dimension to fact and stops, so a
  program selection could never reach the client dimension. `Dim_Date` and
  `Dim_Population` stay single-direction on purpose - see the model notes.
- the slicers have to be **parseable as synced**. `syncGroup` was being written
  as a bare name where Power BI expects an object, and Desktop responded by
  dropping the slicers out of cross-filtering altogether and forgetting the
  selection on page change - the exact behaviour these notes used to claim
  worked.

A visual-level measure filter (`[Total Rows] > 0` on each slicer) was built and
tested first, and is worth recording as a dead end: it does filter per item - a
threshold of 100 rows correctly left only the one client above it - but it
never sees the other slicers' selections, so it cannot cascade.

Every slicer is multi-select with tick boxes and a **Select all** entry.
Without that a dropdown is single-select in practice: a second choice replaces
the first and there is no way back to everything short of the eraser icon.

The last slicer is labelled **T_C_IND**, after the source column it filters,
not "Population". The word was doing two jobs in this report - the Test/Control
indicator, and the record counts `[Test Population]` and `[Control Population]`
- and a filter called Population sitting next to a measure called Test
Population invites exactly the wrong reading. T_C_IND filters; Population
counts.

**T_C_IND defaults to Test**, because Test is the population that receives
email.

Everything on the page responds to all of them: KPI tiles, the journey band,
trends, rankings, matrices and detail tables all read from the same filter
context. There are no disconnected visuals.

### Selecting Control

`[Email Volume]` filters the fact to `t_c_ind = "T"`. Selecting Control in the
population slicer intersects that selection with the `T` filter, so email volume
is correctly **blank**. A banner then appears in the header strip:

> CONTROL POPULATION — NO EMAILS SENT. Email volume is blank because control
> records do not receive email.

Population counts still work under a Control selection, which is the point of
keeping Control in the model.

## Dates

`Latest Available Date` is the latest date carrying Test data **inside the
current filter context**, not the dataset maximum. Narrow the date slicer and
every latest-day figure follows.

`Previous Available Date` finds the previous date that actually holds data. The
feed has gaps - 91 distinct dates across a 142-day window - so with 10, 11 and
13 loaded, the previous day for the 13th is the 11th, not the 12th. When there
is no previous day with data in range, the movement caption reads `N/A` rather
than a misleading 0%.

`Average Daily Volume` divides by days that carry data, never by calendar days.
Missing dates are not treated as zero-volume days.

## Anomaly method

Transparent and explainable, deliberately not a model:

- **Baseline** - the mean of the **14 most recent days with data** before the
  day being evaluated. Trailing, not centred, so a day's status never changes
  when later days arrive. Blank until at least five prior days exist.
- **Spread** - the population standard deviation over the same window.
- **Status** - `High` above baseline + 2 SD, `Low` below baseline − 2 SD,
  otherwise `Normal`; `Baseline forming` while there is too little history.

The thresholds are stated on the page itself, not buried here.

## Visual identity

The report is a **light, printed editorial page**, deliberately not a dark
instrument panel. That choice is the point: the IDR monitoring report is a dark
navy console, and two reports that share a generator should not also share a
face. Someone glancing at a screen from across a room should know which of the
two they are looking at before they can read a number.

| | This report | The IDR console |
|---|---|---|
| Canvas | warm paper `#F3F0E9` | dark navy `#0A0E17` |
| Cards | white, square, hairline rule | dark, rounded, floating |
| Header | one inverted deep-pine masthead | dark band on a dark page |
| Identity mark | accent spine, chapter badge, lit nav pill | full-bleed accent rule |
| Accents | teal, steel, clay, gold | electric blue, cyan, purple, amber |

### The masthead

One deep-pine band across the top holds the chapter mark, the title, the volume
rule, the three navigation pills and all eight filters.

The strapline under the title is not a description of the page - it is the rule
that governs every number in the report: *Email Volume = Test (T) records only.
Control (C) is population, never a send.* It used to be a banner in a strip of
its own, and the per-page strapline that sat here was decorative prose
repeating the chapter caption. A reader who misses the volume rule misreads
every figure on the page, so it takes the permanent position.

The chapter caption and the title share a single container. Two textboxes each
pay the renderer's own 16px of vertical padding, and that difference alone was
enough to push both into scrollbars and cut them in half. Separating the controls from the paper
this sharply means the body of every page is nothing but data - no chrome
competes with it - and it is the silhouette that distinguishes the report
before any colour is read.

The page's identity is carried by three marks, never by a full-bleed rule:

- the **accent spine** down the left edge of the whole page, running through
  both the masthead and the paper;
- the **chapter badge**, a solid accent square holding the page number - the
  report's only decorative geometry, and the thing the eye lands on first;
- the one **lit navigation pill**.

Filters are wells cut into the pine rather than light tiles laid on it. Seven
white boxes across a dark band read as seven buttons, and the masthead stops
being a header and starts competing with the page.

### The body

Everything below the masthead is white or nothing. Cards are square with a
`#DBD4C4` hairline; bands are opened by a tracked accent label alone, not by
boxing each panel.

There is deliberately no hairline rule under those labels. Power BI enforces a
minimum rendered height on a visual container, so a 1px "rule" came out as an
11px grey slab lying across the heading - which is what made the section
headings look like they were overlapping something. Exactly one surface in the
body of the report is tinted: the reminder journey band, because it is the
report's signature visual. The other tinted strip was the narrative pull-quote
at the foot of page 1, and it went with the sentences it held.

Each KPI tile carries a 4px accent bar down its left edge. The bar is a
separate visual rather than a tint on the tile, so the number still sits on
plain white - eight tinted tiles in a row is a mood, not a reading.

## Colour

Every accent exists in **two registers**. The saturated one is used as a pure
mark, where nothing sits on top of it: the spine, the KPI ticks, a chart
series. The deep one is used wherever the accent has to carry text - as small
text itself on paper, and as the fill beneath the white label of the badge and
the active navigation pill.

| Element | Mark | As text / under white text |
|---|---|---|
| Reminder 1, page 1 | `#0E7A6A` teal | `#0E7A6A` |
| Reminder 2 | `#2B6C97` steel | `#2B6C97` |
| Reminder 3 | `#C05A38` clay | `#B45434` |
| Reminder 4, page 2 | `#C79020` gold | `#916917` |
| Page 3 | `#5A6B76` slate | `#5A6B76` |

Four stage accents, three pages: the stage identities are fixed by
`Reminder Order` and do not follow the page count. Pages take the first, the
fourth and slate.

Clay and gold fail WCAG AA in both text roles at full saturation. Dulling the
fills to fix that would have cost the palette its warmth, so each keeps a
darkened twin instead: a bar and the label describing it stay recognisably the
same colour, and both are legible.

| Element | Colour | Rule |
|---|---|---|
| Volume rise | `#2E7D52` green | |
| Volume fall | `#916917` gold | gold, not red - a smaller later stage is the normal shape of a reminder sequence, not a failure |
| Exception / attention | `#916917` gold | |
| Exception, severe | `#AE3B2B` | used only where a rule was actually broken |

Stage colour comes from a measure keyed on `Reminder Order`, so a stage keeps
its identity even when a journey contains only some of the stages. The theme's
series palette is in the same order, so a multi-series chart by reminder picks
up the same identities.

The heatmap ramp runs **light to dark** on paper - the reverse of a dark-canvas
report - so the value printed in each cell inverts with it: ink on the two pale
steps, paper on the two saturated ones. Without that the busiest cells, the
ones actually worth reading, become the unreadable ones.

## Designing for 100+ clients and 100k+ rows

The supplied extract has three clients and 162 rows. The report is built for a
feed of 100+ clients and 100k+ rows, and a layout that reads well at three
clients can be unusable at a hundred. So rather than assert that it scales, the
model was pointed at a synthetic extract with the shape the real feed will have
- 128 clients, ~99k rows, 18 months, journeys of one to four stages, and
control rows - and every page was looked at at that size.

That test found every item below, and **none of them were visible at 162 rows**.
Ranking charts drew three of ten bars and hid the rest behind a scrollbar; the
daily operations table rendered as an empty panel with no error; the Top-N cut
silently re-ranked itself for every cell.

> The fixture and its generator have since been deleted so the project has
> **exactly one input CSV**, and `tools/validate_project.py` now fails the build
> if a second one appears in `Data/` or if the model grows a second parameter.
> Two files in an input folder is an invitation to refresh the wrong one - which
> happened once during that very test, and a whole round of screenshots was
> taken against the fixture by mistake.

### Rankings are cut to a top N, and say so

Every per-client, per-program and per-creative visual is drawn through a
`Top N ... Volume` measure that returns BLANK outside the cut, so the chart
drops those members. `[Top N]` is a measure, so one edit changes every ranking
chart and every caption with it.

The cut is stated, never implied: each chart's subtitle is a coverage caption
reading *Top 10 of 128 clients - 67.9% of selected volume*, or simply
*3 clients in selection* when everything fits. A ranking that silently shows
ten of a hundred and twenty-eight is a lie by omission.

**The ranked set is computed once per visual, not once per cell.** This is the
subtle part. Ranking inside the cell context re-chooses the top ten for every
reminder stage and every week, so a stacked chart drew twenty-two clients
instead of ten and a ten-series weekly line chart never returned at all.
Wrapping the ranking table in `CALCULATETABLE ( ..., ALLSELECTED () )` strips
the visual's own groupings while keeping the slicers: one set, cached, stable
across every cell.

### Grain follows the question, not the source

The daily operations table used to be one row per source row, carrying each
day's baseline and status beside it. At 99k rows it rendered nothing at all -
no error, an empty panel - because a trailing 14-day baseline was being
evaluated for every row.

It is now one row per day. That is also the honest grain: the baseline, the
standard deviation and the exception flag are properties of a *day*, and
printing a day's status beside a single client-creative-stage row implied the
row was the thing being judged. Row-level records live on page 3, which is the
page for them.

### Time axes are scalar, and weekly charts key off a real date

`Dim_Date[Week Start]` holds the Monday of each week so weekly charts sit on a
scalar axis, spaced by time, thinning their own labels. The earlier version put
the text `Year-Week` on a categorical axis: at 91 days that was tight, and at
78 weeks it printed 78 labels, truncated every one to `20...`, and grew a
scrollbar.

### Everything else that scale changed

- Slicers carry a search box. A dropdown of 128 clients without one is not a
  filter.
- The category gutter on ranking charts is widened to 45% of the plot, or long
  names arrive as *Ashley Advantag...*.
- Ranking charts are tall enough for ten bars. At the original height they drew
  three and hid the rest behind a scrollbar.
- A banner appears in the masthead when the selection is large enough that the
  page is showing a window rather than the whole: *128 clients - rankings show
  top 10*.
- The weekly-volume-by-client chart was removed. Ten overlapping weekly lines
  over seventy-eight weeks was never readable, and the space it freed is what
  lets the three rankings show ten bars each.

### What does not scale away

The matrices and the raw extract table stay at full grain and scroll. That is
the right behaviour for them - they exist to be searched and drilled, not
summarised - and Power BI virtualises their rows.

**Numbers in charts and tables follow the viewer's Windows regional format.**
On a machine set to an Indian locale, 653,297 renders as 6,53,297. That is
Power BI working as designed, not a report setting: the model's culture is
`en-US` and DAX-formatted text obeys it, but visual-level number formatting is
the viewer's. Data labels are left at full precision rather than Auto display
units, because Auto renders 122, 123 and 97 all as `0.1K`.

## Accessibility

- Colour is never the only signal: the heatmap prints its values, status columns
  print their words, and movement carries a sign as well as a colour.
- Body text is 8.5pt and above; KPI values are 26pt.
- Every visual has a title, and most carry a subtitle stating what the numbers
  mean.
- Text containers are sized to their line boxes - Power BI clips a run whose
  container is tight rather than reflowing it.
- **Contrast is measured, not asserted.** `tools/check_contrast.py` runs as a
  build stage: it walks every text element in the emitted `report.json`, works
  out which surface it actually sits on by geometry and z-order, and fails the
  build if any falls below WCAG 2.1 AA - 4.5:1 for body text, 3.0:1 for large.
  167 text elements are checked and all pass. This is the check that caught the
  colours the inversion from a dark canvas left behind.

## Navigation

Numbered buttons across every page header, with the current page highlighted in
its accent colour.

There is **no drill-through target any more**. Drill-through needs a page to
land on, and the page it landed on was Drivers. With three pages and every
slicer synced across all of them, the equivalent move is to select the client in
the slicer: every page follows it, which is what drill-through was approximating.
`tools/validate_project.py` reports `drill-through pages: none`, and that is the
intended state rather than a regression.

## Tooltips

Measure-driven tooltips are attached to the visuals where they add something:

| Hovering | Shows |
|---|---|
| a date | volume, REM1-REM4, previous available day, day-over-day % |
| a client | volume, programs, stages, REM1-REM4 |
| a program | volume, clients, stages, creatives |
| a reminder stage | volume, share, latest day, day-over-day %, creatives |
| a creative | volume, clients, programs, reminders |

## Dynamic titles

Titles are measures, never fixed strings:

- `Daily Email Volume — All Clients`
- `Daily Email Volume — Ashley Advantage® Credit Card`
- `Client → Program → Reminder → Creative — All Clients`

`All` appears when nothing is selected, the value when one thing is, and a count
when several are.

## Empty states

| Situation | Behaviour |
|---|---|
| No filters | everything shown |
| No data after filtering | *No data available for the selected filters.* |
| Control-only selection | the Control banner, not the no-data message |
| A stage missing from the journey | slot and connector collapse |
| A stage with no volume in period | `0`, captioned as such |
| A date with no send | no row - it never reaches a table |

## Business definitions

| Term | Definition |
|---|---|
| Email Volume | Sum of the volume column over **Test (`T`) records only** |
| Test | `t_c_ind = "T"` - receives the reminder email |
| Control | `t_c_ind = "C"` - eligible population, deliberately not mailed |
| Population | A **record** count. The extract carries no headcount column, so this counts source rows, not people |
| Volume Movement | Difference against the previous stage **that exists in that journey**. Deliberately not called conversion: the source defines none |
| Active Day | A date that carries Test data |
| Journey | The set of reminder stages present for the current selection, ignoring the date filter |
