# Points the model at the CSV on THIS machine, in one step.
#
#   powershell -ExecutionPolicy Bypass -File tools\set_source_path.ps1
#   powershell -ExecutionPolicy Bypass -File tools\set_source_path.ps1 -Path D:\drops\CDP_latest.csv
#
# Why this exists
# ---------------
# Power Query stores an ABSOLUTE path and has no way to resolve one relative to
# the report file - there is no "current project folder" function in M. So a
# PBIP copied to another machine still points at the path it was built on, and
# every table fails the same way:
#
#     Could not read: C:\Users\<someone-else>\...\CDP_Projects_Summary_History.csv
#
# That is the model's own error, not a corruption: the file simply is not there.
# The fix has always been to edit the p_SourceFilePath parameter inside Power BI
# Desktop, which is four clicks and easy to get wrong. This does it from the
# file system instead, before Desktop is even opened.
#
# With no arguments it points the model at the CSV that travelled with the
# project - Data\ beside this tools\ folder - which is the right answer when the
# whole folder has been copied. Pass -Path to point somewhere else, such as a
# network drop.
#
# Run this BEFORE opening the .pbip. If Desktop is already open on the project,
# close it first - it holds its own copy of the model in memory and will write
# it back over this change on save.
param(
    [string]$Path = "",
    [switch]$Quiet
)
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$tmdl = Join-Path $root 'CDP_Reminder_Volume_Dashboard.SemanticModel\definition\expressions.tmdl'

if (-not (Test-Path $tmdl)) {
    Write-Host "Not a CDP dashboard project: expressions.tmdl not found under" -ForegroundColor Red
    Write-Host "  $tmdl"
    Write-Host "Run this script from the tools folder inside the project."
    exit 1
}

# ---- work out which CSV to point at ---------------------------------------
if ($Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        Write-Host "No file at that path:" -ForegroundColor Red
        Write-Host "  $Path"
        exit 1
    }
    $target = (Resolve-Path -LiteralPath $Path).Path
} else {
    $dataDir = Join-Path $root 'Data'
    $csvs = @(Get-ChildItem -LiteralPath $dataDir -Filter *.csv -File -EA SilentlyContinue)
    if ($csvs.Count -eq 0) {
        Write-Host "No CSV found in $dataDir" -ForegroundColor Red
        Write-Host "Either put the extract there, or pass -Path <full path to the CSV>."
        exit 1
    }
    if ($csvs.Count -gt 1) {
        # The project is built around exactly one input file; two is an
        # invitation to refresh the wrong one.
        Write-Host "More than one CSV in $dataDir - refusing to guess:" -ForegroundColor Red
        $csvs | ForEach-Object { Write-Host ("  " + $_.Name) }
        Write-Host "Pass -Path <full path to the CSV> to choose."
        exit 1
    }
    $target = $csvs[0].FullName
}

# ---- rewrite the one line that carries the path ---------------------------
$text = [System.IO.File]::ReadAllText($tmdl)
$m = [regex]::Match($text, '(?m)^expression\s+p_SourceFilePath\s*=\s*"([^"]*)"')
if (-not $m.Success) {
    Write-Host "Could not find the p_SourceFilePath expression in expressions.tmdl" -ForegroundColor Red
    exit 1
}
$old = $m.Groups[1].Value

if ($old -eq $target) {
    if (-not $Quiet) {
        Write-Host "Already pointed at this machine's copy - nothing to change." -ForegroundColor Green
        Write-Host "  $target"
    }
    exit 0
}

# Replace only the quoted path inside that one expression line.
$escaped = $target -replace '\\', '\\'    # TMDL keeps the path verbatim; only " would need care
$updated = $text.Remove($m.Groups[1].Index, $m.Groups[1].Length).Insert($m.Groups[1].Index, $target)
[System.IO.File]::WriteAllText($tmdl, $updated, (New-Object System.Text.UTF8Encoding($false)))

if (-not $Quiet) {
    Write-Host "Source path updated." -ForegroundColor Green
    Write-Host "  was: $old"
    Write-Host "  now: $target"
    Write-Host ""
    $rows = (Get-Content -LiteralPath $target -ReadCount 0).Count - 1
    Write-Host ("  the file has {0:N0} data rows" -f $rows)
    Write-Host ""
    Write-Host "Next: open CDP_Reminder_Volume_Dashboard.pbip and press Home > Refresh."
}
