# -*- coding: utf-8 -*-
"""Regenerates the whole PBIP project and validates it.

Run:  python tools/build.py
Exit code 0 when every stage passes.

The live-engine check is deliberately not part of this: it needs Power BI
Desktop open on the project, so it stays a separate, explicit step.
"""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOLS = os.path.join(ROOT, "tools")

STAGES = [
    ("generate semantic model", "gen_semantic_model.py"),
    ("generate report", "gen_report.py"),
    ("generate documentation", "gen_docs.py"),
    ("recompute expected values from the CSV", "validate_data.py"),
    ("validate project structure", "validate_project.py"),
    ("audit text contrast", "check_contrast.py"),
    ("audit text fit", "check_text_fit.py"),
]


def main():
    failures = []
    for label, script in STAGES:
        print("=" * 72)
        print("  %s  (%s)" % (label, script))
        print("=" * 72)
        r = subprocess.run([sys.executable, os.path.join(TOOLS, script)],
                           cwd=ROOT)
        if r.returncode != 0:
            failures.append(label)
        print()

    print("=" * 72)
    if failures:
        print("BUILD FAILED: %s" % ", ".join(failures))
        return 1
    print("BUILD OK - project regenerated and validated")
    print()
    print("Next:")
    print("  1. Open CDP_Reminder_Volume_Dashboard.pbip in Power BI Desktop")
    print("  2. Home > Refresh  (a PBIP carries no cached data)")
    print("  3. powershell -ExecutionPolicy Bypass -File tools\\verify_live_model.ps1")
    return 0


if __name__ == "__main__":
    sys.exit(main())
