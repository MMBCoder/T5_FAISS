"""Minimal TMDL emitter.

TMDL is tab-indented and whitespace-significant, and multi-line expressions are
fenced with triple backticks whose body is indented one level deeper than the
``source =`` / ``measure X =`` line that opens them. Getting either wrong makes
Power BI Desktop reject the model with a parse error that names no line, so all
of that formatting is centralised here rather than repeated per table.
"""
import uuid

# Deterministic lineage tags: regenerating the model must not churn the diff,
# and Desktop treats a changed lineageTag as a different column.
NS = uuid.UUID("3f7a1c05-8d2e-5a41-9b63-7c04e1a9d820")


def tag(*parts):
    return str(uuid.uuid5(NS, "|".join(parts)))


def q(name):
    """Quote an identifier only when TMDL needs it."""
    if name and all(c.isalnum() or c == "_" for c in name):
        return name
    return "'%s'" % name.replace("'", "''")


def block(expr, depth):
    """Render a DAX/M expression as a TMDL value at the given indent depth.

    Single-line expressions stay inline - that is what Desktop writes and it
    keeps the file readable. Anything multi-line gets a fenced block whose body
    is indented one level past the fence.
    """
    expr = expr.strip("\n")
    if "\n" not in expr and len(expr) < 110 and "```" not in expr:
        return " " + expr.strip()
    pad = "\t" * (depth + 1)
    body = "\n".join(pad + ln if ln.strip() else "" for ln in expr.split("\n"))
    return " ```\n%s\n%s```" % (body, pad)


def comment(text, depth):
    """TMDL description lines - one `///` per line, above the object."""
    if not text:
        return []
    pad = "\t" * depth
    return ["%s/// %s" % (pad, ln) for ln in text.strip().split("\n")]


class Column(object):
    def __init__(self, name, dtype, source=None, fmt=None, desc=None,
                 hidden=False, key=False, sort_by=None, summarize="none",
                 inferred=False, category=None):
        self.name = name
        self.dtype = dtype
        self.source = source if source is not None else name
        self.fmt = fmt
        self.desc = desc
        self.hidden = hidden
        self.key = key
        self.sort_by = sort_by
        self.summarize = summarize
        # Calculated-table columns are "inferred" from the DAX expression and
        # carry a bracketed sourceColumn; imported ones name the query column.
        self.inferred = inferred
        self.category = category

    def render(self, depth=1):
        pad = "\t" * depth
        out = comment(self.desc, depth)
        out.append("%scolumn %s" % (pad, q(self.name)))
        out.append("%s\tdataType: %s" % (pad, self.dtype))
        if self.key:
            out.append("%s\tisKey" % pad)
        if self.hidden:
            out.append("%s\tisHidden" % pad)
        if self.fmt:
            out.append("%s\tformatString: %s" % (pad, self.fmt))
        out.append("%s\tlineageTag: %s" % (pad, tag("col", self.name, self.source)))
        out.append("%s\tsummarizeBy: %s" % (pad, self.summarize))
        if self.category:
            out.append("%s\tdataCategory: %s" % (pad, self.category))
        if self.inferred:
            out.append("%s\tisNameInferred" % pad)
            out.append("%s\tsourceColumn: [%s]" % (pad, self.source))
        else:
            out.append("%s\tsourceColumn: %s" % (pad, self.source))
        if self.sort_by:
            out.append("%s\tsortByColumn: %s" % (pad, q(self.sort_by)))
        out.append("")
        out.append("%s\tannotation SummarizationSetBy = Automatic" % pad)
        out.append("")
        return out


class Measure(object):
    def __init__(self, name, dax, fmt=None, desc=None, folder=None,
                 hidden=False):
        self.name = name
        self.dax = dax
        self.fmt = fmt
        self.desc = desc
        self.folder = folder
        self.hidden = hidden

    def render(self, depth=1):
        pad = "\t" * depth
        out = comment(self.desc, depth)
        out.append("%smeasure %s =%s" % (pad, q(self.name),
                                         block(self.dax, depth)))
        if self.fmt:
            out.append("%s\tformatString: %s" % (pad, self.fmt))
        out.append("%s\tlineageTag: %s" % (pad, tag("measure", self.name)))
        if self.hidden:
            out.append("%s\tisHidden" % pad)
        if self.folder:
            out.append("%s\tdisplayFolder: %s" % (pad, self.folder))
        out.append("")
        return out


class Table(object):
    def __init__(self, name, desc=None, columns=None, measures=None,
                 partition=None, kind="m", date_table=False, hidden=False):
        self.name = name
        self.desc = desc
        self.columns = columns or []
        self.measures = measures or []
        self.partition = partition
        self.kind = kind            # "m" or "calculated"
        self.date_table = date_table
        self.hidden = hidden

    def render(self):
        out = comment(self.desc, 0)
        out.append("table %s" % q(self.name))
        out.append("\tlineageTag: %s" % tag("table", self.name))
        if self.hidden:
            out.append("\tisHidden")
        if self.date_table:
            out.append("\tdataCategory: Time")
        out.append("")
        for m in self.measures:
            out.extend(m.render(1))
        for c in self.columns:
            out.extend(c.render(1))
        out.append("\tpartition %s = %s" % (q(self.name), self.kind))
        out.append("\t\tmode: import")
        out.append("\t\tsource =%s" % block(self.partition, 2))
        out.append("")
        out.append("\tannotation PBI_Id = %s" % tag("pbiid", self.name))
        out.append("")
        return "\n".join(out)


def relationship(name, from_table, from_col, to_table, to_col,
                 cross_filter=None):
    out = ["relationship %s" % q(name),
           "\tfromColumn: %s.%s" % (q(from_table), q(from_col)),
           "\ttoColumn: %s.%s" % (q(to_table), q(to_col))]
    if cross_filter:
        out.append("\tcrossFilteringBehavior: %s" % cross_filter)
    out.append("")
    return "\n".join(out)


def expression(name, value, desc=None, result_type="Text"):
    """A Power Query parameter exposed at model level."""
    out = comment(desc, 0)
    out.append('expression %s = %s meta [IsParameterQuery=true, Type="%s", '
               'IsParameterQueryRequired=true]' % (q(name), value, result_type))
    out.append("\tlineageTag: %s" % tag("expr", name))
    out.append("")
    out.append("\tannotation PBI_ResultType = %s" % result_type)
    out.append("")
    return "\n".join(out)


def shared_expression(name, m_code, desc=None):
    """A non-parameter shared query - the cleaned source every table builds on."""
    out = comment(desc, 0)
    out.append("expression %s =%s" % (q(name), block(m_code, 0)))
    out.append("\tlineageTag: %s" % tag("expr", name))
    out.append("")
    out.append("\tannotation PBI_ResultType = Table")
    out.append("")
    return "\n".join(out)
