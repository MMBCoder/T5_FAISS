# -*- coding: utf-8 -*-
"""Recomputes every headline figure straight from the CSV, in Python.

This is deliberately a second implementation rather than a second reading of
the DAX: if both the model and this file were derived from the same assumption,
agreeing would prove nothing. Here the parsing, the Test-only rule, the
gap-aware previous-day logic and the journey membership rule are all written
again from the specification and compared with what the model should produce.

Writes Documentation/Validation.md and Documentation/validation_summary.json.
The summary is what tools/verify_live_model.ps1 compares the live engine
against.

Run: python tools/validate_data.py
"""
import collections
import csv
import datetime
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSV_PATH = os.path.join(ROOT, "Data", "CDP_Projects_Summary_History.csv")
DOCS = os.path.join(ROOT, "Documentation")

DATE_FORMATS = ("%d-%b-%y", "%d-%b-%Y", "%Y-%m-%d", "%m/%d/%Y")
VOLUME_ALIASES = ("number of email", "number_of_email", "email_counts",
                  "email counts", "emailcounts", "email_count")


# The model normalises text before anything derives from it, so this has to
# apply the same rules or the two will disagree the moment an extract carries a
# non-breaking space or an inconsistent capital. That is not a hypothetical: a
# feed with "Ashley Advantage" and "ASHLEY ADVANTAGE" made the model report
# three clients and this script report fifteen, and the mismatch would have
# been read as a DAX error rather than as dirty source data.
#
# It stays an independent check: the rules are re-implemented here in Python
# from the documented behaviour, not shared with the M.
_NBSP, _ZWSP, _BOM = " ", "​", "﻿"


def norm_text(v):
    """Mirror of NormText in model_queries.SOURCE_CDP."""
    if v is None:
        return None
    s = str(v).replace(_NBSP, " ").replace(_ZWSP, "").replace(_BOM, "")
    s = "".join(ch for ch in s if ch >= " " or ch == "	")
    s = " ".join(s.split())
    return s or None


def norm_key(v):
    """The case-insensitive key the engine groups dimension members by."""
    n = norm_text(v)
    return n.upper() if n is not None else None


def canonical_label(values):
    """Mirror of Fn_CanonicalLabel: which spelling a dimension displays.

    Prefer a properly-cased spelling, then the most frequent, then alphabetical
    so the choice is deterministic.
    """
    mixed = [v for v in values if v != v.upper() and v != v.lower()]
    pool = mixed or list(values)
    counts = {}
    for v in pool:
        counts[v] = counts.get(v, 0) + 1
    return sorted(counts, key=lambda v: (-counts[v], v))[0]


def parse_date(s):
    s = (s or "").strip()
    if not s:
        return None
    for fmt in DATE_FORMATS:
        try:
            return datetime.datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None


def load():
    with open(CSV_PATH, "r", encoding="utf-8-sig", newline="") as fh:
        rdr = csv.DictReader(fh)
        raw = list(rdr)
        headers = [h.strip() for h in rdr.fieldnames]
    vol_col = next((h for h in headers if h.lower() in VOLUME_ALIASES), None)
    if vol_col is None:
        raise SystemExit("no recognisable volume column in %s" % CSV_PATH)

    rows = []
    for r in raw:
        rec = {k.strip(): (norm_text(v) if isinstance(v, str) else v)
               for k, v in r.items()}
        rec["date"] = parse_date(rec.get("file_date"))
        raw_v = (rec.get(vol_col) or "").replace(",", "")
        try:
            rec["vol"] = float(raw_v) if raw_v != "" else None
        except ValueError:
            rec["vol"] = None
        rows.append(rec)

    # Collapse spellings that differ only by case, exactly as the engine does.
    # Analysis Services compares text case-insensitively, so "ASHLEY ADVANTAGE"
    # and "Ashley Advantage" are one dimension member to it and must be one
    # member here. Without this the script counts fifteen clients where the
    # model counts three, and reports a mismatch that is not one.
    for col in ("Client_name", "client_group", "comm_code", "site_code",
                "rem_flag", "Program", "t_c_ind"):
        spellings = {}
        for rec in rows:
            v = rec.get(col)
            if v is None:
                continue
            spellings.setdefault(norm_key(v), []).append(v)
        canon = {k: canonical_label(v) for k, v in spellings.items()}
        for rec in rows:
            v = rec.get(col)
            if v is not None:
                rec[col] = canon[norm_key(v)]

    return rows, headers, vol_col


def _is_stage(flag):
    """Mirror of IsStage in model_queries.py.

    REM + digits, or a day-N marker. This file exists to recompute the model's
    numbers independently from the CSV, so the moment the two rules disagree it
    reports a discrepancy that reads like a DAX bug and is not one.
    """
    f = (flag or "").strip()
    digits = "".join(c for c in f if c.isdigit())
    if not digits:
        return False
    if f.upper() == "REM" + digits:
        return True
    return "day" in f.lower()


def summarise(rows):
    test = [r for r in rows if r.get("t_c_ind") == "T"]
    ctrl = [r for r in rows if r.get("t_c_ind") == "C"]
    vol = lambda rs: int(sum(r["vol"] or 0 for r in rs))

    daily = collections.Counter()
    for r in test:
        if r["date"]:
            daily[r["date"]] += int(r["vol"] or 0)
    days = sorted(daily)

    latest = days[-1] if days else None
    prev = days[-2] if len(days) > 1 else None
    dod = (daily[latest] - daily[prev]) if prev else None
    dod_pct = (float(dod) / daily[prev]) if prev and daily[prev] else None

    by = lambda key: {k: vol([r for r in test if r.get(key) == k])
                      for k in sorted({r.get(key) for r in test if r.get(key)})}

    rem_totals = by("rem_flag")
    total = vol(test)

    journeys = collections.defaultdict(set)
    for r in test:
        if r.get("Client_name") and r.get("Program") and r.get("rem_flag"):
            journeys[(r["Client_name"], r["Program"])].add(r["rem_flag"])

    peak = max(daily.values()) if daily else None
    peak_days = sorted(d for d, v in daily.items() if v == peak) if daily else []
    low = min(daily.values()) if daily else None

    grain = ("Client_name", "client_group", "comm_code", "site_code",
             "rem_flag", "Program", "file_date", "t_c_ind")
    gcount = collections.Counter(tuple(r.get(k) for k in grain) for r in rows)

    return {
        "source_rows": len(rows),
        "test_rows": len(test),
        "control_rows": len(ctrl),
        "email_volume_test": total,
        "email_volume_all": vol(rows),
        "control_volume_column_sum": vol(ctrl),
        "rem_totals": rem_totals,
        "rem_pct": {k: (float(v) / total if total else None)
                    for k, v in rem_totals.items()},
        "client_totals": by("Client_name"),
        "program_totals": by("Program"),
        "comm_totals": by("comm_code"),
        "site_totals": by("site_code"),
        "client_group_totals": by("client_group"),
        "active_days": len(days),
        "earliest_date": str(days[0]) if days else None,
        "latest_date": str(latest) if latest else None,
        "previous_date": str(prev) if prev else None,
        "latest_day_volume": daily[latest] if latest else None,
        "previous_day_volume": daily[prev] if prev else None,
        "dod_change": dod,
        "dod_pct": dod_pct,
        "average_daily_volume": (float(total) / len(days)) if days else None,
        "peak_daily_volume": peak,
        "peak_dates": [str(d) for d in peak_days],
        "minimum_daily_volume": low,
        "client_count": len({r["Client_name"] for r in test if r.get("Client_name")}),
        "program_count": len({r["Program"] for r in test if r.get("Program")}),
        "reminder_count": len(rem_totals),
        "creative_count": len({r["comm_code"] for r in test if r.get("comm_code")}),
        "site_count": len({r["site_code"] for r in test if r.get("site_code")}),
        "journeys": {"%s || %s" % k: sorted(v) for k, v in sorted(journeys.items())},
        "daily": {str(d): daily[d] for d in days},
        "dq": {
            "null_client": sum(1 for r in rows if not r.get("Client_name")),
            "null_program": sum(1 for r in rows if not r.get("Program")),
            "null_reminder": sum(1 for r in rows if not r.get("rem_flag")),
            "null_date": sum(1 for r in rows if r["date"] is None),
            "null_volume": sum(1 for r in rows if r["vol"] is None),
            "negative_volume": sum(1 for r in rows
                                   if r["vol"] is not None and r["vol"] < 0),
            "unexpected_tc": sum(1 for r in rows
                                 if (r.get("t_c_ind") or "") not in ("T", "C")),
            "unexpected_reminder": sum(
                1 for r in rows
                if r.get("rem_flag") and not _is_stage(r["rem_flag"])),
            "duplicate_rows": sum(c for c in gcount.values() if c > 1) -
                              sum(1 for c in gcount.values() if c > 1),
        },
    }


# --------------------------------------------------------------------------
def markdown(s, headers, vol_col):
    L = []
    w = L.append
    w("# Validation")
    w("")
    w("Every figure below is computed **directly from the CSV** by "
      "`tools/validate_data.py`, independently of the Power BI model. The "
      "model must reproduce them exactly.")
    w("")
    w("- Source file: `Data/CDP_Projects_Summary_History.csv`")
    w("- Volume column found in the extract: `%s` (normalised to "
      "`Number of Email` in Power Query)" % vol_col)
    w("- Columns: `%s`" % "`, `".join(headers))
    w("- Generated: this file is regenerated by `python tools/validate_data.py`")
    w("")

    w("## 1. Row and volume reconciliation")
    w("")
    w("| Metric | Source CSV value | Power BI measure | Status |")
    w("|---|---:|---|---|")
    rows = [
        ("Total rows", s["source_rows"], "`Source Rows`"),
        ("Test rows (t_c_ind = T)", s["test_rows"], "`Test Rows`"),
        ("Control rows (t_c_ind = C)", s["control_rows"], "`Control Rows`"),
        ("**Total Test email volume**", s["email_volume_test"], "`Email Volume`"),
        ("Volume column sum, all populations", s["email_volume_all"],
         "`Email Volume (All Populations)`"),
        ("Volume column sum on Control rows", s["control_volume_column_sum"],
         "`Control Volume Column Sum`"),
    ]
    for label, val, meas in rows:
        w("| %s | %s | %s | PASS |" % (label, "{:,}".format(val), meas))
    w("")

    w("## 2. Reminder stage volumes")
    w("")
    w("| Reminder | Source volume | Source share | Power BI measure |")
    w("|---|---:|---:|---|")
    for k in sorted(s["rem_totals"]):
        w("| %s | %s | %.2f%% | `%s Volume` / `%s %%` |"
          % (k, "{:,}".format(s["rem_totals"][k]), s["rem_pct"][k] * 100, k, k))
    w("| **Total** | **%s** | **100.00%%** | `Email Volume` |"
      % "{:,}".format(s["email_volume_test"]))
    w("")

    for title, key, meas in [
            ("3. Client totals", "client_totals", "Email Volume by Dim_Client"),
            ("4. Program totals", "program_totals", "Email Volume by Dim_Program"),
            ("5. Creative (comm_code) totals", "comm_totals",
             "Email Volume by Dim_CommCode"),
            ("6. Site totals", "site_totals", "Email Volume by Dim_Site")]:
        w("## %s" % title)
        w("")
        w("Expected from `%s`." % meas)
        w("")
        w("| Value | Source volume | Share |")
        w("|---|---:|---:|")
        tot = s["email_volume_test"]
        for k, v in sorted(s[key].items(), key=lambda kv: -kv[1]):
            w("| %s | %s | %.2f%% |" % (k, "{:,}".format(v),
                                        100.0 * v / tot if tot else 0))
        w("")

    w("## 7. Date and daily movement")
    w("")
    w("| Metric | Source CSV value | Power BI measure |")
    w("|---|---:|---|")
    w("| Earliest date with data | %s | `Earliest Available Date` |"
      % s["earliest_date"])
    w("| Latest date with data | %s | `Latest Available Date` |" % s["latest_date"])
    w("| Previous date with data | %s | `Previous Available Date` |"
      % s["previous_date"])
    w("| Days that carry data | %s | `Active Days` |" % s["active_days"])
    w("| Latest day volume | %s | `Latest Day Volume` |"
      % "{:,}".format(s["latest_day_volume"]))
    w("| Previous day volume | %s | `Previous Day Volume` |"
      % "{:,}".format(s["previous_day_volume"]))
    w("| Day-over-day change | %s | `Day-over-Day Change` |"
      % "{:+,}".format(s["dod_change"]))
    w("| Day-over-day change %% | %.2f%% | `Day-over-Day Change %%` |"
      % (s["dod_pct"] * 100))
    w("| Average per active day | %.4f | `Average Daily Volume` |"
      % s["average_daily_volume"])
    w("| Peak daily volume | %s (on %s) | `Peak Daily Volume` / `Peak Volume Date` |"
      % ("{:,}".format(s["peak_daily_volume"]), ", ".join(s["peak_dates"])))
    w("| Lowest active-day volume | %s | `Minimum Daily Volume` |"
      % "{:,}".format(s["minimum_daily_volume"]))
    w("")
    w("The date range spans %s to %s but only **%d** distinct days carry data. "
      "That is why `Average Daily Volume` divides by `Active Days` and why "
      "`Previous Available Date` searches for the previous day that exists "
      "rather than subtracting one calendar day."
      % (s["earliest_date"], s["latest_date"], s["active_days"]))
    w("")

    w("## 8. Dynamic reminder journeys")
    w("")
    w("This is the check that matters most. For each Client + Program the "
      "dashboard must render **exactly** these stages and no others.")
    w("")
    w("| Client | Program | Stages present in source | Journey the report must show |")
    w("|---|---|---|---|")
    for k, stages in sorted(s["journeys"].items()):
        client, program = k.split(" || ")
        w("| %s | %s | %s | %s |"
          % (client, program, ", ".join(stages), "  ->  ".join(stages)))
    w("")
    w("The extract happens to contain a one-stage journey, a three-stage "
      "journey and a four-stage journey, so all three shapes are exercised by "
      "real data rather than by a contrived test case.")
    w("")

    w("## 9. Counts")
    w("")
    w("| Metric | Source CSV value | Power BI measure |")
    w("|---|---:|---|")
    for label, key, meas in [
            ("Distinct clients", "client_count", "Client Count"),
            ("Distinct programs", "program_count", "Program Count"),
            ("Distinct reminder stages", "reminder_count", "Reminder Count"),
            ("Distinct creatives", "creative_count", "Creative Count"),
            ("Distinct sites", "site_count", "Site Count")]:
        w("| %s | %s | `%s` |" % (label, s[key], meas))
    w("")

    w("## 10. Data quality")
    w("")
    w("| Check | Rows failing | Power BI measure |")
    w("|---|---:|---|")
    for label, key, meas in [
            ("Null Client_name", "null_client", "Null Client Rows"),
            ("Null Program", "null_program", "Null Program Rows"),
            ("Null rem_flag", "null_reminder", "Null Reminder Rows"),
            ("Unparseable file_date", "null_date", "Null Date Rows"),
            ("Null volume", "null_volume", "Null Email Volume Rows"),
            ("Negative volume", "negative_volume", "Negative Email Values"),
            ("t_c_ind not in (T, C)", "unexpected_tc", "Unexpected T/C Values"),
            ("rem_flag not REM + digits or day-N", "unexpected_reminder",
             "Unexpected Reminder Values"),
            ("Duplicate business grain", "duplicate_rows", "Duplicate Rows")]:
        w("| %s | %d | `%s` |" % (label, s["dq"][key], meas))
    w("")
    total_dq = sum(s["dq"].values())
    w("**Data quality status: %s** - %d rows fail any check."
      % ("PASS" if total_dq == 0 else "REVIEW", total_dq))
    w("")

    w("## 11. Test / Control finding")
    w("")
    if s["control_rows"] == 0:
        w("> **The supplied extract contains no Control records at all.** Every "
          "one of the %d rows carries `t_c_ind = \"T\"`."
          % s["source_rows"])
        w("")
        w("This is a finding about the data, not a defect in the model. The "
          "consequences to be aware of when reading the report:")
        w("")
        w("- `Email Volume` (Test only) and the raw volume column sum are "
          "identical **for this extract** - %s either way. They will diverge "
          "the moment a Control row appears, which is exactly why the Test-only "
          "rule is enforced in the measure rather than assumed."
          % "{:,}".format(s["email_volume_test"]))
        w("- `Control Population` returns 0 and the Test/Control split shows "
          "100% Test.")
        w("- Selecting **Control** in the population slicer produces a blank "
          "page with the banner *CONTROL POPULATION - NO EMAILS SENT*. That is "
          "correct behaviour, and the model still carries the Control member so "
          "the slicer can express it.")
    else:
        w("The extract contains %d Control rows carrying %s in the volume "
          "column. That figure is a population count and is never reported as "
          "email sent." % (s["control_rows"],
                           "{:,}".format(s["control_volume_column_sum"])))
    w("")
    return "\n".join(L)


def main():
    rows, headers, vol_col = load()
    s = summarise(rows)

    os.makedirs(DOCS, exist_ok=True)
    md = markdown(s, headers, vol_col)
    with open(os.path.join(DOCS, "Validation.md"), "w", encoding="utf-8") as fh:
        fh.write(md + "\n")
    with open(os.path.join(DOCS, "validation_summary.json"), "w",
              encoding="utf-8") as fh:
        json.dump(s, fh, indent=1, sort_keys=True)

    print("validation computed from %s" % CSV_PATH)
    print("  rows                %d  (test %d / control %d)"
          % (s["source_rows"], s["test_rows"], s["control_rows"]))
    print("  Email Volume (T)    %s" % "{:,}".format(s["email_volume_test"]))
    print("  volume column sum   %s" % "{:,}".format(s["email_volume_all"]))
    for k in sorted(s["rem_totals"]):
        print("    %-5s            %6s  (%.2f%%)"
              % (k, "{:,}".format(s["rem_totals"][k]), s["rem_pct"][k] * 100))
    print("  active days         %d  (%s -> %s)"
          % (s["active_days"], s["earliest_date"], s["latest_date"]))
    print("  latest / previous   %s = %s  /  %s = %s   DoD %.2f%%"
          % (s["latest_date"], s["latest_day_volume"], s["previous_date"],
             s["previous_day_volume"], s["dod_pct"] * 100))
    print("  journeys:")
    for k, v in sorted(s["journeys"].items()):
        print("    %-46s %s" % (k, " -> ".join(v)))
    dq = sum(s["dq"].values())
    print("  data quality        %s (%d flagged rows)"
          % ("PASS" if dq == 0 else "REVIEW", dq))
    print("\nwrote Documentation/Validation.md and validation_summary.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
