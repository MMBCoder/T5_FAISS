# -*- coding: utf-8 -*-
"""Audits whether every text element has room to render.

Power BI does not reflow a text run whose container is too short, and it does
not error either. It clips the run and grows a scrollbar, so the page simply
comes out with its headings cut in half - which is exactly how this report's
masthead shipped once already.

Two things have to fit inside a container:

  * the line boxes themselves, roughly 1.75x the point size each, and
  * the renderer's own vertical padding, about 16px top and bottom together,
    which is charged once per visual no matter how many lines it holds.

This walks the emitted report.json and fails the build on anything that does
not clear both. Textboxes are measured exactly; cards are measured against
their value run plus whatever title and subtitle they carry.

Run:  python tools/check_text_fit.py
Exit code 1 if anything would clip.
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT = "CDP_Reminder_Volume_Dashboard"
LEGACY = os.path.join(ROOT, PROJECT + ".Report", "report.json")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from preview_report import val, prop, measure_of   # noqa: E402

# Measured against Desktop 2.157 by shipping a masthead that clipped and then
# growing each container until it stopped.
#
# A textbox does not adapt at all: it needs about 1.75x its point size per
# line, plus 16px of its own padding charged once. Those are the containers
# that clip, and they are checked exactly.
#
# A card behaves differently again, and the difference is size-dependent. A big
# value is auto-shrunk to fit its box, so 28pt lives happily in 46px. Small text
# is not shrunk: it is clipped. A 10pt stage label in a 22px card lost the tops
# of its capitals, while the 8.5pt caption directly beneath it, in a box of
# exactly the same height, rendered perfectly.
#
# So: runs below CARD_SHRINK_PT are held to the strict factor, runs at or above
# it get the loose one because the renderer will scale them down. A single
# factor cannot describe both - the first version of this check used 1.3 for
# everything, passed the clipped labels, and had to be corrected from a
# screenshot.
TEXT_LINE = 1.75
TEXT_PAD = 16
CARD_SHRINK_PT = 14      # at or above this, the card scales the text to fit
CARD_SMALL = 2.40        # below it, the text is clipped instead
CARD_LARGE = 1.60
# A card's title and subtitle are laid out by the container, which packs them
# more tightly than the value area. Holding them to CARD_SMALL flagged every
# KPI tile in the report by three pixels while the screenshots showed all of
# them rendering cleanly.
CARD_CHROME = 2.00


def need_card(chrome_sizes, value_size):
    h = sum(s * CARD_CHROME for s in chrome_sizes)
    if value_size is not None:
        h += value_size * (CARD_LARGE if value_size >= CARD_SHRINK_PT
                           else CARD_SMALL)
    return h


def need_text(sizes):
    return sum(s * TEXT_LINE for s in sizes) + TEXT_PAD


def main():
    doc = json.load(open(LEGACY, encoding="utf-8"))
    problems, checked = [], 0

    for sec in sorted(doc["sections"], key=lambda s: s.get("ordinal", 0)):
        pname = sec.get("displayName", sec["name"])
        for vc in sec["visualContainers"]:
            cfg = json.loads(vc["config"])
            sv = cfg.get("singleVisual", {})
            vt = sv.get("visualType")
            h = vc.get("height", 0)
            o = sv.get("objects", {})
            vco = sv.get("vcObjects", {})

            # chrome the container carries regardless of its type
            chrome_sizes = []
            if prop(vco, "title", "show"):
                chrome_sizes.append(prop(vco, "title", "fontSize", 11))
            if prop(vco, "subTitle", "show"):
                chrome_sizes.append(prop(vco, "subTitle", "fontSize", 9.5))

            label, sizes = None, None
            if vt == "textbox":
                runs = []
                for para in (prop(o, "general", "paragraphs") or []):
                    biggest = 0
                    text = ""
                    for r in para.get("textRuns", []):
                        st = r.get("textStyle", {})
                        size = float(str(st.get("fontSize", "9pt")).replace("pt", ""))
                        biggest = max(biggest, size)
                        text += r.get("value", "")
                    if text.strip():
                        runs.append((biggest, text))
                if runs:
                    sizes = [r[0] for r in runs]
                    label = "textbox %r" % runs[0][1][:30]
            elif vt == "card":
                value_size = prop(o, "labels", "fontSize", 28)
                sizes = ["card"]
                label = "card <%s>" % (measure_of(cfg) or "?")

            if not sizes:
                continue
            checked += 1
            if vt == "card":
                required = need_card(chrome_sizes, value_size)
            else:
                required = need_text(chrome_sizes + sizes)
            if required > h + 0.5:
                problems.append((pname, label, h, required))

    for pname, label, h, required in problems:
        print("  TIGHT %-22s %-44s height %3.0fpx, needs %3.0fpx"
              % (pname[:22], label[:44], h, required))
    print("text fit: %d containers checked, %d too tight"
          % (checked, len(problems)))
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
