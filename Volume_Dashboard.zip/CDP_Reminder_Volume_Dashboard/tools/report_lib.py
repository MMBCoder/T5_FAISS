"""Builders for PBIR report definition JSON.

Everything the report generator emits goes through these helpers so the
expression encoding (literals, measure references, colour bindings) is written
once and stays consistent across ~200 visuals.
"""

SCHEMA_VISUAL = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/1.4.0/schema.json"
SCHEMA_PAGE = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/1.4.0/schema.json"
SCHEMA_PAGES = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.0.0/schema.json"
SCHEMA_REPORT = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/report/1.0.0/schema.json"
SCHEMA_BOOKMARK = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/bookmark/1.0.0/schema.json"
SCHEMA_BOOKMARKS = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/bookmarksMetadata/1.0.0/schema.json"
SCHEMA_VERSION = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/versionMetadata/1.0.0/schema.json"
SCHEMA_PBIR = "https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/1.0.0/schema.json"
SCHEMA_PLATFORM = "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json"
# The .pbip shortcut lives under fabric/pbip/, not fabric/item/pbip/.
SCHEMA_PBIP = "https://developer.microsoft.com/json-schemas/fabric/pbip/pbipProperties/1.0.0/schema.json"
SCHEMA_PBISM = "https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json"

MEASURE_TABLE = "_Measures"

# --------------------------------------------------------------------------
# palette - the single source of truth for report colour
# --------------------------------------------------------------------------
# CDP has a deliberately different identity from the IDR console, which is a
# dark navy instrument panel. This one is its opposite: a light, printed
# editorial page. Warm paper canvas, white cards with a hairline rule, and a
# single inverted deep-pine masthead at the top holding all the controls. The
# two reports should never be mistaken for each other at a glance.
BG_PAGE = "#F3F0E9"       # warm paper - the canvas
BG_OUTSPACE = "#E5E0D5"   # the surround, one step deeper than the page
BG_CARD = "#FFFFFF"       # a card is white paper laid on the canvas
BG_BAND = "#FAF8F3"       # a band that groups cards without boxing them
BG_PANEL = "#12332F"      # deep pine - the inverted masthead
BG_PANEL_2 = "#0D2724"    # the masthead's darker inner well (filters, period)
BG_QUOTE = "#EDE7DA"      # the narrative strip - the one tinted body surface
BORDER = "#DBD4C4"        # hairline warm grey, the only card outline used
BORDER_SOFT = "#EAE4D7"   # row rules inside a table
TEXT_HI = "#13211F"       # ink
TEXT_MID = "#56635F"
TEXT_LOW = "#6B716E"        # 4.7:1 on paper - the pale grey that worked on navy is invisible here
# Text sitting on the inverted masthead. Named separately so no caller has to
# remember which zone it is writing into.
INK_HI = "#F5F2EA"
INK_MID = "#A6BCB4"
INK_LOW = "#889C95"       # 4.7:1 on the pine masthead
PINE_LINE = "#1D4941"     # the only outline drawn inside the masthead

# The accent family is warm-editorial rather than the console's electric blues.
TEAL = "#0E7A6A"          # primary - reminder 1, page 1
STEEL = "#2B6C97"         # reminder 2, page 2
CLAY = "#C05A38"          # reminder 3, page 3
GOLD = "#C79020"          # reminder 4, page 4
SLATE = "#5A6B76"         # page 5, and any "other" category
CLAY_TEXT = "#B45434"     # clay and gold pass as fills but fail as
GOLD_TEXT = "#916917"     # small text on paper - these are the twins

GREEN = "#2E7D52"         # volume rise
AMBER = "#C79020"         # attention / volume fall
RED = "#AE3B2B"           # exception only
# Kept under their old names so nothing downstream has to be rewritten, but
# they now point at the editorial family.
BLUE = TEAL
CYAN = STEEL
PURPLE = CLAY
GRID = "#E4DDCE"          # gridlines sit under the data, never beside it
BAND_ALT = "#F7F4ED"      # banded table row

FONT = "Segoe UI"
FONT_SEMI = "Segoe UI Semibold"
FONT_LIGHT = "Segoe UI Light"

PAGE_W = 1440
PAGE_H = 810


# --------------------------------------------------------------------------
# expression encoding
# --------------------------------------------------------------------------
def lit(v):
    """Literal expression container."""
    if isinstance(v, bool):
        val = "true" if v else "false"
    elif isinstance(v, int):
        val = "%dD" % v
    elif isinstance(v, float):
        val = "%gD" % v
    else:
        val = "'%s'" % str(v).replace("'", "''")
    return {"expr": {"Literal": {"Value": val}}}


def measure_expr(name, entity=MEASURE_TABLE):
    return {"Measure": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": name}}


def column_expr(entity, prop):
    return {"Column": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}


def m_bound(name, entity=MEASURE_TABLE):
    """Property value bound to a measure (conditional formatting)."""
    return {"expr": measure_expr(name, entity)}


def solid(color):
    """Solid colour from a hex string."""
    return {"solid": {"color": lit(color)}}


def solid_m(measure_name, entity=MEASURE_TABLE):
    """Solid colour driven by a measure that returns a hex string."""
    return {"solid": {"color": {"expr": measure_expr(measure_name, entity)}}}


# --------------------------------------------------------------------------
# projections
# --------------------------------------------------------------------------
def pm(name, entity=MEASURE_TABLE, display=None, fmt=None):
    """Measure projection."""
    p = {"field": measure_expr(name, entity),
         "queryRef": "%s.%s" % (entity, name),
         "nativeQueryRef": name}
    if display:
        p["displayName"] = display
    if fmt:
        p["format"] = fmt
    return p


def pc(entity, prop, display=None, fmt=None):
    """Column projection."""
    p = {"field": column_expr(entity, prop),
         "queryRef": "%s.%s" % (entity, prop),
         "nativeQueryRef": prop}
    if display:
        p["displayName"] = display
    if fmt:
        p["format"] = fmt
    return p


def qref(proj):
    return proj["queryRef"]


# --------------------------------------------------------------------------
# formatting object helpers
# --------------------------------------------------------------------------
def obj(props, selector=None):
    o = {"properties": props}
    if selector:
        o["selector"] = selector
    return o


def sel_meta(queryref):
    return {"metadata": queryref}


def sel_id(name):
    return {"id": name}


# --------------------------------------------------------------------------
# visual container
# --------------------------------------------------------------------------
_tab = [0]


def visual(name, x, y, w, h, vtype, roles=None, objects=None, container=None,
           z=None, filters=None, sort=None, sync_group=None, hidden=False,
           parent=None):
    """Assemble one visual container."""
    _tab[0] += 1
    v = {
        "$schema": SCHEMA_VISUAL,
        "name": name,
        "position": {"x": x, "y": y, "z": _tab[0] if z is None else z,
                     "width": w, "height": h, "tabOrder": _tab[0] * 10},
        "visual": {"visualType": vtype},
    }
    if roles:
        q = {"queryState": {}}
        for role, spec in roles.items():
            # A role is either a plain list of projections, or a dict carrying
            # field-parameter metadata alongside the materialised projections.
            q["queryState"][role] = spec if isinstance(spec, dict) else {"projections": spec}
        if sort:
            q["sortDefinition"] = sort
        v["visual"]["query"] = q
    if objects:
        v["visual"]["objects"] = objects
    if container:
        v["visual"]["visualContainerObjects"] = container
    if sync_group:
        # A sync group is an object, not a bare name. Emitting the string
        # alone produced a slicer Desktop could not parse as synced: the
        # selection did not survive page navigation - despite the design notes
        # claiming it did - and the slicers stopped taking part in
        # cross-filtering with each other.
        #
        # fieldChanges stays false: every synced slicer already shows the same
        # field, and letting a field change propagate would let one page
        # silently repoint the others.
        v["visual"]["syncGroup"] = {"groupName": sync_group,
                                    "fieldChanges": False,
                                    "filterChanges": True}
    if roles:
        v["visual"]["drillFilterOtherVisuals"] = True
    if filters:
        v["filterConfig"] = {"filters": filters}
    if hidden:
        v["isHidden"] = True
    if parent:
        v["parentGroupName"] = parent
    return v


def sort_by(field_expr, direction="Descending"):
    return {"sort": [{"field": field_expr, "direction": direction}],
            "isDefaultSort": False}


# --------------------------------------------------------------------------
# container chrome presets
# --------------------------------------------------------------------------
def chrome(title=None, title_measure=None, subtitle=None, subtitle_measure=None,
           bg=BG_CARD, border=BORDER, radius=0, title_size=11, transparent=False,
           title_color=TEXT_HI, pad=None, sub_wrap=True, align="left",
           header=False):
    """Standard card chrome: background, border, title, subtitle, no header."""
    c = {
        "background": [obj({"show": lit(not transparent),
                            "color": solid(bg),
                            "transparency": lit(100 if transparent else 0)})],
        "border": [obj({"show": lit(border is not None and not transparent),
                        "color": solid(border or BORDER),
                        "radius": lit(radius)})],
        # Power BI has no scriptable "download" action - a button can navigate,
        # bookmark, drill through or open a URL, and nothing else. Export data
        # lives in the visual header's overflow menu, so exposing that header
        # is the only supported way to offer an export from the page itself.
        "visualHeader": [obj({"show": lit(header),
                              "foreground": solid(TEXT_LOW),
                              "background": solid(BG_CARD),
                              "transparency": lit(0),
                              "showVisualInformationButton": lit(False),
                              "showVisualWarningButton": lit(False),
                              "showVisualErrorButton": lit(False),
                              "showDrillRoleSelector": lit(False),
                              "showDrillUpButton": lit(False),
                              "showDrillToggleButton": lit(False),
                              "showDrillDownLevelButton": lit(False),
                              "showDrillDownExpandButton": lit(False),
                              "showFilterRestatementButton": lit(False),
                              "showFocusModeButton": lit(True),
                              "showOptionsMenu": lit(True)})],
        "dropShadow": [obj({"show": lit(False)})],
    }
    if title or title_measure:
        props = {
            "show": lit(True),
            "fontColor": solid(title_color),
            # A transparent container sits on a panel that already supplies the
            # surface colour, so the title must not paint its own.
            "alignment": lit(align),
            "fontSize": lit(title_size),
            "fontFamily": lit(FONT_SEMI),
            "titleWrap": lit(False),
        }
        if not transparent:
            props["background"] = solid(bg)
        props["text"] = m_bound(title_measure) if title_measure else lit(title)
        c["title"] = [obj(props)]
    else:
        c["title"] = [obj({"show": lit(False)})]
    if subtitle or subtitle_measure:
        props = {
            "show": lit(True),
            "fontColor": solid(TEXT_MID),
            "alignment": lit(align),
            # 9pt captions were being skipped rather than read. 9.5 is still
            # clearly subordinate to the value but survives a projector.
            "fontSize": lit(9.5),
            "fontFamily": lit(FONT),
            # A KPI tile passes sub_wrap=False: a caption that wraps to two
            # lines pushes the number off the bottom of the card, and Power BI
            # clips it rather than shrinking it.
            "titleWrap": lit(sub_wrap),
        }
        props["text"] = m_bound(subtitle_measure) if subtitle_measure else lit(subtitle)
        c["subTitle"] = [obj(props)]
    if pad:
        c["padding"] = [obj({"top": lit(pad[0]), "right": lit(pad[1]),
                             "bottom": lit(pad[2]), "left": lit(pad[3])})]
    return c


def tooltip_page(page_name):
    """Bind a visual to a report-page tooltip."""
    return {"visualTooltip": [obj({"show": lit(True),
                                   "type": lit("Canvas"),
                                   "section": lit(page_name)})]}


# --------------------------------------------------------------------------
# common visuals
# --------------------------------------------------------------------------
# A textbox reserves roughly this much of its height for its own padding, top
# and bottom together. It is the reason a container sized to the bare line box
# silently grows a scrollbar and clips the text: 18pt needs about 30px of line
# and then this on top. Every height in the report is sized against it.
TEXT_PAD = 16


def line_box(size_pt):
    """The height a single run of this size actually needs, padding included."""
    return int(round(size_pt * 1.75)) + TEXT_PAD


def textbox(name, x, y, w, h, runs, align="left", bg=None, border=None,
            valign="middle", z=None):
    """runs = [(text, size_pt, color, weight)], or a list of such lists to
    stack several lines in one container.

    Stacking matters: two textboxes each pay TEXT_PAD, so a caption over a
    title costs 32px of padding as two visuals and 16px as one. The masthead
    could not afford the difference.
    """
    paragraphs = runs if runs and isinstance(runs[0], (list,)) else [runs]
    paras = []
    for para in paragraphs:
        text_runs = []
        for t in para:
            text, size, color, weight = (tuple(t) + (None,) * 4)[:4]
            style = {"fontSize": "%gpt" % size, "color": color or TEXT_HI}
            if weight:
                style["fontWeight"] = str(weight)
                style["fontFamily"] = FONT_SEMI
            else:
                style["fontFamily"] = FONT
            text_runs.append({"value": text, "textStyle": style})
        paras.append({"textRuns": text_runs, "horizontalTextAlignment": align})
    objects = {"general": [obj({"paragraphs": paras})]}
    cont = {
        "background": [obj({"show": lit(bg is not None),
                            "color": solid(bg or BG_CARD),
                            "transparency": lit(0 if bg else 100)})],
        "border": [obj({"show": lit(border is not None),
                        "color": solid(border or BORDER), "radius": lit(0)})],
        "title": [obj({"show": lit(False)})],
        "visualHeader": [obj({"show": lit(False)})],
        "dropShadow": [obj({"show": lit(False)})],
        "general": [obj({"altText": lit(" ".join(
            r[0] for para in paragraphs for r in para)[:120])})],
    }
    v = visual(name, x, y, w, h, "textbox", objects=objects, container=cont, z=z)
    v["visual"]["objects"]["general"][0]["properties"]["verticalTextAlignment"] = lit(valign)
    return v


def panel(name, x, y, w, h, bg=BG_CARD, border=BORDER, radius=0, z=0):
    """An empty card surface used as the background of a composed KPI tile."""
    return textbox(name, x, y, w, h, [(" ", 8, TEXT_HI)], bg=bg, border=border, z=z)


# There is deliberately no hairline-rule helper. Power BI enforces a minimum
# rendered height on a visual container, so a 1px "rule" comes out as an ~11px
# grey slab sitting across whatever is beneath it - which is exactly what made
# the section headings look like they were overlapping. Bands are opened by
# their accent label alone. The one safe thin shape is a bar at least
# TICK_MIN px on its short side, which is what tick() enforces.
TICK_MIN = 4


def tick(name, x, y, w, h, color, z=1):
    """The short accent bar down the left edge of a KPI tile. It carries the
    page's identity onto every tile without tinting the tile itself."""
    return panel(name, x, y, max(w, TICK_MIN), max(h, TICK_MIN), bg=color,
                 border=None, z=z)


def nav_button(name, x, y, w, h, label, target_page, active=False,
               accent=TEAL, on_dark=True):
    """Page-navigation button for the report navigation bar.

    The bar sits inside the inverted masthead, so the resting state is a well
    cut into the pine rather than a raised light tile: a row of five light
    buttons on a dark band reads as five equally-important calls to action, and
    the active page stops being findable.
    """
    if on_dark:
        fill = accent if active else BG_PANEL_2
        fg = "#FFFFFF" if active else INK_MID
        line = accent if active else "#1D4941"
    else:
        fill = accent if active else BG_CARD
        fg = "#FFFFFF" if active else TEXT_MID
        line = accent if active else BORDER
    # A button formatting object carries "show" on an entry with no selector,
    # and the appearance for a given button state on an entry selected by that
    # state's id. Putting both on the same entry leaves the button unstyled.
    objects = {
        "icon": [obj({"show": lit(False)})],
        "outline": [obj({"show": lit(True)}),
                    obj({"lineColor": solid(line), "weight": lit(1),
                         "transparency": lit(0), "roundEdge": lit(6)},
                        sel_id("default"))],
        "fill": [obj({"show": lit(True)}),
                 obj({"fillColor": solid(fill), "transparency": lit(0)},
                     sel_id("default"))],
        "text": [obj({"show": lit(True)}),
                 obj({"text": lit(label), "fontColor": solid(fg),
                      "fontSize": lit(9),
                      "fontFamily": lit(FONT_SEMI if active else FONT),
                      "bold": lit(False), "horizontalAlignment": lit("center"),
                      "verticalAlignment": lit("middle"),
                      "topMargin": lit(0), "bottomMargin": lit(0),
                      "leftMargin": lit(2), "rightMargin": lit(2)},
                     sel_id("default"))],
    }
    cont = {
        "visualLink": [obj({"show": lit(True), "type": lit("PageNavigation"),
                            "navigationSection": lit(target_page),
                            "tooltip": lit("Go to " + label)})],
        "background": [obj({"show": lit(False)})],
        "border": [obj({"show": lit(False)})],
        "title": [obj({"show": lit(False)})],
        "visualHeader": [obj({"show": lit(False)})],
        "dropShadow": [obj({"show": lit(False)})],
    }
    return visual(name, x, y, w, h, "actionButton", objects=objects, container=cont)


def bookmark_button(name, x, y, w, h, label, bookmark_name):
    objects = {
        "icon": [obj({"show": lit(False)})],
        "outline": [obj({"show": lit(True)}),
                    obj({"lineColor": solid(BORDER), "weight": lit(1),
                         "roundEdge": lit(6)}, sel_id("default"))],
        "fill": [obj({"show": lit(True)}),
                 obj({"fillColor": solid(BG_CARD), "transparency": lit(0)},
                     sel_id("default"))],
        "text": [obj({"show": lit(True)}),
                 obj({"text": lit(label), "fontColor": solid(TEXT_MID),
                      "fontSize": lit(9), "fontFamily": lit(FONT),
                      "horizontalAlignment": lit("center"),
                      "verticalAlignment": lit("middle")}, sel_id("default"))],
    }
    cont = {
        "visualLink": [obj({"show": lit(True), "type": lit("Bookmark"),
                            "bookmark": lit(bookmark_name),
                            "tooltip": lit(label)})],
        "background": [obj({"show": lit(False)})],
        "border": [obj({"show": lit(False)})],
        "title": [obj({"show": lit(False)})],
        "visualHeader": [obj({"show": lit(False)})],
        "dropShadow": [obj({"show": lit(False)})],
    }
    return visual(name, x, y, w, h, "actionButton", objects=objects, container=cont)


def card(name, x, y, w, h, measure, title=None, subtitle_measure=None,
         value_color=None, value_color_measure=None, size=28, bg=BG_CARD,
         border=BORDER, transparent=False, units=None, precision=None,
         entity=MEASURE_TABLE, tooltip=None, title_size=10,
         title_color=TEXT_LOW, align="left"):
    """Classic card: one big number or text value, with dynamic caption.

    The label defaults to TEXT_LOW rather than TEXT_HI. A tile is read value
    first, label second - when both were full-strength white the eye had to
    choose, and eight tiles in a row became a wall of equal-weight text.
    """
    label_props = {
        "color": (solid_m(value_color_measure) if value_color_measure
                  else solid(value_color or TEXT_HI)),
        "fontSize": lit(size),
        "fontFamily": lit(FONT_SEMI),
    }
    # Display units are left unset by default so the card renders the measure's
    # own format string, exactly as a table or a chart label does. Pinning
    # labelDisplayUnits made the card take a different formatting path from
    # every other visual on the page, and 2,016 came out as "2.016".
    if units is not None:
        label_props["labelDisplayUnits"] = lit(units)
    if precision is not None:
        label_props["labelPrecision"] = lit(precision)
    objects = {
        "labels": [obj(label_props)],
        "categoryLabels": [obj({"show": lit(False)})],
        "wordWrap": [obj({"show": lit(True)})],
    }
    cont = chrome(title=title, subtitle_measure=subtitle_measure, bg=bg,
                  border=border, transparent=transparent, title_size=title_size,
                  title_color=title_color, sub_wrap=False, align=align)
    if tooltip:
        cont.update(tooltip_page(tooltip))
    return visual(name, x, y, w, h, "card",
                  roles={"Values": [pm(measure, entity)]},
                  objects=objects, container=cont)


def sparkline(name, x, y, w, h, measure, color=BLUE, entity=MEASURE_TABLE):
    """Minimal line chart used as an in-card sparkline: no chrome at all."""
    p = pm(measure, entity)
    objects = {
        "categoryAxis": [obj({"show": lit(False), "axisType": lit("Categorical")})],
        "valueAxis": [obj({"show": lit(False), "gridlineShow": lit(False)})],
        "legend": [obj({"show": lit(False)})],
        "labels": [obj({"show": lit(False)})],
        "plotArea": [obj({"transparency": lit(100)})],
        "lineStyles": [obj({"strokeWidth": lit(2), "showMarker": lit(False),
                            "lineStyle": lit("solid")})],
        "dataPoint": [obj({"fill": solid(color)}, sel_meta(qref(p)))],
    }
    cont = chrome(transparent=True)
    return visual(name, x, y, w, h, "lineChart",
                  roles={"Category": [pc("Dim_Date", "Date")], "Y": [p]},
                  objects=objects, container=cont)


def axis_objects(cat_title=None, val_title=None, val_start=None, val_end=None,
                 legend=False, legend_pos="Top", cat_type="Categorical",
                 gridlines=True, cat_size=9, val_size=9, cat_concat=False):
    o = {
        "categoryAxis": [obj({
            "show": lit(True), "axisType": lit(cat_type),
            "labelColor": solid(TEXT_MID), "fontSize": lit(cat_size),
            "fontFamily": lit(FONT),
            "showAxisTitle": lit(cat_title is not None),
            "gridlineShow": lit(False),
            "concatenateLabels": lit(cat_concat),
        })],
        "valueAxis": [obj({
            "show": lit(True), "labelColor": solid(TEXT_MID),
            "fontSize": lit(val_size), "fontFamily": lit(FONT),
            "showAxisTitle": lit(val_title is not None),
            "gridlineShow": lit(gridlines),
            "gridlineColor": solid(GRID),
            "gridlineThickness": lit(1),
            "gridlineStyle": lit("solid"),
        })],
        "legend": [obj({"show": lit(legend), "position": lit(legend_pos),
                        "labelColor": solid(TEXT_MID), "fontSize": lit(9),
                        "fontFamily": lit(FONT), "showTitle": lit(False)})],
        "plotArea": [obj({"transparency": lit(100)})],
    }
    if cat_title:
        o["categoryAxis"][0]["properties"]["titleColor"] = solid(TEXT_LOW)
        o["categoryAxis"][0]["properties"]["titleText"] = lit(cat_title)
    if val_title:
        o["valueAxis"][0]["properties"]["titleColor"] = solid(TEXT_LOW)
        o["valueAxis"][0]["properties"]["titleText"] = lit(val_title)
    if val_start is not None:
        o["valueAxis"][0]["properties"]["start"] = lit(val_start)
    if val_end is not None:
        o["valueAxis"][0]["properties"]["end"] = lit(val_end)
    return o


def series_color(projection, color):
    return obj({"fill": solid(color)}, sel_meta(qref(projection)))


def line_style(projection, width=2, marker=False, style="solid", marker_size=4):
    return obj({"strokeWidth": lit(width), "showMarker": lit(marker),
                "lineStyle": lit(style), "markerSize": lit(marker_size)},
               sel_meta(qref(projection)))


def table_objects(font_size=9, header_size=9, row_pad=4, wrap=False):
    """Table styling.

    Headers sit on the card background rather than a fill of their own, and
    only horizontal rules are drawn. A header band plus vertical rules plus
    banding is three separate ways of saying "these are columns", and the data
    disappears underneath them.
    """
    return {
        "grid": [obj({
            "gridVertical": lit(False),
            "gridHorizontal": lit(True),
            "gridHorizontalColor": solid(BORDER_SOFT),
            "gridHorizontalWeight": lit(1),
            "outlineColor": solid(BORDER_SOFT),
            "outlineWeight": lit(0),
            "rowPadding": lit(row_pad),
            "textSize": lit(font_size),
        })],
        "columnHeaders": [obj({
            "fontColor": solid(TEXT_LOW),
            "backColor": solid(BG_CARD),
            "titleAlignment": lit("left"),
            "fontSize": lit(header_size),
            "fontFamily": lit(FONT_SEMI),
            "bold": lit(False),
            "alignment": lit("left"),
            "autoSizeColumnWidth": lit(True),
            "wordWrap": lit(True),
        })],
        "values": [obj({
            "fontColor": solid(TEXT_HI),
            "backColor": solid(BG_CARD),
            "fontColorPrimary": solid(TEXT_HI),
            "backColorPrimary": solid(BG_CARD),
            "fontColorSecondary": solid(TEXT_HI),
            "backColorSecondary": solid(BAND_ALT),
            "bandedRowHeadersandTotal": lit(True),
            "fontSize": lit(font_size),
            "fontFamily": lit(FONT),
            "wordWrap": lit(wrap),
        })],
        # The table visual reads this as "totals", not "show"; with only "show"
        # set it went on drawing a grand-total row, which on a row-level extract
        # means summing a status column and is simply noise.
        "total": [obj({"show": lit(False), "totals": lit(False)})],
    }


def value_color_rule(projection, color_measure):
    """Colour one table/matrix column by a measure returning a hex string."""
    return obj({"fontColor": solid_m(color_measure)}, sel_meta(qref(projection)))


def value_back_rule(projection, color_measure):
    return obj({"backColor": solid_m(color_measure)}, sel_meta(qref(projection)))


# --------------------------------------------------------------------------
# filters
# --------------------------------------------------------------------------
def measure_filter(name, measure, comparison, value, entity=MEASURE_TABLE):
    """Advanced filter on a measure. comparison: 0 eq,1 gt,2 gte,3 lt,4 lte."""
    src = "f"
    return {
        "name": name,
        "field": measure_expr(measure, entity),
        "type": "Advanced",
        "filter": {
            "Version": 2,
            "From": [{"Name": src, "Entity": entity, "Type": 0}],
            "Where": [{"Condition": {"Comparison": {
                "ComparisonKind": comparison,
                "Left": {"Measure": {"Expression": {"SourceRef": {"Source": src}},
                                     "Property": measure}},
                "Right": {"Literal": {"Value": "%dL" % value}},
            }}}],
        },
        "howCreated": "User",
    }


def field_parameter(column, index=0, length=1):
    """Declares that the projections at `index` are supplied by a field parameter."""
    return {"parameterExpr": column, "index": index, "length": length}


def drillthrough_filter(name, entity, prop):
    return {
        "name": name,
        "field": column_expr(entity, prop),
        "type": "Categorical",
        "howCreated": "Drillthrough",
        "isHiddenInViewMode": False,
    }


# --------------------------------------------------------------------------
# page
# --------------------------------------------------------------------------
def page(name, display, ordinal, visuals, height=PAGE_H, width=PAGE_W,
         ptype=None, binding=None, filters=None, visibility=None,
         interactions=None):
    p = {
        "$schema": SCHEMA_PAGE,
        "name": name,
        "displayName": display,
        "displayOption": "FitToPage",
        "height": height,
        "width": width,
        "objects": {
            "background": [obj({"color": solid(BG_PAGE), "transparency": lit(0)})],
            "outspace": [obj({"color": solid(BG_OUTSPACE), "transparency": lit(0)})],
            "outspacePane": [obj({
                "backgroundColor": solid(BG_BAND),
                "foregroundColor": solid(TEXT_MID),
                "borderColor": solid(BORDER),
                "border": lit(True),
                "checkboxAndApplyColor": solid(BLUE),
                "inputBoxColor": solid(BG_CARD),
                "fontFamily": lit(FONT),
                "titleSize": lit(11),
                "headerSize": lit(9),
                "searchTextSize": lit(9),
                "width": lit(280),
            })],
        },
    }
    if ptype:
        p["type"] = ptype
    if binding:
        p["pageBinding"] = binding
    if filters:
        p["filterConfig"] = {"filters": filters}
    if visibility:
        p["visibility"] = visibility
    if interactions:
        p["visualInteractions"] = interactions
    return p, visuals
