# -*- coding: utf-8 -*-
"""Every explicit measure in the CDP model.

The two rules that shape all of this:

1. **Email volume is Test-only.** ``Email Volume`` filters the fact to
   ``t_c_ind = "T"``. Control rows stay in the model so the population can be
   analysed, but they can never contribute to a number labelled "email".
   Selecting Control in the population slicer intersects that selection with the
   ``"T"`` filter and correctly yields blank, which the page banner explains.

2. **Absence is not zero.** A stage that is not part of a client + program
   journey returns BLANK; a stage that exists but had no volume in the selected
   window returns 0. The ``* In Journey`` measures evaluate stage membership
   with the date filter removed, which is what separates the two cases.
"""

FMT_INT = '"#,##0"'
FMT_PCT = '"0.0%"'
FMT_PCT2 = '"+0.0%;-0.0%;0.0%"'
FMT_DATE = "dd-mmm-yyyy"
FMT_SIGNED = '"+#,##0;-#,##0;0"'

# Colours must match report_lib's palette, since these drive conditional
# formatting inside visuals that the palette also styles.
GREEN, AMBER, RED, BLUE, TEXT_HI, TEXT_MID = (
    "#2E7D52", "#916917", "#AE3B2B", "#0E7A6A", "#13211F", "#56635F")
# One identity per reminder stage, reused on every page (spec section 55).
STAGE_COLOURS = ["#0E7A6A", "#2B6C97", "#C05A38", "#C79020"]
SLATE = "#5A6B76"
# Slate as small text on the journey band's warm paper measures 4.49:1 - a hair
# under the 4.5:1 AA floor - so its text register is darkened, exactly as clay
# and gold are.
SLATE_TEXT = "#4E5D66"
# The text-safe register of the four stage accents.
STAGE_TEXT = ["#0E7A6A", "#2B6C97", "#B45434", "#916917"]

# How many stages the journey band draws, filled positionally.
#
# Five, not four. Four was enough while the feed's longest journey was REM1 ->
# REM4, and it was still enough for a day0 -> REM1 -> REM2 -> REM3 program. But
# the unfiltered page shows every stage in the extract at once, and the moment
# one program opens with day0 while another runs through REM4 that union is
# five stages - so the default view of page 1, the first thing anyone sees,
# was dropping REM4 off the end of the band.
#
# A journey longer than this still says so on the path line rather than
# dropping the extras without a word.
JOURNEY_SLOTS = 5
ORDINAL = {1: "first", 2: "second", 3: "third", 4: "fourth", 5: "fifth"}

# How many members a ranking visual draws. Production is 100+ clients;
# a bar chart over all of them is a scrollbar, not a chart.
TOP_N = 10

# The shortlist the two contribution charts on page 1 draw. Smaller than
# TOP_N because those two live in a 174px band: ten horizontal bars in it are
# 11px each, and Power BI puts the remainder behind a scrollbar.
SHORTLIST = 5

F = "Fact_ReminderVolume"


def M(name, dax, fmt=None, desc=None, folder=None, hidden=False):
    return dict(name=name, dax=dax.strip("\n"), fmt=fmt, desc=desc,
                folder=folder, hidden=hidden)


def measures():
    out = []
    a = out.append

    # ======================================================================
    f = "01 Core Volume"
    # ======================================================================
    a(M("Email Volume", '''
CALCULATE (
    SUM ( 'Fact_ReminderVolume'[Number of Email] ),
    'Fact_ReminderVolume'[t_c_ind] = "T"
)
''', FMT_INT, "The primary email metric for the whole report. Test (T) records "
     "only, because Control does not receive the reminder email.\n"
     "Selecting Control in the population slicer intersects with the T filter "
     "and returns blank - that is correct, not a bug.", f))

    a(M("Email Volume (All Populations)", '''
SUM ( 'Fact_ReminderVolume'[Number of Email] )
''', FMT_INT, "Raw sum across Test and Control. Reconciliation and data-quality "
     "use only - never label this as email sent.", f, hidden=False))

    a(M("Control Volume Column Sum", '''
CALCULATE (
    SUM ( 'Fact_ReminderVolume'[Number of Email] ),
    'Fact_ReminderVolume'[t_c_ind] = "C"
)
''', FMT_INT, "Whatever sits in the volume column on Control rows. Control "
     "receives no email, so this is a population figure, never a send count.",
     f))

    a(M("Email Volume YTD", '''
TOTALYTD ( [Email Volume], 'Dim_Date'[Date] )
''', FMT_INT, "Test email volume year to date over the selected context.", f))

    # ======================================================================
    f = "02 Population"
    # ======================================================================
    a(M("Total Population", '''
COUNTROWS ( 'Fact_ReminderVolume' )
''', FMT_INT, "Source records in context. The extract carries no headcount "
     "column, so 'population' here counts records, not people.", f))

    a(M("Test Population", '''
CALCULATE (
    COUNTROWS ( 'Fact_ReminderVolume' ),
    'Fact_ReminderVolume'[t_c_ind] = "T"
)
''', FMT_INT, "Test records in context. Counts rows, not individuals: the "
     "source has no distinct population identifier to count instead.", f))

    a(M("Control Population", '''
CALCULATE (
    COUNTROWS ( 'Fact_ReminderVolume' ),
    'Fact_ReminderVolume'[t_c_ind] = "C"
)
''', FMT_INT, "Control records in context - the eligible population that was "
     "deliberately not mailed.", f))

    a(M("Test Share of Records", '''
DIVIDE ( [Test Population], [Total Population] )
''', FMT_PCT, "Test records as a share of all records in context.", f))

    a(M("Control Share of Records", '''
DIVIDE ( [Control Population], [Total Population] )
''', FMT_PCT, "Control records as a share of all records in context.", f))

    a(M("Population Split Label", '''
VAR _t = [Test Population] + 0
VAR _c = [Control Population] + 0
RETURN
    IF (
        ( _t + _c ) = 0,
        "No records in the current selection",
        FORMAT ( _t, "#,##0" ) & " Test  /  " & FORMAT ( _c, "#,##0" ) & " Control"
    )
''', None, "Caption for the population panel.", f))

    a(M("Control Presence Note", '''
VAR _c = [Control Population]
RETURN
    IF (
        _c = 0,
        "No Control records in this selection - every record is a Test (mailed) record.",
        FORMAT ( _c, "#,##0" ) & " Control records - eligible population, no email sent."
    )
''', None, "States plainly whether a control population exists at all.", f))

    # ======================================================================
    f = "03 Reminder Stages"
    # ======================================================================
    for n in range(1, 5):
        a(M("REM%d Volume" % n, '''
CALCULATE (
    [Email Volume],
    KEEPFILTERS ( 'Dim_Reminder'[Reminder Order] = %d )
)
''' % n, FMT_INT,
          "Test email volume for reminder stage %d.\n"
          "Filters on Reminder Order rather than the literal text \"REM%d\", so "
          "a renamed flag still resolves. KEEPFILTERS means an explicit reminder "
          "slicer selection is respected rather than overridden - excluding "
          "stage %d from the slicer correctly blanks this measure." % (n, n, n),
          f))

    for n in range(1, 5):
        a(M("REM%d %%" % n, '''
DIVIDE ( [REM%d Volume], [Email Volume] )
''' % n, FMT_PCT, "Stage %d share of the Test email volume in context. "
          "DIVIDE returns blank rather than an error when the denominator is "
          "zero." % n, f))

    a(M("Reminder Stage Volume", '''
[Email Volume]
''', FMT_INT, "Alias used where a visual is already sliced by Dim_Reminder, so "
     "the stage in play comes from row context instead of a fixed stage number.",
     f))

    a(M("Reminder Stage Share", '''
DIVIDE (
    [Email Volume],
    CALCULATE ( [Email Volume], REMOVEFILTERS ( 'Dim_Reminder' ) )
)
''', FMT_PCT, "This stage's share of all stages in the same context.", f))

    a(M("% of Selected Volume", '''
DIVIDE (
    [Email Volume],
    CALCULATE ( [Email Volume], ALLSELECTED () )
)
''', FMT_PCT, "Share of the visual's own total, holding every slicer in place. "
     "Used for the matrix '% of Total' column.", f))

    # ======================================================================
    f = "04 Reminder Journey"
    # ======================================================================
    # ------------------------------------------------------------------
    # The journey band, slot by slot.
    #
    # These used to be keyed on the stage number: slot 1 drew Reminder Order 1,
    # slot 2 drew order 2, and so on. That works for exactly one shape of feed -
    # one whose rem_flag values start at 1 - and it fails silently for every
    # other one, which is the worst way to fail.
    #
    # A program whose journey is day0 -> REM1 -> REM2 -> REM3 is the case that
    # broke it. 'day0' carries the digit 0, so Dim_Reminder gives it Reminder
    # Order 0 and sorts it first, correctly. But no slot filtered on order 0,
    # so the band drew three stages and an empty fourth, while the path line
    # above it read DAY0 -> REM1 -> REM2 -> REM3 and the tile beside it said
    # four stages. The first send in the journey - usually the largest - was
    # simply not on the band, and nothing said so.
    #
    # The slots are positional now. Slot 1 draws whichever stage comes first in
    # this journey, slot 2 the second, and so on, whatever their numbers are.
    # That handles day0, a feed that starts at REM2, a REM5 that appears later,
    # and a journey with a gap in the middle - none of which the old form could
    # draw without leaving a hole.
    #
    # Colour still comes from the stage, not from the slot, so a stage keeps one
    # identity across every page: REM2 is steel whether it sits in slot 2 of a
    # REM1-REM4 journey or slot 3 of a day0 journey.
    # ------------------------------------------------------------------
    for n in range(1, JOURNEY_SLOTS + 1):
        a(M("Slot %d Order" % n, """
-- The stage sitting in slot %d: the %s smallest Reminder Order among the stages
-- this journey actually has.
--
-- The date filter is removed on purpose. Which stages a journey has is a
-- property of the journey, not of the window being looked at - that is what
-- lets the band tell 'this journey has no fourth stage' apart from 'the fourth
-- stage sent nothing this month', and the two say very different things.
--
-- Blank when the journey has fewer than %d stages, and every measure built on
-- it then collapses to an empty string, so the slot and its connector
-- disappear rather than printing a hole.
VAR _stages =
    CALCULATETABLE (
        SUMMARIZE ( 'Fact_ReminderVolume', 'Dim_Reminder'[Reminder Order] ),
        REMOVEFILTERS ( 'Dim_Date' ),
        'Fact_ReminderVolume'[t_c_ind] = "T"
    )
VAR _count = COUNTROWS ( _stages )
RETURN
    IF (
        _count >= %d,
        MAXX (
            TOPN ( %d, _stages, 'Dim_Reminder'[Reminder Order], ASC ),
            'Dim_Reminder'[Reminder Order]
        )
    )
""" % (n, ORDINAL[n], n, n, n), "0",
            "Reminder Order of the stage drawn in journey slot %d, or blank if "
            "this journey has fewer than %d stages. Positional, not numbered: "
            "slot 1 is the first stage of the journey whatever it is called, "
            "which is what lets a day-0 send occupy it." % (n, n), f,
            hidden=True))

    for n in range(1, JOURNEY_SLOTS + 1):
        a(M("Slot %d Volume" % n, """
VAR _o = [Slot %d Order]
RETURN
    IF (
        NOT ISBLANK ( _o ),
        CALCULATE (
            [Email Volume],
            KEEPFILTERS ( 'Dim_Reminder'[Reminder Order] = _o )
        )
    )
""" % n, FMT_INT,
            "Test email volume for whichever stage is in journey slot %d. "
            "KEEPFILTERS, so an explicit reminder slicer selection is respected "
            "rather than overridden." % n, f, hidden=True))

    for n in range(1, JOURNEY_SLOTS + 1):
        a(M("Slot %d Share" % n, """
DIVIDE ( [Slot %d Volume], [Email Volume] )
""" % n, FMT_PCT, "Slot %d share of the Test email volume in context." % n, f,
            hidden=True))

    # A card bound to a measure that returns BLANK does not render nothing - it
    # renders the literal text (Blank). Every measure that feeds a journey card
    # therefore returns an empty string instead, which is what actually makes an
    # absent stage disappear.
    for n in range(1, JOURNEY_SLOTS + 1):
        a(M("Slot %d Stage Label" % n, """
VAR _o = [Slot %d Order]
RETURN
    IF (
        ISBLANK ( _o ),
        "",
        UPPER (
            CALCULATE (
                SELECTEDVALUE ( 'Dim_Reminder'[Reminder Display Name] ),
                REMOVEFILTERS ( 'Dim_Reminder' ),
                'Dim_Reminder'[Reminder Order] = _o
            )
        )
    )
""" % n, None,
            "Heading for journey slot %d, taken from the data's own display "
            "name - so a day-0 send reads DAY 0 and a reminder reads REMINDER "
            "n. An empty string rather than BLANK, so the card collapses "
            "instead of printing the literal text (Blank)." % n, f))

    for n in range(1, JOURNEY_SLOTS + 1):
        a(M("Slot %d Journey Value" % n, """
VAR _o = [Slot %d Order]
VAR _vol = [Slot %d Volume]
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( _o ), "",
        ISBLANK ( _vol ), "0",
        FORMAT ( _vol, "#,##0" )
    )
""" % (n, n), None,
            "The number printed on journey slot %d, as text. A zero means the "
            "stage exists in this journey but sent nothing in the selected "
            "period; an empty string means the journey has no such stage and "
            "the card disappears. A numeric measure could not express that "
            "difference on a card, because BLANK renders as the literal text "
            "(Blank)." % n, f))

    for n in range(1, JOURNEY_SLOTS + 1):
        a(M("Slot %d Stage Caption" % n, """
VAR _o = [Slot %d Order]
VAR _vol = [Slot %d Volume]
VAR _pct = [Slot %d Share]
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( _o ), "",
        ISBLANK ( _vol ), "No volume in the selected period",
        FORMAT ( _pct, "0.0%%" ) & " of selected volume"
    )
""" % (n, n, n), None, "Share caption under journey slot %d." % n, f))

    for n in range(1, JOURNEY_SLOTS + 1):
        a(M("Slot %d Latest Day Volume" % n, """
VAR _o = [Slot %d Order]
RETURN
    IF (
        NOT ISBLANK ( _o ),
        CALCULATE (
            [Latest Day Volume],
            KEEPFILTERS ( 'Dim_Reminder'[Reminder Order] = _o )
        )
    )
""" % n, FMT_INT, "Slot %d volume on its own latest available day." % n, f,
            hidden=True))

    for n in range(1, JOURNEY_SLOTS + 1):
        a(M("Slot %d DoD %%" % n, """
VAR _o = [Slot %d Order]
RETURN
    IF (
        NOT ISBLANK ( _o ),
        CALCULATE (
            [Day-over-Day Change %%],
            KEEPFILTERS ( 'Dim_Reminder'[Reminder Order] = _o )
        )
    )
""" % n, FMT_PCT2,
            "Slot %d movement between its latest and previous available day."
            % n, f, hidden=True))

    for n in range(1, JOURNEY_SLOTS + 1):
        a(M("Slot %d Day Caption" % n, """
VAR _o = [Slot %d Order]
VAR _lat = [Slot %d Latest Day Volume]
VAR _dod = [Slot %d DoD %%]
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( _o ), "",
        ISBLANK ( _lat ), "Latest day: no data",
        "Latest day " & FORMAT ( _lat, "#,##0" )
            & IF (
                ISBLANK ( _dod ),
                "  ·  DoD n/a",
                "  ·  " & IF ( _dod >= 0, UNICHAR ( 9650 ), UNICHAR ( 9660 ) )
                    & " " & FORMAT ( _dod, "0.0%%" )
            )
    )
""" % (n, n, n), None,
            "Latest-day and day-over-day caption for journey slot %d." % n, f))

    for n in range(1, JOURNEY_SLOTS + 1):
        a(M("Slot %d Label Colour" % n, """
-- Keyed on the stage, not on the slot, so a stage keeps one identity wherever
-- it lands: REM2 is steel in slot 2 of a REM1-REM4 journey and steel in slot 3
-- of a day0 journey. Order 0 - a day-0 send, which is not a reminder - takes
-- the neutral slate, which also catches any flag whose number the model could
-- not read.
--
-- These are the text-safe registers of the four stage accents. Clay and gold
-- at full saturation fail WCAG AA as small text on this paper; the darkened
-- twins are the same colour to look at and legible to read.
VAR _o = [Slot %d Order]
RETURN
    SWITCH ( _o, 0, "%s", 1, "%s", 2, "%s", 3, "%s", 4, "%s", "%s" )
""" % (n, SLATE_TEXT, STAGE_TEXT[0], STAGE_TEXT[1], STAGE_TEXT[2],
       STAGE_TEXT[3], SLATE_TEXT), None,
            "Text colour for journey slot %d, taken from the stage it is "
            "currently showing." % n, f, hidden=True))

    for n in range(1, JOURNEY_SLOTS):
        a(M("Slot %d Arrow" % n, """
IF (
    NOT ISBLANK ( [Slot %d Order] ) && NOT ISBLANK ( [Slot %d Order] ),
    UNICHAR ( 8594 ),
    ""
)
""" % (n, n + 1), None,
            "Connector drawn between journey slots %d and %d. Blank - and so "
            "invisible - unless both slots are filled, which is what stops the "
            "page showing an arrow into an empty slot." % (n, n + 1), f))

    a(M("Journey Slot Count", "%d" % JOURNEY_SLOTS, "0",
        "How many stages the journey band can draw. Read by [Journey Path "
        "Label] so the path line can say when a journey is longer than the "
        "band.", f, hidden=True))

    a(M("Journey Stage Count", '''
CALCULATE (
    DISTINCTCOUNT ( 'Fact_ReminderVolume'[rem_flag] ),
    'Fact_ReminderVolume'[t_c_ind] = "T",
    REMOVEFILTERS ( 'Dim_Date' )
)
''', "0", "How many reminder stages exist for this journey, irrespective of the "
     "selected date window.", f))

    a(M("Active Reminder Stages", '''
CALCULATE (
    DISTINCTCOUNT ( 'Fact_ReminderVolume'[rem_flag] ),
    'Fact_ReminderVolume'[t_c_ind] = "T"
)
''', "0", "Reminder stages with Test volume inside the selected period.", f))

    a(M("Journey Path Label", '''
VAR _stages =
    CALCULATETABLE (
        SUMMARIZE (
            'Fact_ReminderVolume',
            'Dim_Reminder'[Reminder Order],
            'Dim_Reminder'[Reminder Short Name]
        ),
        REMOVEFILTERS ( 'Dim_Date' ),
        'Fact_ReminderVolume'[t_c_ind] = "T"
    )
VAR _count = COUNTROWS ( _stages )
VAR _slots = [Journey Slot Count]
RETURN
    IF (
        ISEMPTY ( _stages ),
        "No reminder stages in this selection",
        CONCATENATEX (
            _stages,
            'Dim_Reminder'[Reminder Short Name],
            "  " & UNICHAR ( 8594 ) & "  ",
            'Dim_Reminder'[Reminder Order], ASC
        )
            -- The band has a fixed number of slots. When a journey is longer
            -- than that, this line says so: the whole journey is named here
            -- even when the cards below cannot all be drawn, so nothing is
            -- dropped without a word.
            & IF (
                _count > _slots,
                "   (first " & FORMAT ( _slots, "0" ) & " shown below)",
                ""
            )
    )
''', None, "The journey written out - \"REM1 -> REM2 -> REM3\" - built from the "
     "stages actually present, in stage order.", f))

    a(M("Stage Volume Movement", '''
VAR _ord = SELECTEDVALUE ( 'Dim_Reminder'[Reminder Order] )
VAR _present =
    CALCULATETABLE (
        SUMMARIZE ( 'Fact_ReminderVolume', 'Dim_Reminder'[Reminder Order] ),
        REMOVEFILTERS ( 'Dim_Reminder' )
    )
VAR _priorOrd =
    MAXX (
        FILTER ( _present, 'Dim_Reminder'[Reminder Order] < _ord ),
        'Dim_Reminder'[Reminder Order]
    )
VAR _prior =
    CALCULATE (
        [Email Volume],
        REMOVEFILTERS ( 'Dim_Reminder' ),
        'Dim_Reminder'[Reminder Order] = _priorOrd
    )
VAR _cur = [Email Volume]
RETURN
    IF ( NOT ISBLANK ( _priorOrd ) && NOT ISBLANK ( _cur ), _cur - _prior )
''', FMT_SIGNED,
     "Volume difference against the previous stage that actually exists in this "
     "journey, so a gap in the stage sequence does not produce a false step.\n"
     "Deliberately called movement, not conversion: the source defines no "
     "conversion between reminder stages.", f))

    a(M("Stage Volume Movement %", '''
VAR _ord = SELECTEDVALUE ( 'Dim_Reminder'[Reminder Order] )
VAR _present =
    CALCULATETABLE (
        SUMMARIZE ( 'Fact_ReminderVolume', 'Dim_Reminder'[Reminder Order] ),
        REMOVEFILTERS ( 'Dim_Reminder' )
    )
VAR _priorOrd =
    MAXX (
        FILTER ( _present, 'Dim_Reminder'[Reminder Order] < _ord ),
        'Dim_Reminder'[Reminder Order]
    )
VAR _prior =
    CALCULATE (
        [Email Volume],
        REMOVEFILTERS ( 'Dim_Reminder' ),
        'Dim_Reminder'[Reminder Order] = _priorOrd
    )
RETURN
    IF ( NOT ISBLANK ( _priorOrd ), DIVIDE ( [Email Volume] - _prior, _prior ) )
''', FMT_PCT2, "Stage-to-stage volume movement as a percentage of the previous "
     "stage.", f))

    a(M("Stage Movement Colour", '''
VAR _m = [Stage Volume Movement]
RETURN
    SWITCH ( TRUE (), ISBLANK ( _m ), "%s", _m > 0, "%s", _m < 0, "%s", "%s" )
''' % (TEXT_MID, GREEN, AMBER, TEXT_MID), None,
     "Amber, not red, for a fall: a smaller later stage is the normal shape of a "
     "reminder sequence, not a failure.", f, hidden=True))

    # ======================================================================
    f = "05 Daily & Movement"
    # ======================================================================
    a(M("Latest Available Date", '''
CALCULATE (
    MAX ( 'Fact_ReminderVolume'[file_date] ),
    'Fact_ReminderVolume'[t_c_ind] = "T"
)
''', FMT_DATE, "Latest date carrying Test data inside the current filter "
     "context. Honours the date slicer rather than always jumping to the "
     "dataset maximum.", f))

    a(M("Previous Available Date", '''
VAR _latest = [Latest Available Date]
RETURN
    IF (
        NOT ISBLANK ( _latest ),
        CALCULATE (
            MAX ( 'Fact_ReminderVolume'[file_date] ),
            'Fact_ReminderVolume'[t_c_ind] = "T",
            'Fact_ReminderVolume'[file_date] < _latest
        )
    )
''', FMT_DATE, "The previous date that actually holds data, not the latest date "
     "minus one. With days 10, 11 and 13 loaded, the previous day for the 13th "
     "is the 11th.", f))

    a(M("Latest Day Volume", '''
VAR _d = [Latest Available Date]
RETURN
    IF (
        NOT ISBLANK ( _d ),
        CALCULATE ( [Email Volume], 'Fact_ReminderVolume'[file_date] = _d )
    )
''', FMT_INT, "Test email volume on the latest available day in context.", f))

    a(M("Previous Day Volume", '''
VAR _d = [Previous Available Date]
RETURN
    IF (
        NOT ISBLANK ( _d ),
        CALCULATE ( [Email Volume], 'Fact_ReminderVolume'[file_date] = _d )
    )
''', FMT_INT, "Test email volume on the previous available day in context.", f))

    a(M("Day-over-Day Change", '''
VAR _c = [Latest Day Volume]
VAR _p = [Previous Day Volume]
RETURN
    IF ( NOT ISBLANK ( _c ) && NOT ISBLANK ( _p ), _c - _p )
''', FMT_SIGNED, "Latest available day minus previous available day.", f))

    a(M("Day-over-Day Change %", '''
DIVIDE ( [Day-over-Day Change], [Previous Day Volume] )
''', FMT_PCT2, "Day-over-day movement as a percentage of the previous available "
     "day.", f))

    a(M("Day-over-Day Label", '''
VAR _prev = [Previous Available Date]
VAR _pct = [Day-over-Day Change %]
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( [Latest Day Volume] ), "N/A - no data in the current selection",
        ISBLANK ( _prev ) || ISBLANK ( _pct ),
            "N/A - no previous day with data in range",
        IF ( _pct >= 0, UNICHAR ( 9650 ) & " ", UNICHAR ( 9660 ) & " " )
            & FORMAT ( _pct, "+0.0%;-0.0%;0.0%" )
            & " vs " & FORMAT ( _prev, "dd-MMM-yyyy" )
    )
''', None, "The movement caption under the latest-day KPI. States N/A "
     "explicitly rather than showing a misleading 0%.", f))

    a(M("Day-over-Day Colour", '''
VAR _p = [Day-over-Day Change %%]
RETURN
    SWITCH ( TRUE (), ISBLANK ( _p ), "%s", _p > 0, "%s", _p < 0, "%s", "%s" )
''' % (TEXT_MID, GREEN, AMBER, TEXT_MID), None,
     "Movement colour. A drop is amber rather than red - lower volume is not "
     "inherently bad, it just deserves a look.", f, hidden=True))

    a(M("Active Days", '''
CALCULATE (
    DISTINCTCOUNT ( 'Fact_ReminderVolume'[file_date] ),
    'Fact_ReminderVolume'[t_c_ind] = "T"
)
''', FMT_INT, "Days that actually carry Test data in context. The feed is not "
     "daily-complete, so this is the correct denominator for a daily average.",
     f))

    a(M("Active Days Caption", '''
-- Power BI renders a card caption bound to a numeric measure as the field's
-- name rather than its value, so every dynamic caption in this report returns
-- text.
VAR _d = [Active Days]
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( _d ) || _d = 0, "No days with data in this selection",
        _d = 1, "1 day with data",
        FORMAT ( _d, "#,##0" ) & " days with data"
    )
''', None, "Caption form of Active Days, for use under a KPI value.", f))

    a(M("Average Daily Volume", '''
DIVIDE ( [Email Volume], [Active Days] )
''', '"#,##0.0"', "Test email volume per day with data. Missing days are not "
     "counted as zero-volume days.", f))

    a(M("Peak Daily Volume", '''
MAXX ( VALUES ( 'Dim_Date'[Date] ), [Email Volume] )
''', FMT_INT, "Highest single-day Test volume in context.", f))

    a(M("Minimum Daily Volume", '''
MINX (
    FILTER ( VALUES ( 'Dim_Date'[Date] ), NOT ISBLANK ( [Email Volume] ) ),
    [Email Volume]
)
''', FMT_INT, "Lowest single-day Test volume among days that have data. Days "
     "with no data are excluded rather than treated as zero.", f))

    a(M("Peak Volume Date", '''
VAR _t = ADDCOLUMNS ( VALUES ( 'Dim_Date'[Date] ), "@v", [Email Volume] )
VAR _mx = MAXX ( _t, [@v] )
RETURN
    IF ( NOT ISBLANK ( _mx ), MAXX ( FILTER ( _t, [@v] = _mx ), 'Dim_Date'[Date] ) )
''', FMT_DATE, "The date the peak daily volume fell on.", f))

    a(M("Report Latest Date", '''
CALCULATE (
    MAX ( 'Fact_ReminderVolume'[file_date] ),
    'Fact_ReminderVolume'[t_c_ind] = "T",
    ALLSELECTED ()
)
''', FMT_DATE, "Latest available day across the whole selection, ignoring the "
     "row a visual is on. Lets every row of a matrix report the same day.", f))

    a(M("Volume on Report Latest Day", '''
VAR _d = [Report Latest Date]
RETURN
    IF (
        NOT ISBLANK ( _d ),
        CALCULATE ( [Email Volume], 'Fact_ReminderVolume'[file_date] = _d )
    )
''', FMT_INT, "Volume on the report-wide latest day, so matrix rows compare on "
     "one common date.", f))

    # ======================================================================
    f = "06 Counts"
    # ======================================================================
    a(M("Client Count", '''
DISTINCTCOUNT ( 'Fact_ReminderVolume'[Client_name] )
''', "0", "Distinct clients in context.", f))

    a(M("Program Count", '''
DISTINCTCOUNT ( 'Fact_ReminderVolume'[Program] )
''', "0", "Distinct programs in context.", f))

    a(M("Reminder Count", '''
DISTINCTCOUNT ( 'Fact_ReminderVolume'[rem_flag] )
''', "0", "Distinct reminder stages in context.", f))

    a(M("Creative Count", '''
DISTINCTCOUNT ( 'Fact_ReminderVolume'[comm_code] )
''', "0", "Distinct communication / creative codes in context.", f))

    a(M("Site Count", '''
DISTINCTCOUNT ( 'Fact_ReminderVolume'[site_code] )
''', "0", "Distinct site codes in context.", f))

    a(M("Client Group Count", '''
DISTINCTCOUNT ( 'Fact_ReminderVolume'[client_group] )
''', "0", "Distinct client groups in context.", f))

    # ======================================================================
    f = "07 Anomaly Watch"
    # ======================================================================
    a(M("Volume Baseline", '''
-- Mean of the 14 most recent days WITH DATA before the day being evaluated.
-- Trailing days are used rather than a centred window so the status of a day
-- never changes when later days arrive.
VAR _d = MAX ( 'Dim_Date'[Date] )
VAR _days =
    TOPN (
        14,
        CALCULATETABLE (
            VALUES ( 'Fact_ReminderVolume'[file_date] ),
            REMOVEFILTERS ( 'Dim_Date' ),
            'Fact_ReminderVolume'[file_date] < _d,
            'Fact_ReminderVolume'[t_c_ind] = "T"
        ),
        'Fact_ReminderVolume'[file_date], DESC
    )
VAR _vals =
    ADDCOLUMNS (
        _days,
        "@v", CALCULATE ( [Email Volume], REMOVEFILTERS ( 'Dim_Date' ) )
    )
RETURN
    -- A day with no send of its own has no baseline, because it is not a day
    -- the report has anything to say about. Without this guard the calendar
    -- runs past the end of the data and the operations log fills with dated
    -- rows carrying a baseline, no volume and no status - which reads as
    -- missing data rather than as no send.
    IF (
        NOT ISBLANK ( [Email Volume] ) && COUNTROWS ( _days ) >= 5,
        AVERAGEX ( _vals, [@v] )
    )
''', '"#,##0.0"', "Trailing 14-available-day mean volume. Blank on a day with "
     "no send of its own, and until at least 5 prior days exist, so early days "
     "are not judged against noise.", f))

    a(M("Volume Baseline SD", '''
VAR _d = MAX ( 'Dim_Date'[Date] )
VAR _days =
    TOPN (
        14,
        CALCULATETABLE (
            VALUES ( 'Fact_ReminderVolume'[file_date] ),
            REMOVEFILTERS ( 'Dim_Date' ),
            'Fact_ReminderVolume'[file_date] < _d,
            'Fact_ReminderVolume'[t_c_ind] = "T"
        ),
        'Fact_ReminderVolume'[file_date], DESC
    )
VAR _vals =
    ADDCOLUMNS (
        _days,
        "@v", CALCULATE ( [Email Volume], REMOVEFILTERS ( 'Dim_Date' ) )
    )
RETURN
    IF ( COUNTROWS ( _days ) >= 5, STDEVX.P ( _vals, [@v] ) )
''', '"#,##0.0"', "Population standard deviation over the same trailing window.",
     f))

    a(M("Volume Status", '''
-- Transparent, explainable rule: a day is High or Low when it sits more than
-- two trailing standard deviations from the trailing mean. No model, no
-- training, and the thresholds are readable on the page.
VAR _v = [Email Volume]
VAR _m = [Volume Baseline]
VAR _s = [Volume Baseline SD]
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( _v ), BLANK (),
        ISBLANK ( _m ) || ISBLANK ( _s ), "Baseline forming",
        _s = 0 && _v = _m, "Normal",
        _s = 0, IF ( _v > _m, "High", "Low" ),
        _v > _m + 2 * _s, "High",
        _v < _m - 2 * _s, "Low",
        "Normal"
    )
''', None, "Normal / High / Low against a trailing 14-day mean +/- 2 standard "
     "deviations. Documented in Dashboard_Design.md.", f))

    a(M("Reminder Stage Colour", '''
-- One colour per stage, keyed on stage order so REM2 is the same colour on
-- every page and in every visual (spec section 55). Driving this from a measure
-- rather than per-category data point rules is what keeps it consistent when a
-- journey contains only some of the stages.
SWITCH (
    SELECTEDVALUE ( 'Dim_Reminder'[Reminder Order] ),
    1, "%s",
    2, "%s",
    3, "%s",
    4, "%s",
    "%s"
)
''' % (STAGE_COLOURS[0], STAGE_COLOURS[1], STAGE_COLOURS[2], STAGE_COLOURS[3],
       SLATE), None,
     "Stage identity colour, applied to journey cards, bars and matrix rows.",
     "04 Reminder Journey", hidden=True))

    a(M("Heat Colour", '''
-- Five-step ramp against the largest cell the visual is showing. The cell also
-- prints its value, so colour is reinforcement rather than the only signal
-- (spec section 42).
VAR _v = [Email Volume]
VAR _cells =
    CALCULATETABLE (
        SUMMARIZE (
            'Fact_ReminderVolume',
            'Dim_Client'[Client_name],
            'Dim_Date'[Year-Week]
        ),
        ALLSELECTED ()
    )
VAR _max = MAXX ( _cells, [Email Volume] )
VAR _r = DIVIDE ( _v, _max )
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( _v ), "#F7F4ED",
        _r >= 0.75, "#0E7A6A",
        _r >= 0.50, "#4E9A8B",
        _r >= 0.25, "#93BFB5",
        "#D3E3DD"
    )
''', None, "Background colour for the daily heatmap cells.", "07 Anomaly Watch",
     hidden=True))

    a(M("Heat Text Colour", '''
-- The ramp runs light-to-dark on a paper canvas, so the value printed in the
-- cell has to invert with it: ink on the two pale steps, paper on the two
-- saturated ones. Without this the top of the ramp prints dark ink on dark
-- teal and the busiest cells - the ones worth reading - become the unreadable
-- ones.
VAR _v = [Email Volume]
VAR _cells =
    CALCULATETABLE (
        SUMMARIZE (
            'Fact_ReminderVolume',
            'Dim_Client'[Client_name],
            'Dim_Date'[Year-Week]
        ),
        ALLSELECTED ()
    )
VAR _max = MAXX ( _cells, [Email Volume] )
VAR _r = DIVIDE ( _v, _max )
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( _v ), "%s",
        _r >= 0.50, "#FFFFFF",
        "%s"
    )
''' % (TEXT_MID, TEXT_HI), None,
     "Font colour for the daily heatmap cells, inverted against Heat Colour.",
     "07 Anomaly Watch", hidden=True))

    a(M("Volume Status Colour", '''
SWITCH (
    [Volume Status],
    "High", "%s",
    "Low", "%s",
    "Normal", "%s",
    "%s"
)
''' % (BLUE, AMBER, TEXT_MID, TEXT_MID), None, "Colour for the status column.",
     f, hidden=True))

    a(M("Volume vs Baseline", '''
-- Guarded on the day having volume at all, not just on the baseline existing.
-- The calendar runs to the end of the loaded month, so without this a date with
-- no send still had a baseline behind it and reported "-100%", which put rows
-- for days that never happened at the top of the operational table.
VAR _v = [Email Volume]
VAR _m = [Volume Baseline]
RETURN
    IF ( NOT ISBLANK ( _v ) && NOT ISBLANK ( _m ), DIVIDE ( _v - _m, _m ) )
''', FMT_PCT2, "How far the day sits from its trailing baseline. Blank on a "
     "date with no send, so empty calendar days never reach a table.", f))

    a(M("Exception Day Count", '''
COUNTROWS (
    FILTER (
        VALUES ( 'Dim_Date'[Date] ),
        NOT ISBLANK ( [Email Volume] )
            && ( [Volume Status] = "High" || [Volume Status] = "Low" )
    )
)
''', "0", "Days flagged High or Low in the selected period.", f))

    a(M("Exception Summary", '''
VAR _n = [Exception Day Count]
VAR _d = [Active Days]
RETURN
    SWITCH (
        TRUE (),
        _d = 0, "No days with data in the current selection.",
        ISBLANK ( _n ) || _n = 0,
            "No days outside +/-2 SD across " & FORMAT ( _d, "#,##0" ) & " days",
        FORMAT ( _n, "#,##0" ) & " of " & FORMAT ( _d, "#,##0" ) & " days outside +/-2 SD"
    )
''', None, "Plain-language summary for the Operational Watch panel.", f))

    # ======================================================================
    f = "08 Insights"
    # ======================================================================
    a(M("Top Client", '''
VAR _t = ADDCOLUMNS ( VALUES ( 'Dim_Client'[Client_name] ), "@v", [Email Volume] )
VAR _mx = MAXX ( _t, [@v] )
RETURN
    IF (
        NOT ISBLANK ( _mx ),
        CONCATENATEX ( FILTER ( _t, [@v] = _mx ), 'Dim_Client'[Client_name], ", " ),
        ""
    )
''', None, "Client with the highest Test email volume in context.", f))

    a(M("Top Client Volume", '''
MAXX ( VALUES ( 'Dim_Client'[Client_name] ), [Email Volume] )
''', FMT_INT, "Volume of the highest-volume client.", f))

    a(M("Top Program", '''
VAR _t = ADDCOLUMNS ( VALUES ( 'Dim_Program'[Program] ), "@v", [Email Volume] )
VAR _mx = MAXX ( _t, [@v] )
RETURN
    IF (
        NOT ISBLANK ( _mx ),
        CONCATENATEX ( FILTER ( _t, [@v] = _mx ), 'Dim_Program'[Program], ", " ),
        ""
    )
''', None, "Program with the highest Test email volume in context.", f))

    a(M("Top Creative", '''
VAR _t = ADDCOLUMNS ( VALUES ( 'Dim_CommCode'[comm_code] ), "@v", [Email Volume] )
VAR _mx = MAXX ( _t, [@v] )
RETURN
    IF (
        NOT ISBLANK ( _mx ),
        CONCATENATEX ( FILTER ( _t, [@v] = _mx ), 'Dim_CommCode'[comm_code], ", " ),
        ""
    )
''', None, "Communication code carrying the most volume in context.", f))

    a(M("Largest Reminder Stage", '''
VAR _t =
    ADDCOLUMNS (
        VALUES ( 'Dim_Reminder'[Reminder Short Name] ), "@v", [Email Volume] )
VAR _mx = MAXX ( _t, [@v] )
RETURN
    IF (
        NOT ISBLANK ( _mx ),
        CONCATENATEX (
            FILTER ( _t, [@v] = _mx ), 'Dim_Reminder'[Reminder Short Name], ", " ),
        ""
    )
''', None, "Reminder stage carrying the most volume in context.", f))

    a(M("Insight Reminder Mix", '''
VAR _stage = [Largest Reminder Stage]
VAR _share =
    DIVIDE (
        MAXX ( VALUES ( 'Dim_Reminder'[Reminder Short Name] ), [Email Volume] ),
        CALCULATE ( [Email Volume], REMOVEFILTERS ( 'Dim_Reminder' ) )
    )
RETURN
    IF (
        NOT ISBLANK ( _stage ),
        _stage & " represents " & FORMAT ( _share, "0.0%" ) & " of selected email volume.",
        ""
    )
''', None, "Dynamic insight sentence about the reminder mix.", f))

    a(M("Insight Top Program", '''
VAR _p = [Top Program]
VAR _share =
    DIVIDE (
        MAXX ( VALUES ( 'Dim_Program'[Program] ), [Email Volume] ),
        CALCULATE ( [Email Volume], REMOVEFILTERS ( 'Dim_Program' ) )
    )
RETURN
    IF (
        NOT ISBLANK ( _p ),
        _p & " contributes " & FORMAT ( _share, "0.0%" ) & " of selected email volume.",
        ""
    )
''', None, "Dynamic insight sentence about program contribution.", f))

    a(M("Insight Top Client", '''
VAR _c = [Top Client]
VAR _share =
    DIVIDE (
        MAXX ( VALUES ( 'Dim_Client'[Client_name] ), [Email Volume] ),
        CALCULATE ( [Email Volume], REMOVEFILTERS ( 'Dim_Client' ) )
    )
RETURN
    IF (
        NOT ISBLANK ( _c ),
        _c & " has the highest selected-period volume at " & FORMAT ( _share, "0.0%" ) & " of the total.",
        ""
    )
''', None, "Dynamic insight sentence about the leading client.", f))

    a(M("Insight Top Creative", '''
VAR _c = [Top Creative]
VAR _share =
    DIVIDE (
        MAXX ( VALUES ( 'Dim_CommCode'[comm_code] ), [Email Volume] ),
        CALCULATE ( [Email Volume], REMOVEFILTERS ( 'Dim_CommCode' ) )
    )
RETURN
    IF (
        NOT ISBLANK ( _c ),
        "Creative " & _c & " drives " & FORMAT ( _share, "0.0%" ) & " of selected email volume.",
        ""
    )
''', None, "Dynamic insight sentence about creative contribution.", f))

    a(M("Insight Latest Movement", '''
VAR _pct = [Day-over-Day Change %]
VAR _d = [Latest Available Date]
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( _d ), "No data in the current selection.",
        ISBLANK ( _pct ),
            "Latest day is " & FORMAT ( _d, "dd-MMM-yyyy" )
                & "; no previous day with data in range to compare against.",
        "Volume " & IF ( _pct >= 0, "increased ", "decreased " )
            & FORMAT ( ABS ( _pct ), "0.0%" ) & " on " & FORMAT ( _d, "dd-MMM-yyyy" )
            & " versus the previous available day."
    )
''', None, "Dynamic insight sentence about the latest movement.", f))

    a(M("Insight Peak Day", '''
VAR _d = [Peak Volume Date]
VAR _v = [Peak Daily Volume]
RETURN
    IF (
        NOT ISBLANK ( _d ),
        "Peak day was " & FORMAT ( _d, "dd-MMM-yyyy" )
            & " at " & FORMAT ( _v, "#,##0" ) & " emails.",
        ""
    )
''', None, "Dynamic insight sentence about the peak day.", f))

    # ======================================================================
    f = "09 Labels & Titles"
    # ======================================================================
    def sel_label(measure_name, table, column, plural, desc):
        return M(measure_name, '''
VAR _n = COUNTROWS ( VALUES ( '%s'[%s] ) )
VAR _all = COUNTROWS ( ALL ( '%s'[%s] ) )
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( _n ), "None selected",
        _n = _all, "All %s",
        _n = 1, SELECTEDVALUE ( '%s'[%s] ),
        FORMAT ( _n, "#,##0" ) & " %s"
    )
''' % (table, column, table, column, plural, table, column, plural),
                 None, desc, f)

    a(sel_label("Client Selection Label", "Dim_Client", "Client_name",
                "Clients", "Names the client selection for dynamic titles."))
    a(sel_label("Program Selection Label", "Dim_Program", "Program",
                "Programs", "Names the program selection for dynamic titles."))
    a(sel_label("Reminder Selection Label", "Dim_Reminder",
                "Reminder Short Name", "Reminders",
                "Names the reminder selection for dynamic titles."))
    a(sel_label("Creative Selection Label", "Dim_CommCode", "comm_code",
                "Creatives", "Names the creative selection for dynamic titles."))
    a(sel_label("Population Selection Label", "Dim_Population", "Population",
                "Populations", "Names the population selection."))

    a(M("Selected Period Label", '''
VAR _from = MIN ( 'Dim_Date'[Date] )
VAR _to = MAX ( 'Dim_Date'[Date] )
VAR _first = [Earliest Available Date]
VAR _last = [Latest Available Date]
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( _from ), "No dates selected",
        ISBLANK ( _last ), FORMAT ( _from, "dd-MMM-yyyy" ) & "  " & UNICHAR ( 8594 ) & "  "
            & FORMAT ( _to, "dd-MMM-yyyy" ) & "  (no data in range)",
        FORMAT ( _first, "dd-MMM-yyyy" ) & "  " & UNICHAR ( 8594 ) & "  "
            & FORMAT ( _last, "dd-MMM-yyyy" )
    )
''', None, "States the dates actually carrying data inside the selection, not "
     "just the slicer endpoints.", f))

    a(M("Earliest Available Date", '''
CALCULATE (
    MIN ( 'Fact_ReminderVolume'[file_date] ),
    'Fact_ReminderVolume'[t_c_ind] = "T"
)
''', FMT_DATE, "Earliest date with Test data in context.", f))

    a(M("Journey Title", '''
"Reminder Journey  " & UNICHAR ( 8212 ) & "  " & [Client Selection Label]
    & "  |  " & [Program Selection Label]
''', None, "Dynamic title for the journey visual.", f))

    a(M("Trend Title", '''
"Daily Email Volume  " & UNICHAR ( 8212 ) & "  " & [Client Selection Label]
''', None, "Dynamic title for the daily trend.", f))

    a(M("Creative Title", '''
"Creative Contribution  " & UNICHAR ( 8212 ) & "  " & [Client Selection Label]
    & "  |  " & [Program Selection Label]
''', None, "Dynamic title for the creative analysis.", f))

    a(M("Matrix Title", '''
"Client " & UNICHAR ( 8594 ) & " Program " & UNICHAR ( 8594 ) & " Reminder "
    & UNICHAR ( 8594 ) & " Creative  " & UNICHAR ( 8212 ) & "  "
    & [Client Selection Label]
''', None, "Dynamic title for the detail matrix.", f))

    a(M("Population Notice", '''
-- Fires when the user has filtered the population down to something that
-- excludes Test. Email measures are blank in that state by design, and a blank
-- page with no explanation reads as a broken report.
VAR _sel = CONCATENATEX ( VALUES ( 'Dim_Population'[t_c_ind] ), 'Dim_Population'[t_c_ind], "|" )
VAR _hasTest = CONTAINSSTRING ( _sel, "T" )
RETURN
    IF (
        NOT _hasTest,
        "CONTROL POPULATION  " & UNICHAR ( 8212 )
            & "  NO EMAILS SENT.  Email volume is blank because control records do not receive email.",
        ""
    )
''', None, "Banner text shown only when the selection excludes the Test "
     "population.", f))

    a(M("No Data Notice", '''
IF (
    ISBLANK ( [Email Volume] ) && [Population Notice] = "",
    "No data available for the selected filters.",
    ""
)
''', None, "Empty-state message. Suppressed when the population banner is "
     "already explaining the blank.", f))

    a(M("Volume Basis Note", '''
"Email Volume = Test (T) records only.  Control (C) is population, never a send."
''', None, "The standing reminder of the core business rule.", f))

    a(M("Journey Stage Summary", '''
VAR _n = [Journey Stage Count]
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( _n ) || _n = 0, "No reminder stages for this selection",
        _n = 1, "1 reminder stage in this journey",
        FORMAT ( _n, "#,##0" ) & " reminder stages in this journey"
    )
''', None, "Caption stating how many stages the current journey has.", f))

    # ======================================================================
    f = "10 Data Quality"
    # ======================================================================
    a(M("Total Rows", '''
COUNTROWS ( 'Fact_ReminderVolume' )
''', FMT_INT, "Rows in context.", f))

    a(M("Source Rows", '''
CALCULATE ( COUNTROWS ( 'Fact_ReminderVolume' ), REMOVEFILTERS () )
''', FMT_INT, "Rows loaded from the file, ignoring every filter. Reconciles "
     "directly against the CSV line count.", f))

    a(M("Test Rows", '''
[Test Population]
''', FMT_INT, "Rows with t_c_ind = T.", f))

    a(M("Control Rows", '''
[Control Population]
''', FMT_INT, "Rows with t_c_ind = C.", f))

    for label, col in [("Null Client Rows", "DQ Missing Client"),
                       ("Null Program Rows", "DQ Missing Program"),
                       ("Null Reminder Rows", "DQ Missing Reminder"),
                       ("Null Date Rows", "DQ Missing Date"),
                       ("Null Email Volume Rows", "DQ Missing Volume"),
                       ("Negative Email Values", "DQ Negative Volume"),
                       ("Unexpected T/C Values", "DQ Invalid Population"),
                       ("Unexpected Reminder Values", "DQ Invalid Reminder"),
                       ("Duplicate Rows", "DQ Duplicate Row")]:
        a(M(label, "SUM ( 'Fact_ReminderVolume'[%s] )" % col, FMT_INT,
            "Rows failing the %s check. Flagged in Power Query and kept in the "
            "model rather than dropped." % col.replace("DQ ", "").lower(), f))

    a(M("Rows Needing Review", '''
CALCULATE (
    COUNTROWS ( 'Fact_ReminderVolume' ),
    'Fact_ReminderVolume'[Row Status] = "Review"
)
''', FMT_INT, "Rows carrying at least one data-quality flag.", f))

    a(M("Data Quality Status", '''
VAR _n = [Rows Needing Review]
RETURN
    IF ( ISBLANK ( _n ) || _n = 0, "PASS", "REVIEW" )
''', None, "PASS when no row carries a flag.", f))

    a(M("Data Quality Status Colour", '''
IF ( [Data Quality Status] = "PASS", "%s", "%s" )
''' % (GREEN, AMBER), None, "Colour for the data quality banner.", f,
        hidden=True))

    a(M("Data Quality Summary", '''
VAR _n = [Rows Needing Review]
VAR _t = [Total Rows]
RETURN
    IF (
        ISBLANK ( _n ) || _n = 0,
        "All " & FORMAT ( _t, "#,##0" ) & " rows pass every validation check.",
        FORMAT ( _n, "#,##0" ) & " of " & FORMAT ( _t, "#,##0" )
            & " rows carry at least one data-quality flag."
    )
''', None, "Plain-language data quality summary.", f))

    a(M("Reconciliation Note", '''
"Email Volume (Test only) " & FORMAT ( [Email Volume], "#,##0" )
    & "   ·   All populations " & FORMAT ( [Email Volume (All Populations)], "#,##0" )
    & "   ·   Rows " & FORMAT ( [Total Rows], "#,##0" )
''', None, "One-line reconciliation strip for the Data Quality page.", f))

    # ======================================================================
    f = "11 Card Display"
    # ======================================================================
    # Power BI's card visual formats a number through a different path from a
    # table, a matrix or a chart data label: on this build 2,016 rendered as
    # "2.016" on a card while every table on the same page printed "1,674".
    # A card also prints the literal text "(Blank)" when its measure is BLANK,
    # which is exactly what a Control-only selection produces.
    #
    # Both problems disappear if the card is handed text instead of a number,
    # so every KPI value in the report goes through one of these. FORMAT uses
    # the model culture, so the grouping is the same everywhere.
    def display(source, fmt='"#,##0"', zero_for_blank=False, date=False):
        empty = '"0"' if zero_for_blank else 'UNICHAR ( 8212 )'
        if date:
            body = ('VAR _v = [%s]\nRETURN\n    IF ( ISBLANK ( _v ), %s, '
                    'FORMAT ( _v, "dd-MMM-yyyy" ) )' % (source, empty))
        else:
            body = ('VAR _v = [%s]\nRETURN\n    IF ( ISBLANK ( _v ), %s, '
                    'FORMAT ( _v, %s ) )' % (source, empty, fmt))
        return M(source + " Display", body, None,
                 "Card-safe text form of [%s]. See the note on this display "
                 "folder for why every KPI value is text." % source, f)

    for src in ["Email Volume", "Email Volume (All Populations)",
                "Latest Day Volume", "Previous Day Volume", "Peak Daily Volume",
                "Minimum Daily Volume", "Source Rows", "Total Rows",
                "Test Rows", "Client Count", "Program Count", "Creative Count",
                "Site Count", "Client Group Count", "Active Reminder Stages",
                "Journey Stage Count", "Reminder Count"]:
        a(display(src))
    a(display("Average Daily Volume", '"#,##0.0"'))
    for src in ["Control Rows", "Control Population", "Rows Needing Review",
                "Exception Day Count", "Null Client Rows", "Null Program Rows",
                "Null Reminder Rows", "Null Date Rows",
                "Null Email Volume Rows", "Negative Email Values",
                "Unexpected T/C Values", "Unexpected Reminder Values",
                "Duplicate Rows"]:
        a(display(src, zero_for_blank=True))
    # ----------------------------------------------------------------
    # 12  Scale - top N
    #
    # The extract this was built against has three clients. Production is
    # 100+ clients and 100k+ rows, and at that size a ranking chart drawn
    # over every member is not a chart - it is a scrollbar. Every ranking
    # visual is therefore drawn through a Top-N measure that returns BLANK
    # for members outside the cut, which Power BI drops from the plot.
    #
    # Doing this in DAX rather than with a visual-level TopN filter keeps the
    # cut honest: ALLSELECTED means the ranking is computed inside whatever
    # the user has already filtered to, so "top 10" is top 10 of the current
    # selection, not top 10 of the dataset re-ranked afterwards. Each chart
    # also carries a caption stating what the cut hides.
    # ----------------------------------------------------------------
    f = "12 Scale"

    a(M("Top N", "%d" % TOP_N, "0",
        "How many members a ranking visual draws. Change here and every "
        "ranking chart and its caption follow.", f))

    def top_volume(label, table, column):
        return M("Top N %s Volume" % label, '''
-- The ranked set has to be computed ONCE for the whole visual, not once per
-- cell. Ranking inside the cell context means the top ten are re-chosen for
-- every reminder stage and every week, so a stacked chart drew twenty-two
-- clients instead of ten and a weekly line chart with ten series never
-- returned at all.
--
-- Wrapping the ranking table in CALCULATETABLE ( ..., ALLSELECTED () ) strips
-- the visual's own groupings while keeping the slicers, so the set depends
-- only on what the user filtered to - one set, cached, and stable across
-- every cell of the visual.
VAR _n = [Top N]
VAR _ranked =
    TOPN (
        _n,
        CALCULATETABLE (
            ADDCOLUMNS (
                VALUES ( '%s'[%s] ),
                "@vol", CALCULATE ( [Email Volume] )
            ),
            ALLSELECTED ()
        ),
        [@vol], DESC
    )
VAR _keep = SELECTCOLUMNS ( _ranked, "@k", '%s'[%s] )
VAR _this = SELECTEDVALUE ( '%s'[%s] )
RETURN
    IF ( _this IN _keep, [Email Volume] )
''' % (table, column, table, column, table, column), FMT_INT,
                 "Email volume for the top %d %s by volume in the current "
                 "selection, blank elsewhere so the chart drops them. Not to be "
                 "confused with the 'Top %s Volume' insight measure, which is "
                 "the single largest member."
                 % (TOP_N, label.lower(), label), f)

    a(top_volume("Client", "Dim_Client", "Client_name"))
    a(top_volume("Program", "Dim_Program", "Program"))
    a(top_volume("Creative", "Dim_CommCode", "comm_code"))

    def coverage(label, table, column, count_measure):
        return M("%s Coverage Caption" % label, '''
-- States what the Top-N cut is hiding, so the chart never silently implies
-- it is showing everything. Ranked over the same ALLSELECTED scope as the
-- measure it describes, or the caption would disagree with its own chart.
VAR _n = [Top N]
VAR _scope =
    CALCULATETABLE (
        ADDCOLUMNS (
            VALUES ( '%s'[%s] ),
            "@vol", CALCULATE ( [Email Volume] )
        ),
        ALLSELECTED ()
    )
VAR _all = COUNTROWS ( _scope )
VAR _total = SUMX ( _scope, [@vol] )
VAR _shown = SUMX ( TOPN ( _n, _scope, [@vol], DESC ), [@vol] )
VAR _share = DIVIDE ( _shown, _total )
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( _all ), "",
        _all <= _n,
            FORMAT ( _all, "#,##0" ) & " %s in selection",
        "Top " & FORMAT ( _n, "0" ) & " of " & FORMAT ( _all, "#,##0" )
            & " %s  -  " & FORMAT ( _share, "0.0%%" ) & " of selected volume"
    )
''' % (table, column, label.lower() + "s", label.lower() + "s"), None,
                 "Caption stating how much of the selection the Top-%d cut "
                 "covers." % TOP_N, f)

    a(coverage("Client", "Dim_Client", "Client_name", "Client Count"))
    a(coverage("Program", "Dim_Program", "Program", "Program Count"))
    a(coverage("Creative", "Dim_CommCode", "comm_code", "Creative Count"))

    # ----------------------------------------------------------------
    # The contribution band at the foot of page 1.
    #
    # This band has been through three designs. The first was four dynamic
    # sentences, which restated the KPI tiles. The second was a nested treemap
    # of program and client with a "how many clients make 80% of the volume"
    # card beside it; both were rejected on the only test that matters - a
    # senior reader who has not worked with the data could not tell what
    # either one was showing. A treemap asks the eye to compare areas, which
    # people do badly, and asks the reader to know that nesting means
    # hierarchy. The 80% card asked them to hold a cumulative-share idea in
    # their head before the number meant anything.
    #
    # What replaced both is the plainest chart there is: a ranked bar with the
    # name beside it and the number printed on the end of it. Length is the
    # one visual encoding people read accurately, the label says which client,
    # the data label says how many emails, and the subtitle says in words what
    # is shown and what is not. Nothing needs explaining before it can be read.
    #
    # Five, not ten. The band is 174px tall and ten horizontal bars in it are
    # 11px each and then a scrollbar. Five is also the number a leader asks
    # for: the shortlist, with everything else accounted for in one sentence.
    # ----------------------------------------------------------------
    a(M("Shortlist Size", "5", "0",
        "How many members the two contribution charts at the foot of page 1 "
        "draw. Separate from [Top N] because those two are short horizontal "
        "bars in a 174px band, where ten do not fit. Change here and both "
        "charts, both titles and both captions follow.", f))

    def shortlist_volume(label, table, column):
        return M("Shortlist %s Volume" % label, """
-- Same construction as [Top N %s Volume], cut to [Shortlist Size]. The ranked
-- set is computed ONCE for the whole visual under ALLSELECTED (), not once per
-- bar: ranking inside the cell context re-chooses the shortlist for every
-- category, and the chart then draws the wrong number of bars.
VAR _n = [Shortlist Size]
VAR _ranked =
    TOPN (
        _n,
        CALCULATETABLE (
            ADDCOLUMNS (
                VALUES ( '%s'[%s] ),
                "@vol", CALCULATE ( [Email Volume] )
            ),
            ALLSELECTED ()
        ),
        [@vol], DESC
    )
VAR _keep = SELECTCOLUMNS ( _ranked, "@k", '%s'[%s] )
VAR _this = SELECTEDVALUE ( '%s'[%s] )
RETURN
    IF ( _this IN _keep, [Email Volume] )
""" % (label, table, column, table, column, table, column), FMT_INT,
                 "Email volume for the %d largest %s in the current "
                 "selection, blank elsewhere so the bar chart drops them. "
                 "Drives the contribution band at the foot of page 1."
                 % (SHORTLIST, label.lower() + "s"), f)

    a(shortlist_volume("Client", "Dim_Client", "Client_name"))
    a(shortlist_volume("Program", "Dim_Program", "Program"))

    def shortlist_caption(label, plural, table, column):
        return M("Shortlist %s Caption" % label, """
-- Plain English, and quantified. Every earlier version of this caption was
-- written for an analyst: "Top 5 of 128 clients - 67.9%% of selected volume"
-- is four pieces of shorthand, and a reader who does not already know the
-- report cannot unpack it. This one names what is on the chart, says what
-- share of the email it accounts for, and accounts for what is left off.
VAR _n = [Shortlist Size]
VAR _scope =
    CALCULATETABLE (
        ADDCOLUMNS (
            VALUES ( '%s'[%s] ),
            "@vol", CALCULATE ( [Email Volume] )
        ),
        ALLSELECTED ()
    )
VAR _pos = FILTER ( _scope, [@vol] > 0 )
VAR _all = COUNTROWS ( _pos )
VAR _total = SUMX ( _pos, [@vol] )
VAR _shown = SUMX ( TOPN ( _n, _pos, [@vol], DESC ), [@vol] )
RETURN
    SWITCH (
        TRUE (),
        ISBLANK ( _all ) || _all = 0, "No email was sent in this selection.",
        _all = 1, "One %s sent all the email in this selection.",
        _all <= _n,
            "All " & FORMAT ( _all, "#,##0" )
                & " %s that sent email, biggest first.",
        -- Two sentences, and both of them short. These captions sit in panels
        -- 418px and 556px wide, and a chart subtitle in Power BI truncates
        -- with an ellipsis rather than wrapping to a second line: the first
        -- draft of this branch ran to 96 characters and lost its last four
        -- words on screen. "5 of 128" and the share together say what the
        -- longer sentence said.
        "The " & FORMAT ( _n, "0" ) & " biggest of "
            & FORMAT ( _all, "#,##0" ) & " %s. They send "
            & FORMAT ( DIVIDE ( _shown, _total ), "0%%" )
            & " of all email here."
    )
""" % (table, column, label.lower(), plural, plural), None,
                 "Plain-language subtitle for the %s contribution chart: what "
                 "is on it, what share of the email it covers, and what is "
                 "left off." % label.lower(), f)

    a(shortlist_caption("Client", "clients", "Dim_Client", "Client_name"))
    a(shortlist_caption("Program", "programs", "Dim_Program", "Program"))

    def shortlist_title(label, plural, table, column):
        return M("Shortlist %s Title" % label, """
-- The title states the cut, so it can never claim to be showing everything
-- while the chart draws five of a hundred and twenty-eight.
VAR _n = [Shortlist Size]
VAR _scope =
    CALCULATETABLE (
        ADDCOLUMNS (
            VALUES ( '%s'[%s] ),
            "@vol", CALCULATE ( [Email Volume] )
        ),
        ALLSELECTED ()
    )
VAR _all = COUNTROWS ( FILTER ( _scope, [@vol] > 0 ) )
RETURN
    IF (
        ISBLANK ( _all ) || _all <= _n,
        "EMAIL VOLUME BY %s",
        "TOP " & FORMAT ( _n, "0" ) & " %s BY EMAIL VOLUME"
    )
""" % (table, column, label.upper(), plural.upper()), None,
                 "Title for the %s contribution chart, stating the cut when "
                 "there is one." % label.lower(), f)

    a(shortlist_title("Client", "clients", "Dim_Client", "Client_name"))
    a(shortlist_title("Program", "programs", "Dim_Program", "Program"))

    # ----------------------------------------------------------------
    # 13  Compact captions
    #
    # A KPI tile caption gets one line and, on a six-tile row, about 220px of
    # it. The full sentences these compress live on the narrative strip, where
    # there is room for them; putting them on a tile only produced an
    # ellipsis. Every caption here is built to fit, and long client names are
    # truncated explicitly rather than being cut off by the renderer.
    # ----------------------------------------------------------------
    fc = "13 Compact Captions"

    def short_top(label, table, column):
        return M("Top %s Short" % label, '''
VAR _members =
    CALCULATETABLE ( VALUES ( '%s'[%s] ), ALLSELECTED ( '%s' ) )
VAR _top = TOPN ( 1, _members, [Email Volume], DESC )
VAR _name = MAXX ( _top, '%s'[%s] )
VAR _vol = SUMX ( _top, [Email Volume] )
VAR _share = DIVIDE ( _vol, [Email Volume] )
VAR _clip = IF ( LEN ( _name ) > 22, LEFT ( _name, 21 ) & UNICHAR ( 8230 ), _name )
RETURN
    IF ( ISBLANK ( _name ), "", "Top: " & _clip & "  " & FORMAT ( _share, "0.0%%" ) )
''' % (table, column, table, table, column), None,
                 "Leading %s and its share, sized for a KPI tile caption."
                 % label.lower(), fc)

    a(short_top("Client", "Dim_Client", "Client_name"))
    a(short_top("Program", "Dim_Program", "Program"))
    a(short_top("Creative", "Dim_CommCode", "comm_code"))

    a(M("Data Quality Short", '''
VAR _bad = [Rows Needing Review]
RETURN
    IF ( _bad = 0 || ISBLANK ( _bad ), "All rows pass every check",
         FORMAT ( _bad, "#,##0" ) & " rows need review" )
''', None, "Data quality state, sized for a tile caption.", fc))

    a(M("Reconciliation Short", '''
"Test-only basis  -  " & FORMAT ( [Email Volume (All Populations)], "#,##0" )
    & " all populations"
''', None, "Reconciliation of the Test-only figure against the raw column "
     "sum, sized for a tile caption.", fc))

    a(M("Control Presence Short", '''
VAR _c = [Control Rows]
RETURN IF ( _c = 0 || ISBLANK ( _c ), "None in this selection",
            FORMAT ( _c, "#,##0" ) & " rows, never mailed" )
''', None, "Control-row state, sized for a tile caption.", fc))

    a(M("Raw Records Caption", '''
-- The raw page states its own grain and its own size, because a scrolling
-- table gives the reader no other way to know how much is under it.
VAR _rows = [Total Rows]
VAR _clients = [Client Count]
RETURN
    IF (
        ISBLANK ( _rows ), "No records in this selection.",
        FORMAT ( _rows, "#,##0" ) & " records across "
            & FORMAT ( _clients, "#,##0" )
            & IF ( _clients = 1, " client", " clients" )
            & ", newest first. One row per client, group, creative, site, "
            & "stage, program, date and T/C indicator - exactly as the feed "
            & "delivers it."
    )
''', None, "Grain and size statement for the operational records table.", fc))

    a(M("Export Hint", '''
-- Power BI has no scriptable download button, so the export has to be
-- pointed at rather than wired up. The row count is live because the caps
-- below are the whole reason this hint exists.
VAR _rows = [Total Rows]
RETURN
    "To export: hover this table, open the  ...  menu at its top right and "
    & "choose Export data (or right-click the table). "
    & "CSV is capped at 30,000 rows and Excel at 150,000 - this selection "
    & "holds " & FORMAT ( _rows, "#,##0" )
    & ". For the complete extract with no cap, run tools/export_raw_csv.ps1."
''', None, "On-page instructions for exporting the raw records.", fc))

    a(M("Page Status Notice", '''
-- One slot, two messages that cannot both matter at once: an empty selection
-- is not also a large one. Keeping them in a single card leaves the masthead
-- strip to two banners instead of three.
VAR _none = [No Data Notice]
RETURN IF ( _none <> "", _none, [Scale Notice] )
''', None, "The no-data banner, or the large-selection banner when there is "
     "data.", fc))

    a(M("Scale Notice", '''
-- Appears only when the selection is large enough that the detail visuals on
-- the page are showing a window onto the data rather than all of it.
-- The number here has to be the cut the charts on the page actually apply.
-- It said "rankings show top 10" while the two contribution charts were
-- drawing five, which is a banner contradicting the chart beneath it.
VAR _clients = [Client Count]
VAR _rows = [Total Rows]
VAR _n = [Shortlist Size]
RETURN
    IF (
        _clients > _n || _rows > 20000,
        FORMAT ( _clients, "#,##0" ) & " clients  -  the charts below show the "
            & "top " & FORMAT ( _n, "0" ),
        ""
    )
''', None, "Banner shown when the selection is too large to draw in full.", f))

    return out
