# Evaluates every measure a card or a dynamic title is bound to, against the
# model running inside an open Power BI Desktop session, and writes the results
# for preview_report.py to merge in.
#
# The preview is only worth looking at if the numbers on it are the model's own.
# Nothing here is computed in PowerShell - each value is one DAX evaluation.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$legacy = Join-Path $root 'CDP_Reminder_Volume_Dashboard.Report\report.json'
$outDir = Join-Path $root 'build\preview'
$outFile = Join-Path $outDir 'card_values.json'

# ---- collect the measure names the report actually binds to ---------------
$doc = Get-Content $legacy -Raw | ConvertFrom-Json
$names = New-Object System.Collections.Generic.HashSet[string]
foreach ($sec in $doc.sections) {
    foreach ($vc in $sec.visualContainers) {
        $cfg = $vc.config | ConvertFrom-Json
        $sv = $cfg.singleVisual
        if ($null -eq $sv) { continue }
        if ($sv.visualType -eq 'card' -and $sv.projections.Values) {
            $q = $sv.projections.Values[0].queryRef
            if ($q -like '_Measures.*') { [void]$names.Add($q.Substring(10)) }
        }
        # Dynamic titles and subtitles are measures too, and they are half the
        # point of the design - a preview showing {Trend Title} shows nothing.
        foreach ($part in @('title', 'subTitle')) {
            foreach ($e in $sv.vcObjects.$part) {
                $t = $e.properties.text
                if ($t.expr.Measure.Property) { [void]$names.Add($t.expr.Measure.Property) }
            }
        }
    }
}
"measures to evaluate: $($names.Count)"

# ---- connect to the workspace instance ------------------------------------
. "$PSScriptRoot\_find_adomd.ps1"
$adomd = Get-AdomdPath
[void][System.Reflection.Assembly]::LoadFrom($adomd)
$wsRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\Power BI Desktop\AnalysisServicesWorkspaces'
$conn = $null
foreach ($dir in (Get-ChildItem $wsRoot -Directory -EA SilentlyContinue | Sort-Object LastWriteTime -Descending)) {
    $pf = Join-Path $dir.FullName 'Data\msmdsrv.port.txt'
    if (-not (Test-Path $pf)) { continue }
    $port = -join ((Get-Content $pf -Raw).ToCharArray() | Where-Object { $_ -match '\d' })
    if (-not $port) { continue }
    try {
        $c = New-Object Microsoft.AnalysisServices.AdomdClient.AdomdConnection("Data Source=localhost:$port")
        $c.Open(); $cd = $c.CreateCommand()
        $cd.CommandText = 'SELECT [CATALOG_NAME] FROM $SYSTEM.DBSCHEMA_CATALOGS'
        $rr = $cd.ExecuteReader(); $cat = $null
        if ($rr.Read()) { $cat = $rr.GetValue(0) }
        $rr.Close(); $c.Close()
        if (-not $cat) { continue }
        $conn = New-Object Microsoft.AnalysisServices.AdomdClient.AdomdConnection("Data Source=localhost:$port;Catalog=$cat")
        $conn.Open()
        "connected to $cat on port $port"
        break
    } catch { }
}
if (-not $conn) { "no Power BI Desktop workspace instance found"; exit 1 }

function Eval([string]$m) {
    $cmd = $conn.CreateCommand()
    $cmd.CommandText = 'EVALUATE ROW("v", [' + $m.Replace(']', ']]') + '])'
    try {
        $r = $cmd.ExecuteReader()
        $v = $null
        if ($r.Read()) { $v = $r.GetValue(0) }
        $r.Close()
        if ($null -eq $v -or $v -is [System.DBNull]) { return '' }
        # A card renders the measure's own format string. Integers are the only
        # case the raw value gets wrong, so give those the thousands separator
        # the model's format string carries.
        if ($v -is [double] -and [math]::Floor($v) -eq $v -and [math]::Abs($v) -ge 1000) {
            return $v.ToString('#,##0')
        }
        return [string]$v
    } catch { return '' }
}

$out = @{}
$errors = 0
foreach ($m in $names) {
    $v = Eval $m
    $out[$m] = $v
}
New-Item -ItemType Directory -Force $outDir | Out-Null
($out | ConvertTo-Json -Depth 3) | Out-File -FilePath $outFile -Encoding utf8
$conn.Close()
"wrote $outFile  ($($out.Count) values, $errors errored)"
