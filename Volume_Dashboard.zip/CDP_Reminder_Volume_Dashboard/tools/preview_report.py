# -*- coding: utf-8 -*-
"""Renders the emitted report as a static HTML preview.

This is not a mockup. Every rectangle, colour, font size and piece of static
text is read out of the same report.json that Power BI Desktop loads, so the
preview cannot drift from the build the way a hand-drawn mock would.

Card values are the one thing the JSON does not carry, because they are
measures. Run dump_card_values.ps1 against an open Desktop session first and
the real values are merged in; without it a card renders its measure name in
braces and the preview header says so.

Chart interiors are not drawn - a chart's pixels come from the engine at render
time, and inventing them is exactly the "cheat with static output" the spec
rules out. Their real chrome, titles and subtitles are drawn, and the plot area
is left as a marked region.

Run:  python tools/preview_report.py
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT = "CDP_Reminder_Volume_Dashboard"
LEGACY = os.path.join(ROOT, PROJECT + ".Report", "report.json")
VALUES = os.path.join(ROOT, "build", "preview", "card_values.json")
OUT = os.path.join(ROOT, "build", "preview", "preview.html")

PAGE_W, PAGE_H = 1440, 810


# --------------------------------------------------------------------------
# unwrapping the expression containers report.json wraps every property in
# --------------------------------------------------------------------------
def val(node):
    """Pull a scalar out of {'expr': {'Literal': {'Value': "'x'"}}}."""
    if node is None:
        return None
    if isinstance(node, dict):
        if "expr" in node:
            return val(node["expr"])
        if "Literal" in node:
            v = node["Literal"].get("Value")
            if v is None:
                return None
            if v.startswith("'") and v.endswith("'"):
                return v[1:-1].replace("''", "'")
            if v in ("true", "false"):
                return v == "true"
            if v.endswith(("D", "L")):
                try:
                    return float(v[:-1])
                except ValueError:
                    return v[:-1]
            return v
        if "Measure" in node:
            return {"__measure__": node["Measure"].get("Property")}
        if "solid" in node:
            return val(node["solid"].get("color"))
        if "Column" in node:
            return {"__column__": node["Column"].get("Property")}
    return node


def prop(objs, name, key, default=None):
    """First value of objects[name][*].properties[key], ignoring selectors."""
    for entry in (objs or {}).get(name, []) or []:
        if "selector" in entry:
            continue
        p = entry.get("properties", {})
        if key in p:
            v = val(p[key])
            if v is not None:
                return v
    return default


def measure_of(cfg):
    """The measure a card is bound to."""
    proj = (((cfg.get("singleVisual") or {}).get("projections") or {})
            .get("Values") or [])
    if proj:
        q = proj[0].get("queryRef", "")
        return q.split(".", 1)[-1] if "." in q else q
    return None


def esc(t):
    return str(t).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


CHART_TYPES = {"lineChart", "barChart", "columnChart", "pivotTable", "tableEx",
               "hundredPercentStackedColumnChart"}

SANS = "'Segoe UI',system-ui,sans-serif"


def render_visual(vc, values):
    cfg = json.loads(vc["config"])
    sv = cfg.get("singleVisual", {})
    vt = sv.get("visualType")
    vco = sv.get("vcObjects", {})
    o = sv.get("objects", {})
    x, y = vc.get("x", 0), vc.get("y", 0)
    w, h = vc.get("width", 0), vc.get("height", 0)
    z = vc.get("z", 0)

    css = ["position:absolute", "left:%gpx" % x, "top:%gpx" % y,
           "width:%gpx" % w, "height:%gpx" % h, "z-index:%d" % (int(z) + 1),
           "box-sizing:border-box", "overflow:hidden"]
    if prop(vco, "background", "show"):
        css.append("background:%s"
                   % (prop(vco, "background", "color") or "transparent"))
    if prop(vco, "border", "show"):
        css.append("border:1px solid %s" % (prop(vco, "border", "color") or "#000"))
        css.append("border-radius:%gpx" % (prop(vco, "border", "radius") or 0))

    inner = []
    pad_top = 0

    # Title and subtitle stack at the top of the container, above the content,
    # which is where Power BI puts them.
    if prop(vco, "title", "show"):
        t = prop(vco, "title", "text")
        if isinstance(t, dict):
            t = values.get(t.get("__measure__"), "{%s}" % t.get("__measure__"))
        fs = prop(vco, "title", "fontSize", 11)
        fc = prop(vco, "title", "fontColor", "#000")
        inner.append('<div style="font:600 %gpt %s;color:%s;line-height:1.3;'
                     'padding:5px 8px 0;white-space:nowrap;overflow:hidden;'
                     'text-overflow:ellipsis;letter-spacing:.02em">%s</div>'
                     % (fs, SANS, fc, esc(t or "")))
        pad_top += fs * 1.9 + 5
    if prop(vco, "subTitle", "show"):
        t = prop(vco, "subTitle", "text")
        if isinstance(t, dict):
            t = values.get(t.get("__measure__"), "{%s}" % t.get("__measure__"))
        fs = prop(vco, "subTitle", "fontSize", 9.5)
        fc = prop(vco, "subTitle", "fontColor", "#666")
        inner.append('<div style="font:400 %gpt %s;color:%s;line-height:1.3;'
                     'padding:1px 8px 0">%s</div>' % (fs, SANS, fc, esc(t or "")))
        pad_top += fs * 2.0

    if vt == "textbox":
        paras = prop(o, "general", "paragraphs") or []
        runs, align = [], "left"
        for para in paras:
            align = para.get("horizontalTextAlignment", "left")
            for r in para.get("textRuns", []):
                st = r.get("textStyle", {})
                runs.append('<span style="font-size:%s;color:%s;font-weight:%s">'
                            '%s</span>'
                            % (st.get("fontSize", "9pt"), st.get("color", "#000"),
                               st.get("fontWeight", "400"),
                               esc(r.get("value", ""))))
        valign = prop(o, "general", "verticalTextAlignment") or "top"
        just = {"top": "flex-start", "middle": "center",
                "bottom": "flex-end"}.get(valign, "flex-start")
        inner.append('<div style="height:100%%;display:flex;flex-direction:column;'
                     'justify-content:%s;text-align:%s;line-height:1.3;'
                     'font-family:%s">%s</div>' % (just, align, SANS, "".join(runs)))

    elif vt == "card":
        m = measure_of(cfg)
        if m in values:
            shown = values[m]
        else:
            shown = "{%s}" % m
        fs = prop(o, "labels", "fontSize", 28)
        fc = prop(o, "labels", "color")
        if fc is None or isinstance(fc, dict):
            fc = "#56635F"        # measure-driven colour: preview it neutrally
        inner.append('<div style="height:calc(100%% - %gpx);display:flex;'
                     'align-items:center;padding:0 8px;font:600 %gpt %s;'
                     'color:%s;line-height:1.2;overflow:hidden">%s</div>'
                     % (pad_top, fs, SANS, fc, esc(shown)))

    elif vt == "actionButton":
        # A button keeps fill, outline and text under `objects`, not under
        # `vcObjects` like every other visual's chrome. Reading the wrong one
        # gives a silently unlabelled button.
        vco = o
        fill, fg, label, line = "transparent", "#000", "", None
        for e in vco.get("fill", []) or []:
            c = val((e.get("properties") or {}).get("fillColor"))
            if c:
                fill = c
        for e in vco.get("outline", []) or []:
            c = val((e.get("properties") or {}).get("lineColor"))
            if c:
                line = c
        for e in vco.get("text", []) or []:
            p = e.get("properties") or {}
            if "text" in p:
                label = val(p["text"])
                fg = val(p.get("fontColor")) or fg
        css.append("background:%s" % fill)
        if line:
            css.append("border:1px solid %s" % line)
            css.append("border-radius:6px")
        inner.append('<div style="height:100%%;display:flex;align-items:center;'
                     'justify-content:center;font:600 9pt %s;color:%s">%s</div>'
                     % (SANS, fg, esc(label)))

    elif vt == "slicer":
        # A slicer styles its header and its item list through `objects`, the
        # same place a button keeps its fill - not through `vcObjects`.
        vco = o
        head = None
        for e in vco.get("header", []) or []:
            p = e.get("properties") or {}
            if "text" in p:
                head = val(p["text"])
        hdr_c = prop(vco, "header", "fontColor", "#888")
        item_bg = prop(vco, "items", "background", "#fff")
        item_fc = prop(vco, "items", "fontColor", "#000")
        line = prop(vco, "general", "outlineColor", "#ccc")
        if head:
            inner.append(
                '<div style="height:100%%;display:flex;flex-direction:column;'
                'font-family:%s">'
                '<div style="font:600 8.5pt %s;color:%s;padding-bottom:3px">%s</div>'
                '<div style="flex:1;background:%s;border:1px solid %s;display:flex;'
                'align-items:center;justify-content:space-between;padding:0 6px;'
                'font:400 9pt %s;color:%s"><span>All</span>'
                '<span style="opacity:.55">&#9662;</span></div></div>'
                % (SANS, SANS, hdr_c, esc(head), item_bg, line, SANS, item_fc))
        else:
            box = ('<div style="flex:1;background:%s;border:1px solid %s;height:26px;'
                   'display:flex;align-items:center;padding:0 6px;font:400 9pt %s;'
                   'color:%s">%%s</div>' % (item_bg, line, SANS, item_fc))
            inner.append(
                '<div style="height:calc(100%% - %gpx);display:flex;gap:6px;'
                'align-items:center;padding:4px 8px 0">%s'
                '<span style="color:%s;font:400 9pt %s">to</span>%s</div>'
                % (pad_top, box % "22-Apr-2026", item_fc, SANS,
                   box % "10-Sep-2026"))

    elif vt in CHART_TYPES:
        inner.append('<div class="plot" style="height:calc(100%% - %gpx);'
                     'margin:2px 8px 8px"><span>%s</span></div>'
                     % (pad_top + 4, esc(vt)))

    return '<div style="%s">%s</div>' % (";".join(css), "".join(inner))


# --------------------------------------------------------------------------
def build():
    doc = json.load(open(LEGACY, encoding="utf-8"))
    values, have_values = {}, False
    if os.path.isfile(VALUES):
        values = json.load(open(VALUES, encoding="utf-8-sig"))
        have_values = True

    cfg = json.loads(doc.get("config", "{}"))
    page_bg, outspace = "#FFFFFF", "#EEEEEE"

    pages = []
    for sec in sorted(doc["sections"], key=lambda s: s.get("ordinal", 0)):
        objs = (sec.get("objects") or {})
        page_bg = prop(objs, "background", "color", page_bg)
        outspace = prop(objs, "outspace", "color", outspace)
        vis = sorted(sec["visualContainers"], key=lambda v: v.get("z", 0))
        body = "".join(render_visual(v, values) for v in vis)
        pages.append((sec.get("displayName", sec["name"]), len(vis), body,
                      page_bg, outspace))

    note = ("Card values below are live, read from the running model."
            if have_values else
            "Card values are shown as {Measure Name}: the value dump has not "
            "been run against an open Desktop session.")

    html = []
    html.append('<meta charset="utf-8"><title>CDP Report Preview</title>')
    html.append('<style>'
                'body{margin:0;background:%s;font-family:%s;color:#13211F}'
                '.wrap{padding:28px}'
                '.cap{font:600 13px %s;color:#13211F;margin:26px 0 8px;'
                'letter-spacing:.04em;text-transform:uppercase}'
                '.cap span{font-weight:400;color:#7d8a85;text-transform:none;'
                'letter-spacing:0}'
                '.page{position:relative;width:%dpx;height:%dpx;overflow:hidden;'
                'box-shadow:0 2px 18px rgba(0,0,0,.18)}'
                '.plot{border:1px dashed #cfc6b4;border-radius:2px;display:flex;'
                'align-items:center;justify-content:center}'
                '.plot span{font:400 9px %s;color:#b3a893;letter-spacing:.08em;'
                'text-transform:uppercase}'
                '.note{font:400 12px %s;color:#4a5551;background:#fff;'
                'border-left:3px solid #0E7A6A;padding:10px 14px;max-width:%dpx}'
                '</style>' % (outspace, SANS, SANS, PAGE_W, PAGE_H, SANS, SANS,
                              PAGE_W))
    html.append('<div class="wrap">')
    html.append('<div class="note">%s Geometry, colour and static text are read '
                'directly from the generated report.json. Chart interiors are '
                'not drawn - only their real chrome.</div>' % esc(note))
    for name, n, body, bg, _o in pages:
        html.append('<div class="cap">%s <span>&nbsp;&nbsp;%d visuals</span></div>'
                    % (esc(name), n))
        html.append('<div class="page" style="background:%s">%s</div>' % (bg, body))
    html.append('</div>')

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as fh:
        fh.write("\n".join(html))
    print("preview written to %s" % OUT)
    print("  pages: %d   card values: %s"
          % (len(pages), "live" if have_values else "not loaded"))
    return 0


if __name__ == "__main__":
    sys.exit(build())
