<#
.SYNOPSIS
    Evaluates the model's DAX against the real Analysis Services engine inside
    an open Power BI Desktop session.

.DESCRIPTION
    tools/validate_data.py proves the *logic* is right by recomputing every
    figure from the CSV in Python. This script proves the *DAX* is right: it
    connects to the workspace instance Power BI Desktop starts, evaluates every
    measure looking for errors, runs the headline figures and the per-journey
    breakdown, and compares them against Documentation/validation_summary.json.

    Open CDP_Reminder_Volume_Dashboard.pbip in Power BI Desktop first, then:
        powershell -ExecutionPolicy Bypass -File tools\verify_live_model.ps1
#>
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot

if (-not (Get-Process PBIDesktop -ErrorAction SilentlyContinue)) {
    Write-Output 'Power BI Desktop is not running. Open CDP_Reminder_Volume_Dashboard.pbip first.'
    exit 2
}

. "$PSScriptRoot\_find_adomd.ps1"
$adomd = Get-AdomdPath
if (-not $adomd) { Write-Output "ADOMD client not found - is Power BI Desktop installed?"; exit 2 }
[void][System.Reflection.Assembly]::LoadFrom($adomd)

# --------------------------------------------------------------------------
# locate the live workspace instance
# --------------------------------------------------------------------------
$wsRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\Power BI Desktop\AnalysisServicesWorkspaces'
$conn = $null
foreach ($dir in (Get-ChildItem $wsRoot -Directory -ErrorAction SilentlyContinue |
                  Sort-Object LastWriteTime -Descending)) {
    $pf = Join-Path $dir.FullName 'Data\msmdsrv.port.txt'
    if (-not (Test-Path $pf)) { continue }
    # msmdsrv.port.txt is UTF-16; take the digits rather than trusting encoding.
    $port = -join ((Get-Content $pf -Raw).ToCharArray() | Where-Object { $_ -match '\d' })
    if (-not $port) { continue }
    try {
        $c = New-Object Microsoft.AnalysisServices.AdomdClient.AdomdConnection("Data Source=localhost:$port")
        $c.Open(); $cmd = $c.CreateCommand()
        $cmd.CommandText = 'SELECT [CATALOG_NAME] FROM $SYSTEM.DBSCHEMA_CATALOGS'
        $r = $cmd.ExecuteReader(); $cat = $null
        if ($r.Read()) { $cat = $r.GetValue(0) }
        $r.Close(); $c.Close()
        if ($cat) {
            $conn = New-Object Microsoft.AnalysisServices.AdomdClient.AdomdConnection("Data Source=localhost:$port;Catalog=$cat")
            $conn.Open()
            Write-Output "connected: localhost:$port   catalog $cat"
            break
        }
    } catch { }
}
if (-not $conn) { Write-Output 'no live workspace instance found'; exit 2 }

function Invoke-Dax([string]$q) {
    $cmd = $conn.CreateCommand(); $cmd.CommandText = $q
    $rd = $cmd.ExecuteReader()
    $rows = @()
    while ($rd.Read()) {
        $o = [ordered]@{}
        for ($i = 0; $i -lt $rd.FieldCount; $i++) {
            # Column names arrive as "Table[Column]" or "[Measure]". Take the
            # part inside the final brackets so property access works.
            $nm = $rd.GetName($i)
            if ($nm -match '\[([^\[\]]+)\]\s*$') { $nm = $Matches[1] }
            $o[$nm] = $rd.GetValue($i)
        }
        $rows += [pscustomobject]$o
    }
    $rd.Close()
    return $rows
}

$fail = 0
$expect = Get-Content (Join-Path $root 'Documentation\validation_summary.json') -Raw | ConvertFrom-Json

# --------------------------------------------------------------------------
Write-Output ''
Write-Output '=== 1. tables loaded ==='
$tables = Invoke-Dax 'SELECT [TABLE_NAME] FROM $SYSTEM.DBSCHEMA_TABLES WHERE [TABLE_TYPE] = ''TABLE'''
foreach ($t in $tables) { Write-Output ("    {0}" -f $t.TABLE_NAME) }

Write-Output ''
Write-Output '=== 2. every measure evaluates without error ==='
$measures = Invoke-Dax 'SELECT [MEASURE_NAME] FROM $SYSTEM.MDSCHEMA_MEASURES'
$names = $measures | ForEach-Object { $_.MEASURE_NAME } |
         Where-Object { $_ -notlike '__*' } | Sort-Object -Unique
$bad = 0
foreach ($n in $names) {
    $esc = $n -replace '\]', ']]'
    try { [void](Invoke-Dax ("EVALUATE ROW(""v"", [{0}])" -f $esc)) }
    catch {
        $bad++; $fail++
        Write-Output ("    ! [{0}] -> {1}" -f $n, $_.Exception.Message.Split("`n")[0])
    }
}
Write-Output ("    {0} measures evaluated, {1} errored" -f $names.Count, $bad)

# --------------------------------------------------------------------------
Write-Output ''
Write-Output '=== 3. headline figures vs the CSV ==='
$q = @'
EVALUATE
ROW (
    "SourceRows",   [Source Rows],
    "TestRows",     [Test Rows],
    "ControlRows",  [Control Rows],
    "EmailVolume",  [Email Volume],
    "AllPop",       [Email Volume (All Populations)],
    "REM1",         [REM1 Volume],
    "REM2",         [REM2 Volume],
    "REM3",         [REM3 Volume],
    "REM4",         [REM4 Volume],
    "ActiveDays",   [Active Days],
    "Earliest",     [Earliest Available Date],
    "Latest",       [Latest Available Date],
    "Prev",         [Previous Available Date],
    "LatestVol",    [Latest Day Volume],
    "PrevVol",      [Previous Day Volume],
    "DoDPct",       [Day-over-Day Change %],
    "AvgDaily",     [Average Daily Volume],
    "PeakDaily",    [Peak Daily Volume],
    "MinDaily",     [Minimum Daily Volume],
    "Clients",      [Client Count],
    "Programs",     [Program Count],
    "Creatives",    [Creative Count],
    "Sites",        [Site Count],
    "Stages",       [Active Reminder Stages],
    "ReviewRows",   [Rows Needing Review]
)
'@
$a = (Invoke-Dax $q)[0]

function Check($label, $actual, $expected, $tol = 0) {
    $ok = $false
    if ($null -eq $expected) { $ok = $true }
    elseif ($actual -is [string] -or $expected -is [string]) { $ok = ("$actual" -eq "$expected") }
    else { $ok = ([math]::Abs([double]$actual - [double]$expected) -le $tol) }
    if (-not $ok) { $script:fail++ }
    Write-Output ("    {0,-26} model={1,-14} csv={2,-14} {3}" -f `
        $label, "$actual", "$expected", $(if ($ok) { 'PASS' } else { 'FAIL' }))
}

Check 'Source Rows'        $a.SourceRows   $expect.source_rows
Check 'Test Rows'          $a.TestRows     $expect.test_rows
# COUNTROWS over an empty set is BLANK, not 0; normalise both sides so the
# check is a real comparison rather than one that passes on a null.
Check 'Control Rows'       $(if ($null -eq $a.ControlRows) { 0 } else { $a.ControlRows }) $expect.control_rows
Check 'Email Volume (T)'   $a.EmailVolume  $expect.email_volume_test
Check 'Volume all pops'    $a.AllPop       $expect.email_volume_all
Check 'REM1 Volume'        $a.REM1         $expect.rem_totals.REM1
Check 'REM2 Volume'        $a.REM2         $expect.rem_totals.REM2
Check 'REM3 Volume'        $a.REM3         $expect.rem_totals.REM3
Check 'REM4 Volume'        $a.REM4         $expect.rem_totals.REM4
Check 'Active Days'        $a.ActiveDays   $expect.active_days
Check 'Earliest date'      $a.Earliest.ToString('yyyy-MM-dd') $expect.earliest_date
Check 'Latest date'        $a.Latest.ToString('yyyy-MM-dd')   $expect.latest_date
Check 'Previous date'      $a.Prev.ToString('yyyy-MM-dd')     $expect.previous_date
Check 'Latest day volume'  $a.LatestVol    $expect.latest_day_volume
Check 'Previous day volume' $a.PrevVol     $expect.previous_day_volume
Check 'DoD %'              $a.DoDPct       $expect.dod_pct 0.0001
Check 'Average daily'      $a.AvgDaily     $expect.average_daily_volume 0.0001
Check 'Peak daily'         $a.PeakDaily    $expect.peak_daily_volume
Check 'Minimum daily'      $a.MinDaily     $expect.minimum_daily_volume
Check 'Client Count'       $a.Clients      $expect.client_count
Check 'Program Count'      $a.Programs     $expect.program_count
Check 'Creative Count'     $a.Creatives    $expect.creative_count
Check 'Site Count'         $a.Sites        $expect.site_count
Check 'Active stages'      $a.Stages       $expect.reminder_count
Check 'Rows needing review' $(if ($null -eq $a.ReviewRows) { 0 } else { $a.ReviewRows }) 0

# --------------------------------------------------------------------------
Write-Output ''
Write-Output '=== 4. dynamic reminder journey per client + program ==='
$q2 = @'
EVALUATE
SUMMARIZECOLUMNS (
    'Dim_Client'[Client_name],
    'Dim_Program'[Program],
    "Journey",  [Journey Path Label],
    "Stages",   [Journey Stage Count],
    "Volume",   [Email Volume],
    "R1", [REM1 In Journey], "R2", [REM2 In Journey],
    "R3", [REM3 In Journey], "R4", [REM4 In Journey],
    "R1v", [REM1 Journey Volume], "R2v", [REM2 Journey Volume],
    "R3v", [REM3 Journey Volume], "R4v", [REM4 Journey Volume],
    "A1", [REM1 Arrow], "A2", [REM2 Arrow], "A3", [REM3 Arrow]
)
ORDER BY 'Dim_Client'[Client_name]
'@
foreach ($r in (Invoke-Dax $q2)) {
    $key = "{0} || {1}" -f $r.Client_name, $r.Program
    $exp = $expect.journeys.$key
    # The model joins stages with a real arrow glyph; normalise it before
    # comparing. A client + program pair with no rows in the CSV must produce
    # the explicit "no stages" caption, never an empty or half-drawn journey.
    if ($exp) { $expJoin = ($exp -join '  ->  ') }
    else      { $expJoin = 'No reminder stages in this selection' }
    $modelJourney = ($r.Journey -replace [char]0x2192, '->')
    $ok = ($modelJourney -eq $expJoin)
    if (-not $ok) { $fail++ }
    Write-Output ("    {0,-34} {1,-8} stages={2} vol={3,-6} {4}" -f `
        $r.Client_name, $r.Program, $r.Stages, $r.Volume, $(if ($ok) { 'PASS' } else { 'FAIL' }))
    Write-Output ("        model journey : {0}" -f $modelJourney)
    Write-Output ("        csv   journey : {0}" -f $expJoin)
    # A slot that is not in the journey must be BLANK, not 0, and the arrow
    # into it must be blank too - that is the whole absence-vs-zero rule.
    $slots = @($r.R1, $r.R2, $r.R3, $r.R4)
    $vals  = @($r.R1v, $r.R2v, $r.R3v, $r.R4v)
    $arrows = @($r.A1, $r.A2, $r.A3)
    for ($i = 0; $i -lt 4; $i++) {
        $inJourney = ($slots[$i] -eq 1)
        $isBlank = ($null -eq $vals[$i])
        if ($inJourney -and $isBlank) { $fail++; Write-Output ("        ! REM$($i+1) is in the journey but its card is blank") }
        if ((-not $inJourney) -and (-not $isBlank)) { $fail++; Write-Output ("        ! REM$($i+1) is NOT in the journey but its card renders $($vals[$i])") }
    }
    $shown = @(); for ($i=0; $i -lt 4; $i++) { if ($slots[$i] -eq 1) { $shown += "REM$($i+1)" } }
    Write-Output ("        slots rendered: {0}   arrows: {1}" -f ($shown -join ','), (($arrows | Where-Object { $_ }) -join ''))
}

# --------------------------------------------------------------------------
Write-Output ''
Write-Output '=== 5. reminder stage totals and shares ==='
$q3 = @'
EVALUATE
SUMMARIZECOLUMNS (
    'Dim_Reminder'[Reminder Short Name],
    'Dim_Reminder'[Reminder Order],
    "Volume", [Email Volume],
    "Share",  [Reminder Stage Share],
    "Movement", [Stage Volume Movement],
    "Colour", [Reminder Stage Colour]
)
ORDER BY 'Dim_Reminder'[Reminder Order]
'@
foreach ($r in (Invoke-Dax $q3)) {
    $exp = $expect.rem_totals."$($r.'Reminder Short Name')"
    $ok = ([int]$r.Volume -eq [int]$exp)
    if (-not $ok) { $script:fail++ }
    Write-Output ("    {0,-6} order={1} volume={2,-8} csv={3,-8} share={4,-9} movement={5,-8} colour={6} {7}" -f `
        $r.'Reminder Short Name', $r.'Reminder Order', $r.Volume, $exp,
        [math]::Round([double]$r.Share, 4), $r.Movement, $r.Colour,
        $(if ($ok) { 'PASS' } else { 'FAIL' }))
}

# --------------------------------------------------------------------------
Write-Output ''
Write-Output '=== 6. Test / Control behaviour ==='
$q4 = @'
EVALUATE
SUMMARIZECOLUMNS (
    'Dim_Population'[Population],
    'Dim_Population'[Receives Email],
    "EmailVolume", [Email Volume],
    "Records",     [Total Population],
    "Notice",      [Population Notice]
)
'@
foreach ($r in (Invoke-Dax $q4)) {
    Write-Output ("    {0,-10} receives={1,-5} emailVolume={2,-8} records={3}" -f `
        $r.Population, $r.'Receives Email',
        $(if ($null -eq $r.EmailVolume) { 'BLANK' } else { $r.EmailVolume }),
        $(if ($null -eq $r.Records) { 0 } else { $r.Records }))
}
$ctrlOnly = Invoke-Dax @'
EVALUATE
ROW (
    "EmailVolume", CALCULATE ( [Email Volume], 'Dim_Population'[Population] = "Control" ),
    "Notice",      CALCULATE ( [Population Notice], 'Dim_Population'[Population] = "Control" )
)
'@
$cv = $ctrlOnly[0].EmailVolume
Write-Output ("    Control-only selection -> Email Volume = {0}" -f $(if ($null -eq $cv) { 'BLANK (correct)' } else { "$cv (WRONG - control must never show sent email)" }))
if ($null -ne $cv) { $fail++ }
Write-Output ("    banner: {0}" -f $ctrlOnly[0].Notice)

# --------------------------------------------------------------------------
Write-Output ''
Write-Output '=== 7. filter-combination spot checks ==='
$q5 = @'
EVALUATE
SUMMARIZECOLUMNS (
    'Dim_Client'[Client_name],
    'Dim_Program'[Program],
    'Dim_Reminder'[Reminder Short Name],
    'Dim_CommCode'[comm_code],
    "Volume", [Email Volume],
    "PctOfSel", [% of Selected Volume]
)
ORDER BY [Volume] DESC
'@
$rows5 = Invoke-Dax $q5
Write-Output ("    client x program x reminder x creative combinations: {0}" -f $rows5.Count)
$sum5 = ($rows5 | Measure-Object -Property Volume -Sum).Sum
Check 'Sum over all combos' $sum5 $expect.email_volume_test

$q6 = @'
EVALUATE
CALCULATETABLE (
    ROW (
        "Volume", [Email Volume],
        "Stages", [Journey Stage Count],
        "Journey", [Journey Path Label],
        "Latest", [Latest Available Date],
        "Prev", [Previous Available Date]
    ),
    'Dim_Date'[Date] >= DATE ( 2026, 8, 1 ) && 'Dim_Date'[Date] <= DATE ( 2026, 8, 15 )
)
'@
$r6 = (Invoke-Dax $q6)[0]
Write-Output ("    date window 01-Aug-26..15-Aug-26 -> volume={0} latest={1} prev={2}" -f `
    $r6.Volume, $r6.Latest.ToString('yyyy-MM-dd'), $r6.Prev.ToString('yyyy-MM-dd'))
$expWindow = 0
$expect.daily.PSObject.Properties | ForEach-Object {
    if ($_.Name -ge '2026-08-01' -and $_.Name -le '2026-08-15') { $expWindow += [int]$_.Value }
}
Check 'Windowed volume' $r6.Volume $expWindow

# --------------------------------------------------------------------------
Write-Output ''
Write-Output ('=' * 72)
if ($fail -gt 0) {
    Write-Output ("LIVE MODEL VERIFICATION FAILED - {0} problem(s)" -f $fail)
    $conn.Close(); exit 1
}
Write-Output 'LIVE MODEL VERIFICATION PASSED - DAX matches the CSV on every check'
$conn.Close()
exit 0
