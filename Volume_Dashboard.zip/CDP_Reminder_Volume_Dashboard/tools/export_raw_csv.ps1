# Exports the full raw extract from the live model to CSV, with no row cap.
#
#   powershell -ExecutionPolicy Bypass -File tools\export_raw_csv.ps1
#   powershell -ExecutionPolicy Bypass -File tools\export_raw_csv.ps1 -Out C:\temp\cdp.csv
#
# Why this exists: Power BI's in-visual "Export data" is capped at 30,000 rows
# for CSV and 150,000 for Excel. At the production shape this report is built
# for - 100k+ rows - that silently truncates, which is worse than refusing.
# This runs one DAX query against the model already open in Desktop and streams
# every row out, so "the full raw data" means all of it.
#
# It exports the model's own view of the extract, not the source file: the
# cleaned, typed, dimension-joined rows the report actually reads. That is
# usually what someone asking for "the raw data behind the dashboard" wants. To
# get the untouched source instead, just copy the CSV the model was refreshed
# from.
param(
    [string]$Out = "",
    [switch]$TestOnly
)
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
if (-not $Out) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $Out = Join-Path $root ("Exports\CDP_raw_extract_$stamp.csv")
}
New-Item -ItemType Directory -Force (Split-Path -Parent $Out) | Out-Null

# ---- connect to the workspace instance Desktop is running -----------------
. "$PSScriptRoot\_find_adomd.ps1"
$adomd = Get-AdomdPath
if (-not $adomd) { "Power BI Desktop ADOMD client not found - is Desktop installed?"; exit 1 }
[void][System.Reflection.Assembly]::LoadFrom($adomd)

$wsRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\Power BI Desktop\AnalysisServicesWorkspaces'
$conn = $null
foreach ($dir in (Get-ChildItem $wsRoot -Directory -EA SilentlyContinue |
                  Sort-Object LastWriteTime -Descending)) {
    $pf = Join-Path $dir.FullName 'Data\msmdsrv.port.txt'
    if (-not (Test-Path $pf)) { continue }
    # The port file is UTF-16; pull the digits out rather than trusting the encoding.
    $port = -join ((Get-Content $pf -Raw).ToCharArray() | Where-Object { $_ -match '\d' })
    if (-not $port) { continue }
    try {
        $probe = New-Object Microsoft.AnalysisServices.AdomdClient.AdomdConnection("Data Source=localhost:$port")
        $probe.Open()
        $cmd = $probe.CreateCommand()
        $cmd.CommandText = 'SELECT [CATALOG_NAME] FROM $SYSTEM.DBSCHEMA_CATALOGS'
        $rdr = $cmd.ExecuteReader()
        $cat = $null
        if ($rdr.Read()) { $cat = $rdr.GetValue(0) }
        $rdr.Close(); $probe.Close()
        if (-not $cat) { continue }
        $conn = New-Object Microsoft.AnalysisServices.AdomdClient.AdomdConnection("Data Source=localhost:$port;Catalog=$cat")
        $conn.Open()
        "connected to $cat on port $port"
        break
    } catch { }
}
if (-not $conn) {
    "No Power BI Desktop workspace instance found. Open the .pbip and refresh it first."
    exit 1
}

# ---- one query, every row -------------------------------------------------
# SUMMARIZECOLUMNS over the dimension columns with a row count and the two
# volume measures gives exactly the grain the Daily Operations page shows.
$filter = ""
if ($TestOnly) { $filter = ", 'Dim_Population'[Population] = ""Test""" }

$dax = @"
EVALUATE
SUMMARIZECOLUMNS (
    'Dim_Date'[Date],
    'Dim_Client'[Client_name],
    'Dim_ClientGroup'[client_group],
    'Dim_Program'[Program],
    'Dim_Reminder'[Reminder Display Name],
    'Dim_CommCode'[comm_code],
    'Dim_Site'[site_code],
    'Dim_Population'[Population],
    "Rows", [Total Rows],
    "Email Volume (Test only)", [Email Volume],
    "Volume (T + C)", [Email Volume (All Populations)]
)
ORDER BY 'Dim_Date'[Date] DESC, 'Dim_Client'[Client_name]
"@

$cmd = $conn.CreateCommand()
$cmd.CommandTimeout = 1800
$cmd.CommandText = $dax
$reader = $cmd.ExecuteReader()

$sw = New-Object System.IO.StreamWriter($Out, $false, (New-Object System.Text.UTF8Encoding($true)))
try {
    $n = $reader.FieldCount
    $names = @()
    for ($i = 0; $i -lt $n; $i++) {
        # DAX returns names as [Table[Column]]; strip to something a
        # spreadsheet will not choke on.
        $raw = $reader.GetName($i)
        $names += ($raw -replace '^\[|\]$', '' -replace '.*\[', '')
    }
    $sw.WriteLine(($names | ForEach-Object { '"' + ($_ -replace '"', '""') + '"' }) -join ',')

    $rows = 0
    while ($reader.Read()) {
        $cells = @()
        for ($i = 0; $i -lt $n; $i++) {
            $v = $reader.GetValue($i)
            if ($null -eq $v -or $v -is [System.DBNull]) { $cells += '""'; continue }
            if ($v -is [datetime]) { $cells += '"' + $v.ToString('yyyy-MM-dd') + '"'; continue }
            if ($v -is [double] -or $v -is [decimal] -or $v -is [int] -or $v -is [long]) {
                # Invariant culture: a comma decimal separator would split the
                # cell in a CSV.
                $cells += ([string]$v -replace ',', '')
                continue
            }
            $cells += '"' + (([string]$v) -replace '"', '""') + '"'
        }
        $sw.WriteLine($cells -join ',')
        $rows++
    }
} finally {
    $sw.Close()
    $reader.Close()
    $conn.Close()
}

$size = (Get-Item $Out).Length / 1MB
"wrote $Out"
"  rows: {0:N0}   size: {1:N1} MB" -f $rows, $size
"  (no row cap - the in-visual export stops at 30,000 for CSV)"
