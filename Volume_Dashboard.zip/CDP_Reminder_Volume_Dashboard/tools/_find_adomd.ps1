# Locates the Power BI Desktop ADOMD client on this machine.
#
# Dot-source it:  . "$PSScriptRoot\_find_adomd.ps1"
#
# The path was hard-coded to C:\Program Files\... in three scripts, which is
# correct on a default install and wrong on a Microsoft Store install, a
# D:-drive install, or a machine where only the standalone client libraries
# are present. Searching a handful of known locations costs nothing and makes
# the tooling work on a machine nobody configured by hand.
function Get-AdomdPath {
    $candidates = @()
    foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)},
                        $env:LOCALAPPDATA)) {
        if (-not $base) { continue }
        $candidates += Join-Path $base 'Microsoft Power BI Desktop\bin\Microsoft.PowerBI.AdomdClient.dll'
        $candidates += Join-Path $base 'Microsoft Power BI Desktop\bin\Microsoft.AnalysisServices.AdomdClient.dll'
    }
    # Microsoft Store installs live under WindowsApps with a versioned folder.
    $store = Join-Path $env:ProgramFiles 'WindowsApps'
    if (Test-Path $store) {
        $candidates += (Get-ChildItem $store -Directory -Filter 'Microsoft.MicrosoftPowerBIDesktop*' -EA SilentlyContinue |
                        ForEach-Object { Join-Path $_.FullName 'bin\Microsoft.PowerBI.AdomdClient.dll' })
    }
    foreach ($c in $candidates) {
        if ($c -and (Test-Path $c)) { return $c }
    }
    return $null
}
