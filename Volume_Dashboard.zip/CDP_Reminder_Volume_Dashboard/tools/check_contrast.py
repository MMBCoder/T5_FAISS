# -*- coding: utf-8 -*-
"""Audits text contrast across the emitted report.

Inverting a report from a dark canvas to a light one is exactly the change that
leaves a colour behind: a caption that was correct as pale grey on navy becomes
pale grey on white and disappears, and nothing errors. This walks every text
element in report.json, works out which surface it actually sits on by
geometry and z-order, and reports the WCAG contrast ratio.

Thresholds follow WCAG 2.1 AA: 4.5:1 for body text, 3.0:1 for large text
(>=18pt, or >=14pt bold).

Run:  python tools/check_contrast.py
Exit code 1 if anything falls below its threshold.
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT = "CDP_Reminder_Volume_Dashboard"
LEGACY = os.path.join(ROOT, PROJECT + ".Report", "report.json")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from preview_report import val, prop, measure_of   # noqa: E402


def rgb(h):
    h = (h or "").lstrip("#")
    if len(h) != 6:
        return None
    try:
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    except ValueError:
        return None


def luminance(c):
    def ch(v):
        v /= 255.0
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(x) for x in c)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def ratio(fg, bg):
    a, b = luminance(fg), luminance(bg)
    hi, lo = max(a, b), min(a, b)
    return (hi + 0.05) / (lo + 0.05)


def contains(outer, inner):
    ox, oy, ow, oh = outer
    ix, iy, iw, ih = inner
    # The centre of the text element is what matters: a transparent card laid
    # over a panel takes that panel's colour under its own text.
    cx, cy = ix + iw / 2.0, iy + ih / 2.0
    return ox <= cx <= ox + ow and oy <= cy <= oy + oh


def main():
    doc = json.load(open(LEGACY, encoding="utf-8"))
    failures, checked = [], 0

    for sec in sorted(doc["sections"], key=lambda s: s.get("ordinal", 0)):
        pname = sec.get("displayName", sec["name"])
        page_bg = prop(sec.get("objects") or {}, "background", "color", "#FFFFFF")

        items = []
        for vc in sec["visualContainers"]:
            cfg = json.loads(vc["config"])
            sv = cfg.get("singleVisual", {})
            box = (vc.get("x", 0), vc.get("y", 0),
                   vc.get("width", 0), vc.get("height", 0))
            vco = sv.get("vcObjects", {})
            fill = None
            if prop(vco, "background", "show"):
                fill = prop(vco, "background", "color")
            # A button paints itself through its fill object, under `objects`
            # rather than `vcObjects` - reading the wrong one meant every
            # navigation label went unchecked.
            if sv.get("visualType") == "actionButton":
                for e in (sv.get("objects") or {}).get("fill", []) or []:
                    c = val((e.get("properties") or {}).get("fillColor"))
                    if c:
                        fill = c
            items.append({"vc": vc, "cfg": cfg, "sv": sv, "box": box,
                          "z": vc.get("z", 0), "fill": fill})

        def surface_under(item):
            """The colour of the topmost opaque thing beneath this element.

            Ties on z are broken by area, smallest first. Background surfaces
            are all emitted at z = 0, so a 46px badge laid on the full-width
            masthead ties with it - and taking the masthead meant the badge's
            own white-on-gold number was measured against the pine behind it
            and silently passed.
            """
            best, best_key = page_bg, None
            for o in items:
                if o is item or not o["fill"]:
                    continue
                if o["z"] > item["z"]:
                    continue
                if not contains(o["box"], item["box"]):
                    continue
                key = (o["z"], -(o["box"][2] * o["box"][3]))
                if best_key is None or key > best_key:
                    best, best_key = o["fill"], key
            return best

        for it in items:
            sv, vco = it["sv"], it["sv"].get("vcObjects", {})
            o = sv.get("objects", {})
            under = it["fill"] or surface_under(it)
            texts = []

            if prop(vco, "title", "show"):
                texts.append(("title", prop(vco, "title", "fontColor"),
                              prop(vco, "title", "fontSize", 11), True))
            if prop(vco, "subTitle", "show"):
                texts.append(("subtitle", prop(vco, "subTitle", "fontColor"),
                              prop(vco, "subTitle", "fontSize", 9.5), False))

            vt = sv.get("visualType")
            if vt == "textbox":
                for para in (prop(o, "general", "paragraphs") or []):
                    for r in para.get("textRuns", []):
                        st = r.get("textStyle", {})
                        if not (r.get("value") or "").strip():
                            continue
                        size = str(st.get("fontSize", "9pt")).replace("pt", "")
                        texts.append(("text %r" % r["value"][:28],
                                      st.get("color"), float(size),
                                      st.get("fontWeight") is not None))
            elif vt == "card":
                c = prop(o, "labels", "color")
                if isinstance(c, dict):
                    c = None      # measure-driven; checked by its own measure
                if c:
                    texts.append(("value<%s>" % measure_of(it["cfg"]), c,
                                  prop(o, "labels", "fontSize", 28), True))
            elif vt == "actionButton":
                for e in (sv.get("objects") or {}).get("text", []) or []:
                    p = e.get("properties") or {}
                    if "text" in p:
                        texts.append(("button %r" % val(p["text"]),
                                      val(p.get("fontColor")), 9, True))
            elif vt == "slicer":
                # Header and items are styled through `objects`, not `vcObjects`.
                texts.append(("slicer header",
                              prop(o, "header", "fontColor"), 8.5, True))
                # The items list paints its own background inside the slicer.
                ibg = prop(o, "items", "background") or under
                fg = prop(o, "items", "fontColor")
                if fg and rgb(fg) and rgb(ibg):
                    checked += 1
                    r = ratio(rgb(fg), rgb(ibg))
                    if r < 4.5:
                        failures.append((pname, sv.get("visualType"),
                                         "slicer items", fg, ibg, r, 4.5))

            for label, fg, size, bold in texts:
                f, b = rgb(fg), rgb(under)
                if not f or not b:
                    continue
                checked += 1
                large = size >= 18 or (size >= 14 and bold)
                need = 3.0 if large else 4.5
                r = ratio(f, b)
                if r < need:
                    failures.append((pname, vt, label, fg, under, r, need))

    for pname, vt, label, fg, bg, r, need in failures:
        print("  LOW  %-22s %-14s %-34s %s on %s  %.2f:1 (needs %.1f)"
              % (pname[:22], vt, label[:34], fg, bg, r, need))
    print("contrast: %d text elements checked, %d below threshold"
          % (checked, len(failures)))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
