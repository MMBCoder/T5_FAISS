# -*- coding: utf-8 -*-
"""Generates the documentation set from the project itself.

Data_Model.md and DAX_Measures.md are written from the same Python definitions
that build the semantic model, and Data_Profile.md from the same CSV the model
loads. Hand-written copies of either would be wrong within a week; generated
ones cannot drift.

Run: python tools/gen_docs.py
"""
import collections
import csv
import datetime
import io
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import model_measures as MM
import gen_semantic_model as GSM
import validate_data as VD

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DOCS = os.path.join(ROOT, "Documentation")


def write(name, text):
    os.makedirs(DOCS, exist_ok=True)
    with io.open(os.path.join(DOCS, name), "w", encoding="utf-8") as fh:
        fh.write(text.rstrip() + "\n")
    print("  wrote Documentation/%s" % name)


# --------------------------------------------------------------------------
def data_profile():
    rows, headers, vol_col = VD.load()
    s = VD.summarise(rows)
    L = []
    w = L.append
    w("# Data Profile")
    w("")
    w("Profile of the supplied extract, produced by `python tools/gen_docs.py` "
      "before any modelling decision was taken.")
    w("")
    w("| Property | Value |")
    w("|---|---|")
    w("| Source | `Data/CDP_Projects_Summary_History.csv` |")
    w("| Rows | %s |" % "{:,}".format(s["source_rows"]))
    w("| Columns | %d |" % len(headers))
    w("| Date range | %s to %s |" % (s["earliest_date"], s["latest_date"]))
    w("| Distinct dates with data | %d |" % s["active_days"])
    w("| Total volume column sum | %s |" % "{:,}".format(s["email_volume_all"]))
    w("| Encoding | UTF-8 with BOM |")
    w("")

    w("## Columns as they appear in the file")
    w("")
    w("| # | Header | Inferred type | Distinct values | Nulls |")
    w("|---:|---|---|---:|---:|")
    for i, h in enumerate(headers, 1):
        vals = [(r.get(h) or "").strip() for r in rows]
        nulls = sum(1 for v in vals if v == "")
        distinct = len({v for v in vals if v})
        if h == "file_date":
            typ = "date (dd-MMM-yy)"
        elif h.lower() in VD.VOLUME_ALIASES:
            typ = "whole number"
        else:
            typ = "text"
        w("| %d | `%s` | %s | %s | %d |"
          % (i, h, typ, "{:,}".format(distinct), nulls))
    w("")
    w("> The volume column ships as **`%s`**, while the specification calls it "
      "`Number of Email`. Power Query accepts either name and normalises to "
      "`Number of Email`, so the documented DAX works verbatim against either "
      "drop." % vol_col)
    w("")

    w("## Distinct values")
    w("")
    for col in ["Client_name", "client_group", "Program", "rem_flag",
                "comm_code", "site_code", "t_c_ind"]:
        counts = collections.Counter((r.get(col) or "").strip() for r in rows)
        w("### `%s` - %d distinct" % (col, len(counts)))
        w("")
        w("| Value | Rows |")
        w("|---|---:|")
        for k, n in sorted(counts.items()):
            w("| %s | %s |" % (k or "*(blank)*", "{:,}".format(n)))
        w("")

    w("## Findings that shaped the model")
    w("")
    w("1. **There are no Control records.** All %s rows carry `t_c_ind = \"T\"`. "
      "The Test/Control rule is still enforced in the measure rather than "
      "assumed, and `Dim_Population` still carries a Control member, so the "
      "report behaves correctly the first time a Control row appears."
      % "{:,}".format(s["source_rows"]))
    w("2. **The feed is not daily-complete.** %d distinct dates span %s to %s, "
      "a window of %d calendar days. Averages therefore divide by days that "
      "carry data, and the previous-day comparison looks for the previous day "
      "that exists rather than subtracting one."
      % (s["active_days"], s["earliest_date"], s["latest_date"],
         (datetime.date(*map(int, s["latest_date"].split("-")))
          - datetime.date(*map(int, s["earliest_date"].split("-")))).days + 1))
    w("3. **Journeys differ in length.** The three client + program pairs in "
      "this extract have one, three and four reminder stages respectively, so "
      "the dynamic-journey requirement is exercised by real data rather than a "
      "contrived case.")
    w("")
    w("| Client | Program | Stages present |")
    w("|---|---|---|")
    for k, stages in sorted(s["journeys"].items()):
        client, program = k.split(" || ")
        w("| %s | %s | %s |" % (client, program, "  ->  ".join(stages)))
    w("")
    w("4. **`comm_code` and `client_group` are one-to-one with the client in "
      "this extract**, and `site_code` is one-to-one with the reminder stage "
      "within a client. Nothing in the model assumes that will stay true.")
    w("5. **No data-quality failures.** Every validation check returns zero: no "
      "nulls, no negative volumes, no unexpected T/C or reminder values, no "
      "duplicate rows on the business grain.")
    w("")
    return "\n".join(L)


# --------------------------------------------------------------------------
def data_model():
    tables = [GSM.fact_table(), GSM.dim_date(), GSM.dim_reminder(),
              GSM.dim_client(), GSM.dim_client_group(), GSM.dim_program(),
              GSM.dim_commcode(), GSM.dim_site(), GSM.dim_population(),
              GSM.measure_table()]
    L = []
    w = L.append
    w("# Data Model")
    w("")
    w("Generated by `python tools/gen_docs.py` from the same definitions that "
      "build the semantic model.")
    w("")
    w("## Shape")
    w("")
    w("A star schema. Every dimension filters the fact in one direction; there "
      "are no bidirectional relationships and no dimension-to-dimension joins.")
    w("")
    w("```text")
    w("                          Dim_Date")
    w("                              |")
    w("        Dim_Reminder          |          Dim_Client")
    w("                   \\          |          /")
    w("                    \\         |         /")
    w("   Dim_Program ------  Fact_ReminderVolume  ------ Dim_CommCode")
    w("                    /         |         \\")
    w("                   /          |          \\")
    w("          Dim_Site            |           Dim_ClientGroup")
    w("                       Dim_Population")
    w("")
    w("   _Measures  (measure home, no data)")
    w("```")
    w("")

    w("## Relationships")
    w("")
    w("| From (many) | To (one) | Cardinality | Cross-filter |")
    w("|---|---|---|---|")
    for name, ft, fc, tt, tc, cf in GSM.RELATIONSHIPS:
        w("| `%s[%s]` | `%s[%s]` | many-to-one | %s |"
          % (ft, fc, tt, tc, "both" if cf else "single"))
    w("")
    w("`Dim_Date` is marked as the model date table, and `Dim_Date[Date]` is "
      "the only date field any visual uses.")
    w("")
    w("The six dimensions that carry a slicer cross-filter in **both** "
      "directions. A star with single-direction relationships propagates "
      "dimension to fact and stops, so selecting a program filtered the data "
      "but left every client listed in the client slicer - including clients "
      "that run no such program. Filtering has to reach back up through the "
      "fact for one slicer to narrow another.")
    w("")
    w("`Dim_Date` and `Dim_Population` stay single-direction deliberately: the "
      "time-intelligence measures remove and replace date filters on purpose, "
      "and `Dim_Population` must always list both Test and Control even when "
      "an extract contains neither.")
    w("")

    w("## Tables")
    w("")
    for t in tables:
        w("### `%s`" % t.name)
        w("")
        for line in (t.desc or "").split("\n"):
            w(line)
        w("")
        w("- Storage: import, %s partition"
          % ("Power Query (M)" if t.kind == "m" else "calculated (DAX)"))
        if t.measures:
            w("- Measures: %d (see DAX_Measures.md)" % len(t.measures))
        w("")
        if t.columns:
            w("| Column | Type | Hidden | Sorted by | Description |")
            w("|---|---|---|---|---|")
            for c in t.columns:
                w("| `%s` | %s | %s | %s | %s |"
                  % (c.name, c.dtype, "yes" if c.hidden else "no",
                     ("`%s`" % c.sort_by) if c.sort_by else "-",
                     (c.desc or "").replace("\n", " ")))
            w("")

    w("## Business logic held in the model")
    w("")
    w("**Test versus Control.** `t_c_ind` is `T` for the population that "
      "receives the reminder email and `C` for the control population that does "
      "not. Control rows are loaded and kept - the model can report on them as "
      "a population - but `[Email Volume]`, and every measure derived from it, "
      "filters to `T`. `Fact_ReminderVolume[Number of Email]` is hidden and the "
      "model sets `discourageImplicitMeasures`, so a report author cannot "
      "casually drag the raw column into a visual and reintroduce Control "
      "volume.")
    w("")
    w("**Reminder ordering.** `Dim_Reminder[Reminder Order]` is parsed from the "
      "digits in `rem_flag` in Power Query, not from a hard-coded mapping. Every "
      "reminder field sorts by it, so stages are never ordered alphabetically "
      "and a `REM5` in a future extract sorts and labels itself.")
    w("")
    w("**Journey membership.** Which stages exist for a client and program is a "
      "property of the journey, not of the window being viewed. The "
      "`REMn In Journey` measures therefore evaluate membership with the date "
      "filter removed. That is what separates *this stage is not part of this "
      "journey* (blank) from *this stage exists but sent nothing in the selected "
      "period* (zero).")
    w("")
    w("**Client group.** `Dim_Client` is keyed on `Client_name` because that is "
      "what the fact joins on, and carries the group as an attribute. The "
      "authoritative group filter is `Dim_ClientGroup`, which joins the fact on "
      "the source value directly, so a client that legitimately spans two groups "
      "is represented truthfully rather than being forced into one.")
    w("")
    w("## Refresh")
    w("")
    w("| Parameter | Default | Purpose |")
    w("|---|---|---|")
    w("| `p_SourceFilePath` | `%s` | The extract to load. The only parameter "
      "in the model, and the only machine-specific value in the project. |"
      % GSM.DEFAULT_SOURCE)
    w("")
    w("Power Query cannot resolve a path relative to the report file, so this "
      "one value is absolute and has to be repointed when the project moves. "
      "It defaults to the copy bundled under `Data/`, which means a freshly "
      "built project refreshes without anyone touching it. See "
      "[Deployment.md](Deployment.md).")
    w("")
    w("One shared query, `Source_CDP`, reads and cleans the file once; the fact "
      "and every dimension derive from it, so they cannot disagree about what "
      "the source says.")
    w("")
    return "\n".join(L)


# --------------------------------------------------------------------------
def dax_measures():
    ms = MM.measures()
    by_folder = collections.OrderedDict()
    for m in ms:
        by_folder.setdefault(m["folder"] or "(none)", []).append(m)

    L = []
    w = L.append
    w("# DAX Measures")
    w("")
    w("All %d measures live in the `_Measures` table. Generated by "
      "`python tools/gen_docs.py` from `tools/model_measures.py`." % len(ms))
    w("")
    w("## The two rules everything else follows")
    w("")
    w("1. **Email volume is Test-only.** `[Email Volume]` filters the fact to "
      "`t_c_ind = \"T\"`. Selecting Control in the population slicer intersects "
      "that selection with the `T` filter and correctly returns blank; the page "
      "banner explains it rather than leaving the reader with an empty page.")
    w("2. **Absence is not zero.** A stage that is not part of a journey returns "
      "blank; a stage that exists but had no volume in the selected window "
      "returns zero.")
    w("")
    w("## Contents")
    w("")
    for folder, group in by_folder.items():
        w("- [%s](#%s) - %d measures"
          % (folder, folder.lower().replace(" ", "-").replace("&", ""),
             len(group)))
    w("")

    for folder, group in by_folder.items():
        w("## %s" % folder)
        w("")
        for m in group:
            w("### `%s`" % m["name"])
            w("")
            if m["desc"]:
                for line in m["desc"].split("\n"):
                    w(line)
                w("")
            meta = []
            if m["fmt"]:
                meta.append("format `%s`" % m["fmt"])
            if m["hidden"]:
                meta.append("hidden")
            if meta:
                w("*%s*" % ", ".join(meta))
                w("")
            w("```dax")
            w("%s =" % m["name"])
            for line in m["dax"].split("\n"):
                w("    " + line if line.strip() else "")
            w("```")
            w("")
    return "\n".join(L)


# --------------------------------------------------------------------------
def main():
    print("generating documentation")
    write("Data_Profile.md", data_profile())
    write("Data_Model.md", data_model())
    write("DAX_Measures.md", dax_measures())
    return 0


if __name__ == "__main__":
    sys.exit(main())
